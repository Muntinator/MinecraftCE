/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * mesh.c — greedy chunk mesher with BSP-friendly merge constraints.
 *
 * Pool management: each (chunk, dir) owns one contiguous pool segment.
 * Remeshing a chunk removes its six segments (memmove compaction) and
 * appends fresh ones at the end. Emission order inside a bucket is layer-
 * ascending, then slab/coordinate ascending — the renderer's cursor-free
 * slice walk depends on this.
 */

#include <string.h>

#include "mesh.h"
#include "light.h"
#include "liquid.h"

/* N5: torch is see-through for meshing (neighbours' faces stay visible) and
 * never emits full-block faces of its own (it renders as a small box).
 * push3 S0: the sapling is meshed the same way; its small-box draw is S4. */
static inline int see_through(uint8_t b)
{
    return b == B_AIR || b == B_TORCH || b == B_SAPLING;
}

quad_t quad_pool[QUAD_POOL_MAX];
bucket_t chunk_buckets[NCHUNKS][6];
uint16_t mesh_pool_used;
uint16_t mstat_quads;

static uint8_t chunk_dirty[NCHUNKS];
uint16_t mesh_events;   /* chunk bits set by mesh_dirty_block; the
                           compositor reads+clears (NCHUNKS==16) */

void mesh_init(void)
{
    memset(chunk_buckets, 0, sizeof chunk_buckets);
    memset(chunk_dirty, 1, sizeof chunk_dirty);
    mesh_pool_used = 0;
    mstat_quads = 0;
    liquids_reset();        /* push3 S3: a new/loaded world starts static */
    light_reset();          /* N5: (re)build the derived light field + torch
                               list from world[] before the first mesh, so
                               every quad bakes the correct face light */
}

void mesh_dirty_block(int x, int z)
{
    int cx = x >> CHUNK_SHIFT, cz = z >> CHUNK_SHIFT;
    if (cx < 0 || cx >= CHUNKS_X || cz < 0 || cz >= CHUNKS_Z)
        return;
    chunk_dirty[cx * CHUNKS_Z + cz] = 1;
    mesh_events |= (uint16_t)(1u << (cx * CHUNKS_Z + cz));
    /* faces on chunk borders live in the neighbor's mesh */
    if ((x & (CHUNK_SIZE - 1)) == 0 && cx > 0) {
        chunk_dirty[(cx - 1) * CHUNKS_Z + cz] = 1;
        mesh_events |= (uint16_t)(1u << ((cx - 1) * CHUNKS_Z + cz));
    }
    if ((x & (CHUNK_SIZE - 1)) == CHUNK_SIZE - 1 && cx < CHUNKS_X - 1) {
        chunk_dirty[(cx + 1) * CHUNKS_Z + cz] = 1;
        mesh_events |= (uint16_t)(1u << ((cx + 1) * CHUNKS_Z + cz));
    }
    if ((z & (CHUNK_SIZE - 1)) == 0 && cz > 0) {
        chunk_dirty[cx * CHUNKS_Z + cz - 1] = 1;
        mesh_events |= (uint16_t)(1u << (cx * CHUNKS_Z + cz - 1));
    }
    if ((z & (CHUNK_SIZE - 1)) == CHUNK_SIZE - 1 && cz < CHUNKS_Z - 1) {
        chunk_dirty[cx * CHUNKS_Z + cz + 1] = 1;
        mesh_events |= (uint16_t)(1u << (cx * CHUNKS_Z + cz + 1));
    }
}

/* remove a chunk's segments from the pool, shifting everything above down */
static void pool_remove_chunk(int ci)
{
    for (int d = 0; d < 6; d++) {
        bucket_t *b = &chunk_buckets[ci][d];
        if (b->count == 0)
            continue;
        uint16_t start = b->off, n = b->count;
        memmove(&quad_pool[start], &quad_pool[start + n],
                (size_t)(mesh_pool_used - start - n) * sizeof(quad_t));
        mesh_pool_used -= n;
        mstat_quads -= n;
        b->count = 0;
        for (int c = 0; c < NCHUNKS; c++)
            for (int e = 0; e < 6; e++)
                if (chunk_buckets[c][e].count &&
                    chunk_buckets[c][e].off > start)
                    chunk_buckets[c][e].off -= n;
    }
}

/* append a quad to the bucket's open segment; returns 0 when pool full */
static int emit(bucket_t *b, uint8_t layer, uint8_t a, uint8_t va,
                uint8_t w, uint8_t h, uint8_t block)
{
    if (mesh_pool_used >= QUAD_POOL_MAX)
        return 0;
    quad_t *q = &quad_pool[mesh_pool_used++];
    q->layer = layer; q->a = a; q->b = va; q->w = w; q->h = h;
    q->block = block;
    b->count++;
    mstat_quads++;
    return 1;
}

/* cave classification (bit 7 of the block byte): a face is "cave" when its
 * adjacent air cell lies STRICTLY below the generation-time terrain line
 * (world_height, frozen at gen — never updated by edits) for EVERY column
 * it covers. air_y is the y of the adjacent air cells; [cx0,cx0+cw) x
 * [cz0,cz0+ch) is the rect of air-cell columns. Out-of-world columns or a
 * single surface-or-above column un-flags the whole quad (conservative:
 * an unflagged quad is always drawn, so it can never hide a visible face). */
static uint8_t cave_flag(int air_y, int cx0, int cz0, int cw, int ch)
{
    for (int j = 0; j < ch; j++)
        for (int i = 0; i < cw; i++) {
            int x = cx0 + i, z = cz0 + j;
            if (x < 0 || x >= WORLD_SX || z < 0 || z >= WORLD_SZ)
                return 0;
            if (air_y >= world_height[x * WORLD_SZ + z])
                return 0;
        }
    return 0x80;
}

static void open_bucket(bucket_t *b)
{
    b->off = mesh_pool_used;
    b->count = 0;
    memset(b->layer_start, 0, sizeof b->layer_start);
}

/* fill layer_start entries from `from` upward with the final count, so a
 * slice [layer_start[L], layer_start[L+1]) is valid for every L even when
 * the pool filled mid-mesh */
static void close_bucket(bucket_t *b, int from)
{
    if (from > WORLD_SY)
        from = WORLD_SY;
    while (from <= WORLD_SY)
        b->layer_start[from++] = b->count;
}

/* ---- meshing of one chunk ---- */

static void mesh_y_dir(int ci, int bx, int bz, int dir)
{
    bucket_t *b = &chunk_buckets[ci][dir];
    open_bucket(b);
    int dy = (dir == DIR_PY) ? 1 : -1;
    int y;

    for (y = 0; y < WORLD_SY; y++) {
        b->layer_start[y] = b->count;
        uint8_t grid[CHUNK_SIZE][CHUNK_SIZE];  /* [x][z] block id or 0 */
        uint8_t lg[CHUNK_SIZE][CHUNK_SIZE];    /* face light of that cell */
        for (int x = 0; x < CHUNK_SIZE; x++)
            for (int z = 0; z < CHUNK_SIZE; z++) {
                uint8_t blk = world[WORLD_IDX(bx + x, y, bz + z)];
                if (!see_through(blk) &&
                    see_through(world_get(bx + x, y + dy, bz + z))) {
                    grid[x][z] = blk;
                    lg[x][z] = light_get(bx + x, y + dy, bz + z);
                } else {
                    grid[x][z] = 0;
                }
            }
        for (int z = 0; z < CHUNK_SIZE; z++) {
            for (int x = 0; x < CHUNK_SIZE; x++) {
                uint8_t id = grid[x][z];
                if (!id)
                    continue;
                uint8_t lv = lg[x][z];         /* N5: merge on light too */
                int w = 1;
                while (w < 4 && x + w < CHUNK_SIZE &&
                       grid[x + w][z] == id && lg[x + w][z] == lv)
                    w++;
                int h = 1;
                for (; h < 4 && z + h < CHUNK_SIZE; h++) {
                    int ok = 1;
                    for (int i = 0; i < w; i++)
                        if (grid[x + i][z + h] != id ||
                            lg[x + i][z + h] != lv) { ok = 0; break; }
                    if (!ok)
                        break;
                }
                for (int j = 0; j < h; j++)
                    for (int i = 0; i < w; i++)
                        grid[x + i][z + j] = 0;
                /* air cells sit directly above (+y) / below (-y) the rect,
                 * same columns, at layer y+dy */
                uint8_t cf = cave_flag(y + dy, bx + x, bz + z, w, h);
                if (!emit(b, (uint8_t)y, (uint8_t)(bx + x),
                          (uint8_t)(bz + z), (uint8_t)w, (uint8_t)h,
                          (uint8_t)(id | cf | (lv << 5))))
                    goto full;
            }
        }
    }
full:
    close_bucket(b, y + 1);
}

static void mesh_z_dir(int ci, int bx, int bz, int dir)
{
    bucket_t *b = &chunk_buckets[ci][dir];
    open_bucket(b);
    int dz = (dir == DIR_PZ) ? 1 : -1;
    int y;

    for (y = 0; y < WORLD_SY; y++) {
        b->layer_start[y] = b->count;
        for (int z = 0; z < CHUNK_SIZE; z++) {
            for (int x = 0; x < CHUNK_SIZE; x++) {
                uint8_t blk = world[WORLD_IDX(bx + x, y, bz + z)];
                if (see_through(blk) ||
                    !see_through(world_get(bx + x, y, bz + z + dz)))
                    continue;
                uint8_t lv = light_get(bx + x, y, bz + z + dz);
                int w = 1;
                while (x + w < CHUNK_SIZE) {
                    uint8_t nb = world[WORLD_IDX(bx + x + w, y, bz + z)];
                    if (nb != blk ||
                        !see_through(world_get(bx + x + w, y, bz + z + dz)) ||
                        light_get(bx + x + w, y, bz + z + dz) != lv)
                        break;
                    w++;
                }
                /* air cells: the x-run [bx+x, bx+x+w) at z = bz+z+dz, layer y */
                uint8_t cf = cave_flag(y, bx + x, bz + z + dz, w, 1);
                if (!emit(b, (uint8_t)y, (uint8_t)(bz + z),
                          (uint8_t)(bx + x), (uint8_t)w, 1,
                          (uint8_t)(blk | cf | (lv << 5))))
                    goto full;
                x += w - 1;
            }
        }
    }
full:
    close_bucket(b, y + 1);
}

static void mesh_x_dir(int ci, int bx, int bz, int dir)
{
    bucket_t *b = &chunk_buckets[ci][dir];
    open_bucket(b);
    int dx = (dir == DIR_PX) ? 1 : -1;
    int y;

    for (y = 0; y < WORLD_SY; y++) {
        b->layer_start[y] = b->count;
        for (int z = 0; z < CHUNK_SIZE; z++) {
            for (int x = 0; x < CHUNK_SIZE; x++) {
                uint8_t blk = world[WORLD_IDX(bx + x, y, bz + z)];
                if (see_through(blk) ||
                    !see_through(world_get(bx + x + dx, y, bz + z)))
                    continue;
                uint8_t lv = light_get(bx + x + dx, y, bz + z);
                /* air cell: single column (bx+x+dx, bz+z) at layer y */
                uint8_t cf = cave_flag(y, bx + x + dx, bz + z, 1, 1);
                if (!emit(b, (uint8_t)y, (uint8_t)(bz + z),
                          (uint8_t)(bx + x), 1, 1,
                          (uint8_t)(blk | cf | (lv << 5))))
                    goto full;
            }
        }
    }
full:
    close_bucket(b, y + 1);
}

void mesh_update_chunk(int ci)
{
    chunk_dirty[ci] = 0;
    pool_remove_chunk(ci);
    int bx = (ci / CHUNKS_Z) << CHUNK_SHIFT;
    int bz = (ci % CHUNKS_Z) << CHUNK_SHIFT;
    mesh_y_dir(ci, bx, bz, DIR_PY);
    mesh_y_dir(ci, bx, bz, DIR_NY);
    mesh_x_dir(ci, bx, bz, DIR_PX);
    mesh_x_dir(ci, bx, bz, DIR_NX);
    mesh_z_dir(ci, bx, bz, DIR_PZ);
    mesh_z_dir(ci, bx, bz, DIR_NZ);
}

void mesh_update(void)
{
    for (int ci = 0; ci < NCHUNKS; ci++)
        if (chunk_dirty[ci])
            mesh_update_chunk(ci);
}
