/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * skydemo.h — push3 S5: the Skyblock "day one" script (make SKYDEMO=1).
 *
 * Included by main.c's interactive branch ONLY in the SKYDEMO build: from
 * here on kb_Scan()/kb_Data read this table instead of the keypad, and
 * everything else is the real game — title menu, create screen, world gen,
 * game_session's shell dispatch (2nd on the chest -> container_screen,
 * alpha -> inventory_screen), player_tick, the compositor and the HUD. The
 * game loop runs exactly SK_TPF ticks per frame (the timer is not read) and
 * create_screen's seed is DEMO_SEED, so the run is deterministic: host
 * --s5demo compiles the same main.c over tools/host/calcshim.h and must end
 * on the same frame (tests/autotest-s5demo.json).
 *
 * One step = `n` kb_Scan() calls with the same keys held. In game one scan
 * = one frame = SK_TPF ticks; in a menu / container screen one scan = one
 * pass of its key loop (K_SLOW adds 40 ms per scan there on the calc so a
 * viewer can follow the menus; delay() does not touch any game state).
 */
#ifndef SKYDEMO_H
#define SKYDEMO_H

#define SK_TPF 2                /* game ticks per frame (the real game: 1..4) */

typedef struct {
    uint8_t n;                  /* scans (0 for a storyboard mark) */
    uint8_t g1;                 /* keypad group 1 as-is */
    uint8_t g7;                 /* bits 0-3 arrows (group 7), 4 enter,
                                   5 clear, 6 alpha, 7 slow */
    uint8_t dig;                /* 1..9 numpad digit; SK_MARK | beat id */
} sk_step_t;

#define SK_MARK 0x80
/* key sets for S(): group-1 keys as-is, arrows << 8, the rest above */
#define K_UP    (kb_Up << 8)
#define K_DOWN  (kb_Down << 8)
#define K_LEFT  (kb_Left << 8)
#define K_RIGHT (kb_Right << 8)
#define K_ENTER (1 << 12)
#define K_CLEAR (1 << 13)
#define K_ALPHA (1 << 14)
#define K_SLOW  (1 << 15)
/* in-game names (main.c read_input) */
#define G_FWD   K_UP
#define G_BACK  K_DOWN
#define G_LU    kb_Yequ         /* look up */
#define G_LL    kb_Window       /* look left */
#define G_LD    kb_Zoom         /* look down */
#define G_LR    kb_Trace        /* look right */
#define G_2ND   kb_2nd          /* jump / interact */
#define G_BRK   kb_Del          /* break (hold) */
#define G_PLACE kb_Mode         /* place / pour */
#define G_NEXT  kb_Graph        /* next hotbar slot */
#define S(n, k)  { (n), (uint8_t)(k), (uint8_t)((k) >> 8), 0 }
#define SD(n, d) { (n), 0, 0x80, (d) }          /* a digit, slow */
#define MARK(b)  { 0, 0, 0, SK_MARK | (b) }
#define M(n, k)  S(n, (k) | K_SLOW)             /* menu step */

/* storyboard beats (host --s5demo writes a PNG + asserts the world) */
enum { SB_START = 1, SB_CHEST, SB_OPEN, SB_TAKEN, SB_TRENCH, SB_LAVA,
       SB_WATER, SB_MINING, SB_REGEN, SB_LOGS, SB_CRAFT, SB_END };

static const sk_step_t sk_script[] = {
    /* ---- title: New World; create: Skyblock, Survival, Create ---- */
    M(12, 0), M(1, K_ENTER), M(6, 0),
    M(6, 0), M(1, K_RIGHT), M(6, 0), M(1, K_RIGHT), M(10, 0),
    M(1, K_ENTER), M(6, 0), M(1, K_RIGHT), M(10, 0),
    M(1, K_ENTER), M(6, 0), M(1, K_ENTER), M(1, 0),
    /* ---- in game: the spawn view, then walk to the chest ---- */
    S(2, 0), MARK(SB_START),
    S(20, 0),                           /* look at the island */
    S(4, G_FWD | G_LL),
    S(10, G_FWD),
    S(1, G_LD),
    S(6, 0), MARK(SB_CHEST),
    /* ---- 2nd on the chest (game_session's dispatch) ---- */
    S(1, G_2ND),
    M(8, 0), MARK(SB_OPEN),
    SD(1, 2), M(8, 0),                  /* water bucket -> hotbar 2 */
    M(1, K_RIGHT), M(8, 0),
    SD(1, 1), M(12, 0), MARK(SB_TAKEN), /* lava bucket -> hotbar 1 */
    M(1, K_CLEAR), M(1, 0),
    /* ---- to the trench spot ---- */
    S(6, 0),
    S(2, G_LR),
    S(4, G_FWD | G_LR),
    S(12, G_FWD),
    S(9, G_LR),
    S(2, G_BACK),                       /* step back: the trench line */
    S(4, 0),
    /* ---- dig a 3-long trench (x 20, z 17..19) in the grass by hand ---- */
    S(9, G_BRK),                        /* pitch -18: (20,4,17), 18 ticks */
    S(1, G_LD),
    S(9, G_BRK),                        /* -24: (20,4,18) */
    S(2, G_LD),
    S(9, G_BRK),                        /* -36: (20,4,19) */
    S(8, 0), MARK(SB_TRENCH),
    /* ---- lava at the far end, water at the near end ---- */
    S(1, G_LU), S(4, 0),                /* -30: the far floor */
    S(1, G_PLACE), S(12, 0), MARK(SB_LAVA),
    S(1, G_NEXT), S(3, G_LD),           /* water bucket, -48: near floor */
    S(6, 0),
    S(1, G_PLACE), S(20, 0), MARK(SB_WATER),
    /* ---- mine the first cobblestone by hand: it comes straight back ---- */
    S(3, G_LU), S(4, 0),                /* -30: the cobble */
    S(12, G_BRK), MARK(SB_MINING),
    S(11, G_BRK),                       /* 46 ticks: breaks at 45, regrown */
    S(3, 0), MARK(SB_REGEN),
    S(16, 0),
    /* ---- punch the tree: two logs, pick them up ---- */
    S(4, G_LL), S(2, G_LU),             /* yaw 96, pitch -18: log y5 */
    S(18, G_BRK),
    S(2, G_LU),                         /* -6: log y6 */
    S(18, G_BRK),
    S(4, 0),
    S(12, G_FWD),                       /* into the gap: both drops */
    S(4, 0),
    S(12, G_LR), S(2, G_LD),            /* face the generator */
    S(10, 0), MARK(SB_LOGS),
    /* ---- alpha: hand-craft planks, then a crafting table ---- */
    S(1, K_ALPHA),
    M(8, 0),
    M(1, K_UP), M(8, 0),                /* backpack -> recipe strip */
    M(1, K_ENTER), M(10, 0),            /* Oak Wood Planks x4 */
    M(1, K_RIGHT), M(6, 0), M(1, K_RIGHT), M(8, 0),
    M(1, K_ENTER), M(14, 0), MARK(SB_CRAFT),   /* Crafting Table */
    M(1, K_CLEAR), M(1, 0),
    /* ---- hold the new table (hotbar 5) ---- */
    S(4, 0),
    S(1, G_NEXT), S(3, 0), S(1, G_NEXT), S(3, 0), S(1, G_NEXT),
    S(40, 0),
};

#define SK_LEN (sizeof sk_script / sizeof sk_script[0])

#ifndef SK_BEAT
#define SK_BEAT(b) ((void)0)
#endif
#ifndef SK_STEP
#define SK_STEP(i) ((void)0)
#endif
#ifndef SK_OVER
#define SK_OVER() ((void)0)     /* host: a scan past the end (runaway) */
#endif

static uint8_t sk_kb[8];
static uint16_t sk_i;           /* next step */
static uint8_t sk_left;         /* scans left in the current step */
static uint8_t sk_slow;
static uint16_t sk_ticks;       /* game ticks run so far */

static void sk_scan(void)
{
    while (!sk_left) {
        memset(sk_kb, 0, sizeof sk_kb);
        if (sk_i >= SK_LEN) {
            SK_OVER();
            return;             /* script over: every key up */
        }
        const sk_step_t *s = &sk_script[sk_i++];
        if (s->dig & SK_MARK) {
            SK_BEAT(s->dig & 31);
            continue;
        }
        SK_STEP(sk_i - 1);
        sk_left = s->n;
        sk_kb[1] = s->g1;
        sk_kb[7] = s->g7 & 15;
        if (s->g7 & 16) sk_kb[6] |= kb_Enter;
        if (s->g7 & 32) sk_kb[6] |= kb_Clear;
        if (s->g7 & 64) sk_kb[2] |= kb_Alpha;
        sk_slow = s->g7 & 128;
        if (s->dig)             /* 1,4,7 group 3; 2,5,8 group 4; 3,6,9 group 5 */
            sk_kb[3 + (s->dig - 1) % 3] |= (uint8_t)(2 << ((s->dig - 1) / 3));
    }
    sk_left--;
    if (sk_slow)
        delay(40);
}

#define sk_end() (sk_i >= SK_LEN && !sk_left)

#undef kb_Data
#define kb_Data sk_kb
#define kb_Scan sk_scan

#endif
