/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * light.c — N5 block-light field: a small BFS-style flood (integer
 * relaxation) that quantizes to the 4 palette shade banks, plus the torch
 * render list. Portable (host-compiled): the harness --n5 test drives the
 * exact functions the calc uses.
 *
 * Model: torches emit LIGHT_MAX (3), lit furnaces FURNACE_LIGHT (2); light
 * falls off 1 per step through non-opaque cells with occlusion (opaque
 * non-source cells stay 0, so they never propagate — that IS the occlusion).
 * A block FACE takes the light of the adjacent air cell (sampled by the
 * mesher), so a lit room's walls brighten. Max light 3 => any lit cell is
 * within 3 steps of a source => LIGHT_MAX relaxation sweeps converge, and a
 * radius-LIGHT_MAX box captures a source's entire influence: both make the
 * incremental edits genuinely local.
 */

#include <string.h>

#include "light.h"
#include "mesh.h"
#include "textures.h"

uint8_t light_packed[(WORLD_N + 3) / 4];
uint8_t torch_n;
uint8_t torch_pos[TORCH_MAX][3];

/* opaque[id]: 1 blocks light, 0 lets it pass. A table (not a switch): the
 * eZ80 clang backend miscompiles a sparse membership switch into an
 * unsupported wide-constant bitmask test (fatal "unable to legalize i18"). */
static const uint8_t opaque_tbl[B_COUNT] = {
    0,  /* B_AIR         */
    1,  /* B_GRASS       */
    1,  /* B_DIRT        */
    1,  /* B_STONE       */
    1,  /* B_COBBLE      */
    1,  /* B_LOG         */
    0,  /* B_LEAVES      */
    1,  /* B_PLANKS      */
    1,  /* B_SAND        */
    0,  /* B_WATER       */
    0,  /* B_GLASS       */
    1,  /* B_BEDROCK     */
    1,  /* B_TNT         */
    1,  /* B_COAL_ORE    */
    1,  /* B_IRON_ORE    */
    1,  /* B_CRAFTING_TABLE */
    1,  /* B_FURNACE     */
    0,  /* B_TORCH       */
    1,  /* B_FURNACE_LIT */
    1,  /* B_CHEST       */
    0,  /* B_WATER_FLOW  */
    0,  /* B_LAVA        (emits LIGHT_MAX, S3) */
    0,  /* B_LAVA_FLOW   */
    1,  /* B_OBSIDIAN    */
    0,  /* B_SAPLING     */
};

bool block_opaque(uint8_t b)
{
    return b < B_COUNT ? (bool)opaque_tbl[b] : true;
}

uint8_t light_emit(uint8_t b)
{
    if (b == B_TORCH)
        return LIGHT_MAX;
    if (b == B_FURNACE_LIT)
        return FURNACE_LIGHT;
    if (b == B_LAVA || b == B_LAVA_FLOW)   /* push3 S3: lava glows */
        return LIGHT_MAX;
    return 0;
}

/* one relaxation sweep over the inclusive box: each non-opaque (or source)
 * cell rises to max(source_floor, max_neighbor - 1). max-only, so iterating
 * in place is safe and only accelerates convergence; LIGHT_MAX sweeps fully
 * propagate the 3-step field. Neighbours OUTSIDE the box are read too (via
 * light_get), which lets a removal box refill from intact surroundings. */
static void relax_box(int x0, int y0, int z0, int x1, int y1, int z1)
{
    for (int pass = 0; pass < LIGHT_MAX; pass++)
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++)
                for (int y = y0; y <= y1; y++) {
                    int idx = WORLD_IDX(x, y, z);
                    uint8_t b = world[idx];
                    uint8_t fl = light_emit(b);
                    if (block_opaque(b) && !fl)
                        continue;              /* opaque non-source: stays 0 */
                    uint8_t m = 0, nl;
                    nl = light_get(x + 1, y, z); if (nl > m) m = nl;
                    nl = light_get(x - 1, y, z); if (nl > m) m = nl;
                    nl = light_get(x, y + 1, z); if (nl > m) m = nl;
                    nl = light_get(x, y - 1, z); if (nl > m) m = nl;
                    nl = light_get(x, y, z + 1); if (nl > m) m = nl;
                    nl = light_get(x, y, z - 1); if (nl > m) m = nl;
                    uint8_t want = m ? (uint8_t)(m - 1) : 0;
                    if (want < fl)
                        want = fl;
                    uint8_t cur = (light_packed[idx >> 2] >>
                                   ((idx & 3) << 1)) & 3;
                    if (want > cur)
                        light_set_idx(idx, want);
                }
}

void light_reset(void)
{
    memset(light_packed, 0, sizeof light_packed);
    torch_n = 0;
    for (int x = 0; x < WORLD_SX; x++)
        for (int z = 0; z < WORLD_SZ; z++)
            for (int y = 0; y < WORLD_SY; y++) {
                int idx = WORLD_IDX(x, y, z);
                uint8_t b = world[idx];
                uint8_t e = light_emit(b);
                if (e)
                    light_set_idx(idx, e);
                if (b == B_TORCH || b == B_SAPLING)
                    torch_list_add(x, y, z);
            }
    relax_box(0, 0, 0, WORLD_SX - 1, WORLD_SY - 1, WORLD_SZ - 1);
}

/* clamp a radius-LIGHT_MAX box around (sx,sy,sz) into world bounds */
#define LBOX(sx, sy, sz)                                                    \
    int x0 = (sx) - LIGHT_MAX, x1 = (sx) + LIGHT_MAX;                       \
    int y0 = (sy) - LIGHT_MAX, y1 = (sy) + LIGHT_MAX;                       \
    int z0 = (sz) - LIGHT_MAX, z1 = (sz) + LIGHT_MAX;                       \
    if (x0 < 0) x0 = 0; if (y0 < 0) y0 = 0; if (z0 < 0) z0 = 0;             \
    if (x1 >= WORLD_SX) x1 = WORLD_SX - 1;                                  \
    if (y1 >= WORLD_SY) y1 = WORLD_SY - 1;                                  \
    if (z1 >= WORLD_SZ) z1 = WORLD_SZ - 1

/* snapshot a box (<= (2*LIGHT_MAX+1)^3), diff it after an edit, and mark every
 * column whose light column changed mesh-dirty (chunk-local remesh). */
#define LBOX_DIM (2 * LIGHT_MAX + 1)

void light_add_source(int sx, int sy, int sz, uint8_t emit)
{
    LBOX(sx, sy, sz);
    uint8_t snap[LBOX_DIM][LBOX_DIM][LBOX_DIM];
    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++)
            for (int y = y0; y <= y1; y++)
                snap[x - x0][y - y0][z - z0] = light_get(x, y, z);

    int si = WORLD_IDX(sx, sy, sz);
    if (light_get(sx, sy, sz) < emit)
        light_set_idx(si, emit);
    relax_box(x0, y0, z0, x1, y1, z1);

    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++) {
            int changed = 0;
            for (int y = y0; y <= y1; y++)
                if (light_get(x, y, z) != snap[x - x0][y - y0][z - z0]) {
                    changed = 1;
                    break;
                }
            if (changed)
                mesh_dirty_block(x, z);
        }
}

void light_del_source(int sx, int sy, int sz)
{
    LBOX(sx, sy, sz);
    uint8_t snap[LBOX_DIM][LBOX_DIM][LBOX_DIM];
    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++)
            for (int y = y0; y <= y1; y++)
                snap[x - x0][y - y0][z - z0] = light_get(x, y, z);

    /* clear the box (non-source cells -> 0), keep any surviving source at its
     * emission; relax then refills from the intact surrounding cells */
    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++)
            for (int y = y0; y <= y1; y++) {
                int idx = WORLD_IDX(x, y, z);
                light_set_idx(idx, light_emit(world[idx]));
            }
    relax_box(x0, y0, z0, x1, y1, z1);

    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++) {
            int changed = 0;
            for (int y = y0; y <= y1; y++)
                if (light_get(x, y, z) != snap[x - x0][y - y0][z - z0]) {
                    changed = 1;
                    break;
                }
            if (changed)
                mesh_dirty_block(x, z);
        }
}

/* ---- torch render list ---- */

void torch_list_add(int x, int y, int z)
{
    for (int i = 0; i < torch_n; i++)
        if (torch_pos[i][0] == x && torch_pos[i][1] == y &&
            torch_pos[i][2] == z)
            return;
    if (torch_n < TORCH_MAX) {
        torch_pos[torch_n][0] = (uint8_t)x;
        torch_pos[torch_n][1] = (uint8_t)y;
        torch_pos[torch_n][2] = (uint8_t)z;
        torch_n++;
    }
}

void torch_list_del(int x, int y, int z)
{
    for (int i = 0; i < torch_n; i++)
        if (torch_pos[i][0] == x && torch_pos[i][1] == y &&
            torch_pos[i][2] == z) {
            torch_pos[i][0] = torch_pos[torch_n - 1][0];
            torch_pos[i][1] = torch_pos[torch_n - 1][1];
            torch_pos[i][2] = torch_pos[torch_n - 1][2];
            torch_n--;
            return;
        }
}

/* a torch is a small centered box wearing the torch tile; drawn through the
 * shared entity box pipeline (after the world, like drops/mobs — so it can
 * show through nearer geometry, the same accepted limitation those have).
 * push3 S4: saplings share the list and draw as a camera-facing sprite of
 * T_SAPLING, one block square on the cell floor, its inset background (the
 * tile's corner texel) keyed out. The cell is re-read, so an entry whose
 * block is gone (e.g. blown up) draws nothing. */
void torches_draw(uint8_t *fb, const camera_t *cam)
{
    for (int i = 0; i < torch_n; i++) {
        int x = torch_pos[i][0], y = torch_pos[i][1], z = torch_pos[i][2];
        fix cx = INT_TO_FIX(x) + FIX_ONE / 2;
        fix cz = INT_TO_FIX(z) + FIX_ONE / 2;
        fix dx = cx - cam->x, dz = cz - cam->z;
        if (dx < 0) dx = -dx;
        if (dz < 0) dz = -dz;
        if ((dx > dz ? dx : dz) > INT_TO_FIX(20))
            continue;                       /* out of the draw radius */
        uint8_t b = world[WORLD_IDX(x, y, z)];   /* list cells are in bounds */
        if (b == B_SAPLING) {
            int sx, sy;
            fix depth;
            const uint8_t *t = tex_data[T_SAPLING];
            if (render_project(cx, INT_TO_FIX(y) + FIX_ONE / 2, cz,
                               &sx, &sy, &depth))
                render_sprite16(sx, sy, (rfocal * FIX_ONE) / depth, t, t[0]);
        } else if (b == B_TORCH) {
            /* half 448/4096 ~= 0.11 wide, 2600/4096 ~= 0.63 tall, sitting on
             * the supporting block's top (cell floor at y) */
            render_box(fb, cx, INT_TO_FIX(y), cz, 448, 2600,
                       tex_avg[T_TORCH_BOX], tex_data[T_TORCH_BOX]);
        }
    }
}
