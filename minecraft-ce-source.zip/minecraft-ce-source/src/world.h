/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef WORLD_H
#define WORLD_H

#include "common.h"

#define WORLD_SX 32
#define WORLD_SZ 32
#define WORLD_SY 12

/* y innermost: a column is contiguous */
#define WORLD_IDX(x, y, z) ((((x) * WORLD_SZ) + (z)) * WORLD_SY + (y))

enum block_id {
    B_AIR = 0,
    B_GRASS,
    B_DIRT,
    B_STONE,
    B_COBBLE,
    B_LOG,
    B_LEAVES,
    B_PLANKS,
    B_SAND,
    B_WATER,
    B_GLASS,
    B_BEDROCK,
    B_TNT,
    B_COAL_ORE,
    B_IRON_ORE,             /* was B_GOLD_ORE (N1: iron replaces gold) */
    B_CRAFTING_TABLE,       /* placeable; opens the crafting UI (N4) */
    B_FURNACE,              /* placeable; unlit furnace (N4) */
    B_TORCH,                /* light-emitting placeable lands N5 */
    B_FURNACE_LIT,          /* N4: burning furnace — a distinct id so lighting a
                               furnace is a world edit that re-meshes the block
                               (the lit-front tile swap). Breaks/drops as
                               B_FURNACE; never held in the inventory. */
    /* push3 S0: Skyblock ids. Tables are wired now; behaviour lands later
     * (chest UI S2, liquid flow/buckets/obsidian rules S3, sapling growth +
     * its small-box draw S4). The three liquids below stay CONTIGUOUS so
     * block_liquid() is one range test. */
    B_CHEST,                /* 19 placeable; 27-slot container from S2 */
    B_WATER_FLOW,           /* 20 flowing water (T_WATER); S3 */
    B_LAVA,                 /* 21 lava source (T_LAVA); S3 */
    B_LAVA_FLOW,            /* 22 flowing lava (T_LAVA); S3 */
    B_OBSIDIAN,             /* 23 water-on-lava-source result; iron pick */
    B_SAPLING,              /* 24 torch-like (see-through, walk-through) */
    B_COUNT                 /* 25 */
};

extern uint8_t world[WORLD_SX * WORLD_SZ * WORLD_SY];

/* heightmap kept from generation; used for spawn and (later) trees */
extern uint8_t world_height[WORLD_SX * WORLD_SZ];
extern uint8_t g_worldtype;   /* 0 normal, 1 superflat, 2 skyblock (push3 S1) */

void world_gen(uint32_t seed);
/* push3 S4: the gen tree (logs y h+1..h+3 at x,z; leaves into air), map-edge
 * safe in x/z; the caller keeps h >= 0 and h + 4 < WORLD_SY */
void grow_tree(int x, int h, int z);

/* push3 S1: a new Skyblock player (at the (16,16) spawn corner) looks over
 * the island toward the tree instead of into the void */
#define SKY_SPAWN_YAW   40
#define SKY_SPAWN_PITCH (-12)

/* N3 leaf decay support: is there a B_LOG within Chebyshev distance r of
 * (x,y,z)? Pure read of world[]; OOB cells are never B_LOG. */
bool log_within(int x, int y, int z, int r);

/* Out of bounds: air on the sides/top (edge walls render), solid below
 * (nobody can see the world's underside — skip those faces). Skyblock
 * (push3 S1): below the map is the void, air — things fall through it. */
static inline uint8_t world_get(int x, int y, int z)
{
    if (y < 0)
        return g_worldtype == 2 ? B_AIR : B_BEDROCK;
    if (y >= WORLD_SY || x < 0 || x >= WORLD_SX || z < 0 || z >= WORLD_SZ)
        return B_AIR;
    return world[WORLD_IDX(x, y, z)];
}

static inline void world_set(int x, int y, int z, uint8_t b)
{
    if (x >= 0 && x < WORLD_SX && y >= 0 && y < WORLD_SY &&
        z >= 0 && z < WORLD_SZ)
        world[WORLD_IDX(x, y, z)] = b;
}

/* any water/lava cell, source or flowing: not solid for collision, placement
 * or the crosshair ray (B_WATER is 9; the other three are the 20..22 run) */
static inline bool block_liquid(uint8_t b)
{
    return b == B_WATER || (b >= B_WATER_FLOW && b <= B_LAVA_FLOW);
}

static inline bool block_solid(uint8_t b)
{
    return b != B_AIR;
}

#endif
