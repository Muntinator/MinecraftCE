/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#include "palette.h"

extern unsigned char global_palette[128];

/* M3+: base colors 0..60 come from the convimg-quantized texture palette
 * (src/gfx/global_palette.c, 1555 little-endian); 61..63 are reserved
 * (black / white / sky, pinned in convimg.yaml). Banks at +64/+128/+192
 * are pre-darkened copies for the per-direction face shading. */

uint8_t pal_red_idx;
uint8_t pal_shadow_idx;

/* per-bank brightness, /256: 100%, 80%, 62%, 50% */
static const uint16_t bank_scale[4] = { 256, 205, 159, 128 };

static void decode1555(int i, uint8_t *r, uint8_t *g, uint8_t *b)
{
    uint16_t v = (uint16_t)(global_palette[i * 2] |
                            (global_palette[i * 2 + 1] << 8));
    uint8_t r5 = (v >> 10) & 31, g5 = (v >> 5) & 31, b5 = v & 31;
    *r = (uint8_t)((r5 << 3) | (r5 >> 2));
    *g = (uint8_t)((g5 << 3) | (g5 >> 2));
    *b = (uint8_t)((b5 << 3) | (b5 >> 2));
}

void palette_build(uint8_t rgb[256][3])
{
    for (int bank = 0; bank < 4; bank++) {
        uint16_t s = bank_scale[bank];
        for (int i = 0; i < 64; i++) {
            uint8_t r, g, b;
            decode1555(i, &r, &g, &b);
            uint8_t *out = rgb[(bank << 6) | i];
            out[0] = (uint8_t)((r * s) >> 8);
            out[1] = (uint8_t)((g * s) >> 8);
            out[2] = (uint8_t)((b * s) >> 8);
        }
    }
    /* pick the reddest base entry for the hearts UI */
    {
        int best = 0, bscore = -10000;
        for (int i = 0; i < PAL_TEXBLACK; i++) {
            int sc = rgb[i][0] * 2 - rgb[i][1] * 2 - rgb[i][2];
            if (sc > bscore) { bscore = sc; best = i; }
        }
        pal_red_idx = (uint8_t)best;
        /* UI U3: the never-read pal_green_idx pick is gone (its .bss byte
         * pays for tex_avg[T_ICO_GUNPOWDER]) */
        /* UI U2: Minecraft's text shadow is the text colour at 25%; for
         * white that is (63,63,63). Nearest real (base or shaded) entry;
         * the reserved slots 60..63 and their banks are excluded. */
        best = 0; bscore = 1 << 22;
        for (int i = 0; i < 256; i++) {
            if ((i & 63) >= PAL_TEXBLACK)
                continue;
            int dr = rgb[i][0] - 63, dg = rgb[i][1] - 63, db = rgb[i][2] - 63;
            int sc = dr * dr + dg * dg + db * db;
            if (sc < bscore) { bscore = sc; best = i; }
        }
        pal_shadow_idx = (uint8_t)best;
    }

    /* reserved slots keep full brightness in every bank's base */
    rgb[PAL_SKY][0] = 120; rgb[PAL_SKY][1] = 175; rgb[PAL_SKY][2] = 235;
    rgb[PAL_WHITE][0] = rgb[PAL_WHITE][1] = rgb[PAL_WHITE][2] = 255;
    rgb[PAL_BLACK][0] = rgb[PAL_BLACK][1] = rgb[PAL_BLACK][2] = 0;
    for (int bank = 0; bank < 4; bank++) {
        uint8_t *tb = rgb[SHADE_IDX(PAL_TEXBLACK, bank)];
        tb[0] = tb[1] = tb[2] = 0;
    }

    /* M25 sky gradient (convimg untouched — these are runtime-only slots).
     * The bank variants of PAL_SKY (127/191/255) AND PAL_BLACK (125/189/253)
     * are unused by rendering (no block face has base 61/63; UI grays use
     * PAL_WHITE's banks) so we repaint the six of them, plus PAL_SKY itself,
     * as a 7-step deep->light vertical ramp (zenith .. horizon). Solid bands
     * (no vertical dither, which would stripe under the per-row memset); 7
     * near steps read smooth. The brightness LUT scales them together, so
     * night darkens the whole sky. */
    static const uint8_t ramp[6][3] = {   /* zenith(deep) .. one below horizon */
        { 58, 116, 203 }, { 68, 126, 208 }, { 79, 136, 214 },
        { 89, 145, 219 }, { 99, 155, 224 }, { 110, 165, 230 },
    };                                    /* horizon step = PAL_SKY (120,175,235) */
    static const uint8_t slot[6] = {
        SHADE_IDX(PAL_BLACK, 3), SHADE_IDX(PAL_BLACK, 2), SHADE_IDX(PAL_BLACK, 1),
        SHADE_IDX(PAL_SKY, 3),   SHADE_IDX(PAL_SKY, 2),   SHADE_IDX(PAL_SKY, 1),
    };
    for (int i = 0; i < 6; i++) {
        rgb[slot[i]][0] = ramp[i][0];
        rgb[slot[i]][1] = ramp[i][1];
        rgb[slot[i]][2] = ramp[i][2];
    }
}
