/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * craft.c — recipe table + shapeless craft logic (portable, host-compiled).
 *
 * N1 iron economy. Hand-craftable recipes (needs_table 0): planks, sticks,
 * torch, crafting table. Everything gated needs_table 1 (tools, armour) is
 * only craftable at a placed crafting table — the gate is ENFORCED in N2/N4;
 * this milestone just carries the flag. Counts operate on the player's slot
 * inventory via inv_count / inv_remove / inv_add (player.c).
 */

#include "craft.h"
#include "world.h"
#include "player.h"

const recipe_t recipes[RECIPE_COUNT] = {
    /* R1  1 LOG              -> 4 PLANKS                     (hand) */
    { 1, { {B_LOG, 1} },                    B_PLANKS,      4, CAT_BLOCKS, 0 },
    /* R2  2 PLANKS           -> 4 STICKS                     (hand) */
    { 1, { {B_PLANKS, 2} },                 I_STICK,       4, CAT_ITEMS,  0 },
    /* R3  1 COAL + 1 STICK   -> 4 TORCH                      (hand) */
    { 2, { {I_COAL, 1}, {I_STICK, 1} },     B_TORCH,       4, CAT_BLOCKS, 0 },
    /* R4  4 PLANKS           -> 1 CRAFTING TABLE             (hand) */
    { 1, { {B_PLANKS, 4} },                 B_CRAFTING_TABLE, 1, CAT_BLOCKS, 0 },
    /* R5  1 COAL + 2 SAND    -> 2 GLASS  (coal gives a use)  (table) */
    { 2, { {I_COAL, 1}, {B_SAND, 2} },      B_GLASS,       2, CAT_BLOCKS, 1 },
    /* R6  1 GUNPOWDER + 2 SAND -> 2 TNT  (creeper path)      (table) */
    { 2, { {I_GUNPOWDER, 1}, {B_SAND, 2} }, B_TNT,         2, CAT_BLOCKS, 1 },

    /* ---- tools: 3 head + 2 sticks (sword 2 + 1). Need a crafting table. ---- */
    { 2, { {B_PLANKS, 3}, {I_STICK, 2} },      I_PICK_WOOD,   1, CAT_TOOLS, 1 },
    { 2, { {B_STONE, 3}, {I_STICK, 2} },       I_PICK_STONE,  1, CAT_TOOLS, 1 },
    { 2, { {I_IRON_INGOT, 3}, {I_STICK, 2} },  I_PICK_IRON,   1, CAT_TOOLS, 1 },
    { 2, { {B_PLANKS, 3}, {I_STICK, 2} },      I_AXE_WOOD,    1, CAT_TOOLS, 1 },
    { 2, { {B_STONE, 3}, {I_STICK, 2} },       I_AXE_STONE,   1, CAT_TOOLS, 1 },
    { 2, { {I_IRON_INGOT, 3}, {I_STICK, 2} },  I_AXE_IRON,    1, CAT_TOOLS, 1 },
    { 2, { {B_PLANKS, 2}, {I_STICK, 1} },      I_SWORD_WOOD,  1, CAT_TOOLS, 1 },
    { 2, { {B_STONE, 2}, {I_STICK, 1} },       I_SWORD_STONE, 1, CAT_TOOLS, 1 },
    { 2, { {I_IRON_INGOT, 2}, {I_STICK, 1} },  I_SWORD_IRON,  1, CAT_TOOLS, 1 },

    /* ---- iron armour (ingots only). Need a crafting table. ---- */
    { 1, { {I_IRON_INGOT, 5} },  I_HELMET_IRON, 1, CAT_TOOLS, 1 },
    { 1, { {I_IRON_INGOT, 8} },  I_CHEST_IRON,  1, CAT_TOOLS, 1 },
    { 1, { {I_IRON_INGOT, 7} },  I_LEGS_IRON,   1, CAT_TOOLS, 1 },
    { 1, { {I_IRON_INGOT, 4} },  I_BOOTS_IRON,  1, CAT_TOOLS, 1 },

    /* push3 S2: 8 PLANKS -> 1 CHEST (table). Appended so every older
     * recipe index (and the Tools/Items strips) stays put. */
    { 1, { {B_PLANKS, 8} },      B_CHEST,       1, CAT_BLOCKS, 1 },
    /* push3 S3: 3 IRON INGOTS -> 1 BUCKET (table). Appended; in the Items
     * tab (next to sticks) so the full 13-cell Tools strip is unchanged. */
    { 1, { {I_IRON_INGOT, 3} },  I_BUCKET,      1, CAT_ITEMS,  1 },
};

/* N4 furnace data (declared now so the id space + tables settle once). Each
 * smelt consumes one input id -> one output id; fuels give a burn budget in
 * "items smelted". Consumed by the furnace UI in N4. */
const smelt_t smelts[SMELT_COUNT] = {
    { B_IRON_ORE, I_IRON_INGOT },
    { I_PORKCHOP, I_PORKCHOP_COOKED },
};
const fuel_t fuels[FUEL_COUNT] = {
    { I_COAL, 8 },
    { B_PLANKS, 1 },
};

int craft_list(uint8_t cat, uint8_t *idx)
{
    int n = 0;
    for (int i = 0; i < RECIPE_COUNT; i++)
        if (recipes[i].cat == cat)
            idx[n++] = (uint8_t)i;
    return n;
}

bool craft_can(const recipe_t *r)
{
    for (int i = 0; i < r->n_in; i++)
        if (inv_count(r->in[i].id) < r->in[i].count)
            return false;
    return true;
}

void craft_apply(const recipe_t *r)
{
    for (int i = 0; i < r->n_in; i++)
        inv_remove(r->in[i].id, r->in[i].count);
    inv_add(r->out, r->out_count);
}
