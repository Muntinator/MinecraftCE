/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef PALETTE_H
#define PALETTE_H

#include "common.h"
#include "world.h"

/*
 * Palette layout (M3-compatible):
 *   0..63    base colors (block colors now, texture colors at M3)
 *   +64      bank 1: 80%  (+x / -x faces)
 *   +128     bank 2: 62%  (+z / -z faces)
 *   +192     bank 3: 50%  (-y faces)
 * Bank 0 is full brightness (+y faces). Face color = base | bank << 6.
 */

#define SHADE_TOP    0
#define SHADE_X      1
#define SHADE_Z      2
#define SHADE_BOTTOM 3

#define SHADE_IDX(base, bank) ((uint8_t)((base) | ((bank) << 6)))

#define PAL_SKY   63   /* sky — bank 0 only, banks reuse the slot for UI */
#define PAL_WHITE 62
#define PAL_BLACK 61
/* texture black: tiles' PAL_BLACK texels are remapped here at textures_init.
 * Unlike PAL_BLACK (whose banks are the sky ramp) it is black in EVERY bank,
 * so shaded black texels (leaf gaps, glass, bedrock, TNT) stay black.
 * No convimg texel may land on slot 60 (UI U1: convimg.yaml pins it to a
 * magenta placeholder no texel is near, and max-entries 64 leaves no
 * "(unused)" slot for convimg's duplicate black cluster; palette_build paints
 * 60 black in every bank). host --palcheck guards both. */
#define PAL_TEXBLACK 60

extern const uint8_t block_color[B_COUNT];

/* fills 256 RGB888 triplets; calc converts to 1555, host writes BMP */
void palette_build(uint8_t rgb[256][3]);

extern uint8_t pal_red_idx;   /* reddest palette entry (hearts UI) */
extern uint8_t pal_shadow_idx; /* nearest (63,63,63): MC text shadow of white */

#endif
