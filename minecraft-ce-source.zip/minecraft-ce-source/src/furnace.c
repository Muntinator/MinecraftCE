/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * furnace.c — furnace entities + background smelting. Portable (host-compiled):
 * furnaces_tick runs identically on the calc main loop and in the host --n4
 * test. See furnace.h.
 */

#include "furnace.h"
#include "world.h"
#include "craft.h"
#include "mesh.h"
#include "compose.h"
#include "light.h"
#include <string.h>

furnace_t furnaces[FURNACE_MAX];
chest_t chests[CHEST_MAX];

/* push3 S2: furnace_t and chest_t both start with {active, x, y, z}; one
 * lookup/claim pair serves both arrays. */
static uint8_t *ent_at(uint8_t *e, unsigned sz, uint8_t n,
                       int x, int y, int z)
{
    for (; n; n--, e += sz)
        if (e[0] && e[1] == x && e[2] == y && e[3] == z)
            return e;
    return 0;
}

static uint8_t *ent_create(uint8_t *base, unsigned sz, uint8_t n,
                           int x, int y, int z)
{
    uint8_t *e = ent_at(base, sz, n, x, y, z);
    if (e)
        return e;                       /* already tracked */
    for (e = base; n; n--, e += sz)
        if (!e[0]) {
            memset(e, 0, sz);           /* empty slots, timers 0 */
            e[0] = 1;
            e[1] = (uint8_t)x;
            e[2] = (uint8_t)y;
            e[3] = (uint8_t)z;
            return e;
        }
    return 0;                           /* all in use */
}

void furnaces_reset(void)
{
    memset(furnaces, 0, sizeof furnaces);
}

void chests_reset(void)
{
    memset(chests, 0, sizeof chests);
}

int furnace_smelt_out(uint8_t in_id)
{
    for (int i = 0; i < SMELT_COUNT; i++)
        if (smelts[i].in == in_id)
            return smelts[i].out;
    return 0;
}

int fuel_value(uint8_t id)
{
    for (int i = 0; i < FUEL_COUNT; i++)
        if (fuels[i].id == id)
            return fuels[i].items;
    return 0;
}

furnace_t *furnace_at(int x, int y, int z)
{
    return (furnace_t *)ent_at((uint8_t *)furnaces, sizeof(furnace_t),
                               FURNACE_MAX, x, y, z);
}

furnace_t *furnace_create(int x, int y, int z)
{
    return (furnace_t *)ent_create((uint8_t *)furnaces, sizeof(furnace_t),
                                   FURNACE_MAX, x, y, z);
}

void furnace_remove(int x, int y, int z)
{
    furnace_t *f = furnace_at(x, y, z);
    if (f)
        f->active = 0;
}

chest_t *chest_at(int x, int y, int z)
{
    return (chest_t *)ent_at((uint8_t *)chests, sizeof(chest_t), CHEST_MAX,
                             x, y, z);
}

/* A chest whose cell is no longer B_CHEST (blown up by TNT: explosions do
 * not know about entities) is stale: free it first, so it neither blocks a
 * slot forever nor hands its old contents to a new chest in that cell. */
chest_t *chest_create(int x, int y, int z)
{
    for (chest_t *c = chests; c < chests + CHEST_MAX; c++)
        if (c->active && world_get(c->x, c->y, c->z) != B_CHEST)
            c->active = 0;
    return (chest_t *)ent_create((uint8_t *)chests, sizeof(chest_t),
                                 CHEST_MAX, x, y, z);
}

bool chest_break(int x, int y, int z)
{
    chest_t *c = chest_at(x, y, z);
    if (!c)
        return true;
    bool kept = false;
    if (plr.mode == MODE_SURVIVAL)
        for (slot_t *s = c->slots; s < c->slots + CHEST_SLOTS; s++)
            if (s->count && (s->count = (uint8_t)inv_add(s->id, s->count)))
                kept = true;            /* no room: stays in the chest */
    if (kept)
        return false;
    c->active = 0;
    return true;
}

/* keep the world block id in sync with the burn state; only edits (and dirties
 * the mesh) on a transition so it's cheap to call every tick. Deactivates the
 * entity if its cell is no longer a furnace (defensive). */
static void furnace_set_lit(furnace_t *f, bool lit)
{
    uint8_t cur = world_get(f->x, f->y, f->z);
    if (cur != B_FURNACE && cur != B_FURNACE_LIT) {
        f->active = 0;                   /* cell was overwritten */
        return;
    }
    uint8_t want = lit ? B_FURNACE_LIT : B_FURNACE;
    if (cur == want)
        return;
    world_set(f->x, f->y, f->z, want);   /* the lit-front tile swap: re-mesh */
    /* N5: a lit furnace front is a light source (level FURNACE_LIGHT). Update
     * AFTER the world edit so the incremental flood reads the right block. */
    if (lit)
        light_add_source(f->x, f->y, f->z, FURNACE_LIGHT);
    else
        light_del_source(f->x, f->y, f->z);
    mesh_dirty_block(f->x, f->z);
    compose_add_block(f->x, f->y, f->z);
}

static void furnace_tick_one(furnace_t *f)
{
    uint8_t res = f->in.count ? (uint8_t)furnace_smelt_out(f->in.id) : 0;
    bool has_in = res != 0;
    bool out_ok = has_in &&
                  (f->out.count == 0 ||
                   (f->out.id == res && f->out.count < STACK_MAX));

    /* light (or relight) if idle, smeltable and fuelled */
    if (f->burn == 0 && has_in && out_ok && f->fuel.count) {
        int fv = fuel_value(f->fuel.id);
        if (fv > 0) {
            f->burn_max = (uint16_t)(fv * SMELT_TICKS);
            f->burn = f->burn_max;
            if (--f->fuel.count == 0)
                f->fuel.id = 0;
        }
    }

    if (f->burn > 0) {
        f->burn--;                       /* burns down even if the job stalls */
        if (has_in && out_ok) {
            if (++f->progress >= SMELT_TICKS) {
                f->progress = 0;
                if (--f->in.count == 0)
                    f->in.id = 0;
                if (f->out.count == 0) {
                    f->out.id = res;
                    f->out.count = 1;
                } else {
                    f->out.count++;
                }
            }
        } else {
            f->progress = 0;             /* nothing to smelt: no progress */
        }
    } else {
        f->progress = 0;
    }

    furnace_set_lit(f, f->burn > 0);
}

void furnaces_tick(void)
{
    for (int i = 0; i < FURNACE_MAX; i++)
        if (furnaces[i].active)
            furnace_tick_one(&furnaces[i]);
}
