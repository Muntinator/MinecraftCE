/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * mcfont.c — Minecraft pixel font renderer (see mcfont.h). The glyph table
 * is generated from the official Mojang font (gitignored build input).
 */

#include "mcfont.h"
#include "palette.h"
#include "../gfx/lce/mcfont_data.h"

static int glyph(char c)
{
    unsigned i = (unsigned)(uint8_t)c - MCFONT_FIRST;
    return i < MCFONT_COUNT ? (int)i : -1;
}

int mc_text_width(const char *s, int scale)
{
    int w = 0;
    for (; *s; s++) {
        int g = glyph(*s);
        if (g >= 0)
            w += mcfont_adv[g];
    }
    return w * scale;
}

static void run(uint8_t *fb, int x, int y, const char *s, uint8_t col,
                int scale)
{
    for (; *s; s++) {
        int g = glyph(*s);
        if (g < 0)
            continue;
        const uint8_t *bits = mcfont_bits[g];
        for (int r = 0; r < 8; r++) {
            uint8_t b = bits[r];
            for (int sy = 0; sy < scale; sy++) {
                int py = y + r * scale + sy;
                if (!b || py < 0 || py >= SCREEN_H)
                    continue;
                uint8_t *row = fb + py * SCREEN_W;
                for (int c = 0; c < 8; c++) {
                    if (!(b & (0x80 >> c)))
                        continue;
                    int px = x + c * scale;
                    for (int sx = 0; sx < scale; sx++, px++)
                        if (px >= 0 && px < SCREEN_W)
                            row[px] = col;
                }
            }
        }
        x += mcfont_adv[g] * scale;
    }
}

void mc_text(uint8_t *fb, int x, int y, const char *s, uint8_t colour,
             int scale)
{
    if (colour != PAL_BLACK) {
        uint8_t sh = (colour & 63) == PAL_WHITE ? pal_shadow_idx
                   : SHADE_IDX(colour & 63, 3);
        run(fb, x + scale, y + scale, s, sh, scale);
    }
    run(fb, x, y, s, colour, scale);
}

void mc_text_center(uint8_t *fb, int y, const char *s, uint8_t colour,
                    int scale)
{
    mc_text(fb, SCREEN_W / 2 - mc_text_width(s, scale) / 2, y, s, colour,
            scale);
}
