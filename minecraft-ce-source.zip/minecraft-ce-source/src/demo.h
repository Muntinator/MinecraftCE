/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * demo.h — the deterministic parity frame. Both the calc DEMO build and the
 * host harness compile these exact constants, so their framebuffers must be
 * byte-identical (verified by CRC32C via cemu-autotester).
 */

#ifndef DEMO_H
#define DEMO_H

#include "common.h"

#define DEMO_SEED  0x00C0FFEEu

#define DEMO_CAM_X (16 * FIX_ONE + FIX_ONE / 2)
#define DEMO_CAM_Y (10 * FIX_ONE)
#define DEMO_CAM_Z (4 * FIX_ONE)
#define DEMO_YAW   0
#define DEMO_PITCH (-8)

#endif
