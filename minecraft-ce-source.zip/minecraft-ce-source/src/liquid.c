/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * liquid.c — push3 S3 liquid rules (see liquid.h). Portable: the host
 * --s3liquid scenarios and the calc S3_TEST frame run this exact code.
 */

#include "liquid.h"
#include "world.h"
#include "mesh.h"
#include "compose.h"
#include "light.h"

#ifndef LIQ_LOST
#define LIQ_LOST()             /* host: counts pushes dropped on a full queue */
#endif

/* packed cell: x << 9 | z << 4 | y (5 + 5 + 4 bits) */
static uint16_t liq_q[LIQ_QMAX];
static uint8_t liq_head, liq_n;

/* one out-of-line world_get for every rule below (the inline one costs
 * ~20 B per call site on the eZ80) */
static __attribute__((noinline)) uint8_t lget(int8_t x, int8_t y, int8_t z)
{
    return world_get(x, y, z);
}

static const int8_t nb6[6][3] = {
    {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}, {0, 1, 0}, {0, -1, 0},
};

void liquids_reset(void)
{
    liq_n = 0;
}

static bool in_world(int8_t x, int8_t y, int8_t z)
{
    return (uint8_t)x < WORLD_SX && (uint8_t)y < WORLD_SY &&
           (uint8_t)z < WORLD_SZ;
}

void liquid_push(int x, int y, int z)
{
    if (!in_world(x, y, z))
        return;
    uint16_t c = (uint16_t)((x << 9) | (z << 4) | y);
    for (uint8_t i = 0; i < liq_n; i++)
        if (liq_q[(liq_head + i) & (LIQ_QMAX - 1)] == c)
            return;                     /* already queued */
    if (liq_n == LIQ_QMAX) {
        LIQ_LOST();
        return;
    }
    liq_q[(liq_head + liq_n++) & (LIQ_QMAX - 1)] = c;
}

static bool is_water(uint8_t b) { return b == B_WATER || b == B_WATER_FLOW; }
static bool is_lava(uint8_t b)  { return b == B_LAVA || b == B_LAVA_FLOW; }

/* a liquid may (re)fill this cell */
static bool open_cell(uint8_t b)
{
    return b == B_AIR || b == B_TORCH || b == B_SAPLING ||
           b == B_WATER_FLOW || b == B_LAVA_FLOW;
}

static bool touches(int8_t x, int8_t y, int8_t z, bool lava)
{
    for (uint8_t d = 0; d < 6; d++) {
        uint8_t n = lget(x + nb6[d][0], y + nb6[d][1], z + nb6[d][2]);
        if (lava ? is_lava(n) : is_water(n))
            return true;
    }
    return false;
}

bool liquid_near(int x, int y, int z)
{
    return touches(x, y, z, false) || touches(x, y, z, true);
}

void liquid_set(int x, int y, int z, uint8_t b)
{
    uint8_t old = lget(x, y, z);
    world_set(x, y, z, b);
    mesh_dirty_block(x, z);
    compose_add_block(x, y, z);
    torch_list_del(x, y, z);            /* torch / sapling washed away */
    if (light_emit(old))                /* torch / lava gone: re-flood */
        light_del_source(x, y, z);
    if (light_emit(b))                  /* lava: LIGHT_MAX */
        light_add_source(x, y, z, light_emit(b));
    liquid_push(x, y, z);
}

/* what an open cell holding `cur` should hold, from its neighbours */
static uint8_t want(int8_t x, int8_t y, int8_t z, uint8_t cur)
{
    uint8_t up = lget(x, y + 1, z);
    bool w = is_water(up), l = is_lava(up);
    uint8_t ws = 0;
    for (uint8_t d = 0; d < 4; d++) {
        int8_t nx = x + nb6[d][0], nz = z + nb6[d][2];
        uint8_t n = lget(nx, y, nz);
        if (n != B_WATER && n != B_LAVA)
            continue;
        /* a source over an open cell falls instead of spreading; a flow it
         * already made stays supported (plan: horizontal source = support) */
        if (cur != (n == B_WATER ? B_WATER_FLOW : B_LAVA_FLOW) &&
            open_cell(lget(nx, y - 1, nz)))
            continue;
        if (n == B_WATER) {
            w = true;
            ws++;
        } else {
            l = true;
        }
    }
    if (w && l)
        return B_COBBLE;                /* the flows meet */
    if (w)
        return ws >= 2 && !open_cell(lget(x, y - 1, z)) ? B_WATER
                                                              : B_WATER_FLOW;
    if (l)
        return touches(x, y, z, false) ? B_COBBLE : B_LAVA_FLOW;
    return (cur == B_WATER_FLOW || cur == B_LAVA_FLOW) ? B_AIR : cur;
}

static void eval_open(int8_t x, int8_t y, int8_t z)
{
    if (!in_world(x, y, z))
        return;
    uint8_t b = world[WORLD_IDX(x, y, z)];
    if (!open_cell(b))
        return;
    uint8_t n = want(x, y, z, b);
    if (n != b)
        liquid_set(x, y, z, n);
}

static void eval(int8_t x, int8_t y, int8_t z)
{
    if (!in_world(x, y, z))
        return;
    uint8_t b = world[WORLD_IDX(x, y, z)];
    if (b == B_LAVA && touches(x, y, z, false)) {
        liquid_set(x, y, z, B_OBSIDIAN);
        return;
    }
    if (b == B_WATER || b == B_LAVA) {
        /* a source spreads: down into an open cell, else sideways */
        if (open_cell(lget(x, y - 1, z))) {
            eval_open(x, y - 1, z);
        } else {
            for (uint8_t d = 0; d < 4; d++)
                eval_open(x + nb6[d][0], y, z + nb6[d][2]);
        }
        return;
    }
    eval_open(x, y, z);
}

void liquids_tick(void)
{
    for (int k = 0; k < 4 && liq_n; k++) {
        uint16_t c = liq_q[liq_head];
        liq_head = (uint8_t)((liq_head + 1) & (LIQ_QMAX - 1));
        liq_n--;
        int8_t x = c >> 9, z = (c >> 4) & 31, y = c & 15;
        eval(x, y, z);
        for (uint8_t d = 0; d < 6; d++)
            eval(x + nb6[d][0], y + nb6[d][1], z + nb6[d][2]);
    }
}
