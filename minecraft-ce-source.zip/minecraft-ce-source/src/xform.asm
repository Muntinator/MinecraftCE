; Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
; xform.asm — hand-written eZ80 world->view vertex transform + outcode (M18c).
;
; void xform_asm(int wx, int wy, int wz, v3 *out);
; uint8_t outcode5_asm(const v3 *v);
;
; xform_asm computes EXACTLY the C transform() in render.c, bit-for-bit:
;   dx = (wx<<12) - rcam.cx;  dy = (wy<<12) - rcam.cyy;  dz = (wz<<12) - rcam.cz
;   out.x = fpmul(dx,cy) - fpmul(dz,sy)
;   t     = fpmul(dx,sy) + fpmul(dz,cy)
;   out.z = fpmul(t,cp)  + fpmul(dy,sp)
;   out.y = fpmul(dy,cp) - fpmul(t,sp)
; where fpmul(a,b) = floor((a*b) >> 12).
;
; The multiply core (xf_mulc) is a SPECIALIZED exact-floor 12.12 multiply:
; the second operand is always a camera coefficient sy/cy/sp/cp = a SIN/COS
; lut value in [-4096, 4096], which fits signed 16-bit — so the generic
; 24x24 core of fp_mul (9 partial products) shrinks to a 24x16 core with 6
; partials and a shorter column chain. Semantics are IDENTICAL to fp_mul
; for any 16-bit signed Y:
;   U = a_u * Y_u (unsigned 24x16, 5 product bytes 0..4)
;   a*Y = U - (a<0 ? Y_u<<24 : 0) - (Y<0 ? a_u<<16 : 0)   (mod 2^40)
;   result = product bits 12..35  (floor of the >>12, two's complement)
; — the same sign-correction identity fp_mul uses, one column narrower.
; Column/correction byte math validated exhaustively on the host against
; int64 (all Y in [-4096,4096] x edge a, + 20M random full-range cases)
; and on-calc by the FPTEST vectors (tools/host/genfptest.py).
;
; Operand passing: `a` is staged in the xf_a scratch (IY base), Y travels in
; BC (C=y0, B=y1) and SURVIVES the call — the core never touches BC — so
; multiplies are paired to reuse both operands (4 a-stagings + 6 Y loads
; instead of 8+8 naive):
;   stage dx: P1=dx*cy, P3=dx*sy   stage dz: P2=dz*sy (sy still in BC),
;   P4=dz*cy; x=P1-P2, t=P3+P4     stage t:  P5=t*cp, P8=t*sp
;   stage dy: P6=dy*sp (sp in BC), P7=dy*cp; z=P5+P6, y=P7-P8
;
; Everything runs on the MAIN register bank + private .bss scratch — no
; exx / ex af,af', so no shadow borrow and NO di/ei window is needed (the
; M10 "shadow before di" landmine cannot apply). Not reentrant; fine for
; the single-threaded game (same contract as fpmath.asm).
;
; rcam_t field order (render.h): sy cy sp cp cx cyy cz — each a packed
; 24-bit fix, byte offsets 0 3 6 9 12 15 18. v3 out: x y z at 0 3 6.
; render.c static-asserts sizeof(rcam_t)==21 / sizeof(v3)==9 so a toolchain
; layout change can never silently break these offsets.

assume adl=1

section .bss
private xprod
xprod:  rb 4            ; product bytes 1..4 (bits 8..39) — mul core scratch
private xf_a
xf_a:   rb 3            ; mul operand a (IY base for xf_mulc); Y rides in BC
private dyv
dyv:    rb 3
private dzv
dzv:    rb 3
private pstash
pstash: rb 3            ; first stashed product of a pair
private pstash2
pstash2: rb 3           ; second stashed product
private resbuf
resbuf: rb 9            ; out.x, out.y, out.z assembled before the copy

section .text
public _xform_asm
extern _rcam

; _rcam field offsets
RC_SY  := 0
RC_CY  := 3
RC_SP  := 6
RC_CP  := 9
RC_CX  := 12
RC_CYY := 15
RC_CZ  := 18

_xform_asm:
    push ix                 ; callee-saved (used as the arg frame pointer)
    push iy                 ; callee-saved (used as the xf_mulc operand base)
    ld ix, 6 + 3            ; 2 saved regs (ix,iy) + return address
    add ix, sp              ; ix -> arg0 (wx)

    ; ---- dy = (wy<<12) - rcam.cyy ----
    ld hl, (ix + 3)         ; wy
    call shl12
    ld de, (_rcam + RC_CYY)
    or a, a
    sbc hl, de
    ld (dyv), hl
    ; ---- dz = (wz<<12) - rcam.cz ----
    ld hl, (ix + 6)         ; wz
    call shl12
    ld de, (_rcam + RC_CZ)
    or a, a
    sbc hl, de
    ld (dzv), hl
    ; ---- dx = (wx<<12) - rcam.cx, staged directly as mul operand ----
    ld hl, (ix + 0)         ; wx
    call shl12
    ld de, (_rcam + RC_CX)
    or a, a
    sbc hl, de
    ld (xf_a), hl           ; a = dx

    ld iy, xf_a             ; xf_mulc reads a @ iy+0..2; Y rides in BC

    ; ---- P1 = fpmul(dx,cy), P3 = fpmul(dx,sy) ----
    ld bc, (_rcam + RC_CY)  ; C = cy.0, B = cy.1 (UBC ignored)
    call xf_mulc
    ld (pstash), hl         ; P1
    ld bc, (_rcam + RC_SY)
    call xf_mulc
    ld (pstash2), hl        ; P3

    ; ---- a = dz; P2 = fpmul(dz,sy) (sy still in BC) ----
    ld hl, (dzv)
    ld (xf_a), hl
    call xf_mulc            ; HL = P2
    ex de, hl
    ld hl, (pstash)
    or a, a
    sbc hl, de              ; out.x = P1 - P2
    ld (resbuf + 0), hl

    ; ---- P4 = fpmul(dz,cy); t = P3 + P4, staged directly ----
    ld bc, (_rcam + RC_CY)
    call xf_mulc            ; HL = P4
    ld de, (pstash2)
    add hl, de              ; t
    ld (xf_a), hl           ; a = t

    ; ---- P5 = fpmul(t,cp), P8 = fpmul(t,sp) ----
    ld bc, (_rcam + RC_CP)
    call xf_mulc
    ld (pstash), hl         ; P5
    ld bc, (_rcam + RC_SP)
    call xf_mulc
    ld (pstash2), hl        ; P8

    ; ---- a = dy; P6 = fpmul(dy,sp) (sp still in BC) ----
    ld hl, (dyv)
    ld (xf_a), hl
    call xf_mulc            ; HL = P6
    ld de, (pstash)
    add hl, de              ; out.z = P5 + P6
    ld (resbuf + 6), hl

    ; ---- P7 = fpmul(dy,cp) ----
    ld bc, (_rcam + RC_CP)
    call xf_mulc            ; HL = P7
    ld de, (pstash2)
    or a, a
    sbc hl, de              ; out.y = P7 - P8
    ld (resbuf + 3), hl

    ; ---- copy resbuf (x,y,z) -> *out ----
    ld hl, resbuf
    ld de, (ix + 9)         ; out ptr
    ld bc, 9
    ldir

    pop iy
    pop ix
    ret

; ---------------------------------------------------------------------------
; uint8_t outcode5_asm(const v3 *v);
;
; EXACTLY the C outcode5() in render.c (5 frustum plane tests):
;   z = v->z; wside = z + (z>>4); wvert = (z>>1)+(z>>2)+(z>>4)
;   bit0: z - 1024 < 0        (NEAR_Z)
;   bit1: wside - x < 0       bit2: wside + x < 0
;   bit3: wvert - y < 0       bit4: wvert + y < 0
; >> is ARITHMETIC (floor), done as in-memory sra/rra byte chains.
; Standalone (not fused into xform_asm) so it also serves cache-HIT vectors
; from xform_cached and the mob-face / chunk-corner paths. Result in A.
; Clobbers A,BC,DE,HL,IY (IY caller-saved here — fp_mul sets the precedent).
; Sign tests use sbc/adc hl (which DO set S), never add hl (which doesn't);
; all inputs are within +/-2^22 so bit 23 is a true sign — no overflow case.
; ---------------------------------------------------------------------------
section .bss
private zscr
zscr:   rb 3            ; running z >> k
private wvrt
wvrt:   rb 3            ; wvert accumulator

section .text
public _outcode5_asm

_outcode5_asm:
    ld iy, 3
    add iy, sp
    ld iy, (iy + 0)         ; iy -> v {x @0, y @3, z @6}

    ld hl, (iy + 6)         ; z
    ld (zscr), hl
    call sra_z              ; zscr = z>>1
    ld hl, (zscr)
    ld (wvrt), hl
    call sra_z              ; zscr = z>>2
    ld hl, (zscr)
    ld de, (wvrt)
    add hl, de
    ld (wvrt), hl           ; (z>>1)+(z>>2)
    call sra_z
    call sra_z              ; zscr = z>>4
    ld hl, (zscr)
    ld de, (wvrt)
    add hl, de
    ld (wvrt), hl           ; wvert = (z>>1)+(z>>2)+(z>>4)

    ld c, 0                 ; outcode accumulator

    ; bit0: z < 1024
    ld hl, (iy + 6)
    ld de, 1024
    or a, a
    sbc hl, de
    jp p, .n0
    set 0, c
.n0:
    ; wside = z + (z>>4)  (zscr still holds z>>4)
    ld hl, (iy + 6)
    ld de, (zscr)
    add hl, de              ; HL = wside
    ld de, (iy + 0)         ; DE = x
    ; bit1: wside - x < 0
    push hl                 ; keep wside across the test
    or a, a
    sbc hl, de
    pop hl
    jp p, .n1
    set 1, c
.n1:
    ; bit2: wside + x < 0   (HL = wside, DE = x)
    or a, a
    adc hl, de              ; adc sets S; carry just cleared
    jp p, .n2
    set 2, c
.n2:
    ld de, (iy + 3)         ; DE = y
    ; bit3: wvert - y < 0
    ld hl, (wvrt)
    push hl
    or a, a
    sbc hl, de
    pop hl
    jp p, .n3
    set 3, c
.n3:
    ; bit4: wvert + y < 0   (HL = wvert, DE = y)
    or a, a
    adc hl, de
    jp p, .n4
    set 4, c
.n4:
    ld a, c
    ret

; sra_z: arithmetic shift (zscr) right one bit. Clobbers A + flags.
sra_z:
    ld a, (zscr + 2)
    sra a
    ld (zscr + 2), a
    ld a, (zscr + 1)
    rra
    ld (zscr + 1), a
    ld a, (zscr + 0)
    rra
    ld (zscr + 0), a
    ret

; shl12: HL <<= 12, arithmetic (exact for the guaranteed small signed range,
; |wx| <= ~48). Clobbers only HL + flags.
shl12:
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    ret

; ---------------------------------------------------------------------------
; xf_mulc — HL = floor((a * Y) >> 12) for a = signed 24-bit @ (iy+0..2),
;   Y = signed 16-bit in BC (C = y0, B = y1), |a*Y| < 2^39. See the file
;   header for the derivation. Partial products Q_ij = a_i * y_j land at
;   bytes i+j, i+j+1; product byte0 = Q00.l only (nothing is added to it,
;   so it can never carry out), so the rolling column sum starts at byte1
;   exactly like fp_mul's core:
;     byte1: Q00.h Q01.l Q10.l        byte2: Q01.h Q10.h Q11.l Q20.l
;     byte3: Q11.h Q20.h Q21.l        byte4: Q21.h
;   then the two sign-correction subtracts, then extract bits 12..35 as
;   ((bytes 2..4 as 24-bit) << 4) | (byte1 >> 4) — add hl,hl x4 discards
;   bits 36..39 off the top, which is exactly the truncation wanted.
;   Clobbers A, DE, HL. Preserves BC, IX, IY.
; ---------------------------------------------------------------------------
xf_mulc:
    ld de, 0                ; UDE stays 0 for every 24-bit add below

    ; ---- column 1 (byte1): HL = Q00.h + Q01.l + Q10.l
    ld hl, 0
    ld d, (iy + 0)
    ld e, c
    mlt de                  ; Q00
    ld e, d
    ld d, 0
    add hl, de              ; += Q00.h
    ld d, (iy + 0)
    ld e, b
    mlt de                  ; Q01
    ld d, 0
    add hl, de              ; += Q01.l
    ld d, (iy + 1)
    ld e, c
    mlt de                  ; Q10
    ld d, 0
    add hl, de              ; += Q10.l
    ld a, l
    ld (xprod + 0), a
    ld l, h                 ; carry into column 2
    ld h, 0

    ; ---- column 2 (byte2): += Q01.h Q10.h Q11.l Q20.l
    ld d, (iy + 0)
    ld e, b
    mlt de                  ; Q01
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, c
    mlt de                  ; Q10
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, b
    mlt de                  ; Q11
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, c
    mlt de                  ; Q20
    ld d, 0
    add hl, de
    ld a, l
    ld (xprod + 1), a
    ld l, h
    ld h, 0

    ; ---- column 3 (byte3): += Q11.h Q20.h Q21.l
    ld d, (iy + 1)
    ld e, b
    mlt de                  ; Q11
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, c
    mlt de                  ; Q20
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, b
    mlt de                  ; Q21
    ld d, 0
    add hl, de
    ld a, l
    ld (xprod + 2), a
    ld l, h
    ld h, 0

    ; ---- column 4 (byte4): += Q21.h
    ld d, (iy + 2)
    ld e, b
    mlt de                  ; Q21
    ld e, d
    ld d, 0
    add hl, de
    ld a, l
    ld (xprod + 3), a       ; bits 32..39

    ; ---- corrections (see header identity) ----
    ; a<0: bytes 3..4 -= (y0, y1)
    bit 7, (iy + 2)
    jr z, .a_pos
    ld a, (xprod + 2)
    sub a, c
    ld (xprod + 2), a
    ld a, (xprod + 3)
    sbc a, b
    ld (xprod + 3), a
.a_pos:
    ; Y<0: bytes 2..4 -= (a0, a1, a2)
    bit 7, b
    jr z, .y_pos
    ld a, (xprod + 1)
    sub a, (iy + 0)
    ld (xprod + 1), a
    ld a, (xprod + 2)
    sbc a, (iy + 1)
    ld (xprod + 2), a
    ld a, (xprod + 3)
    sbc a, (iy + 2)
    ld (xprod + 3), a
.y_pos:

    ; ---- extract bits 12..35 = (bytes 2..4 << 4) | (byte1 >> 4) ----
    ld hl, (xprod + 1)      ; product bytes 2..4 = bits 16..39
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl              ; << 4: bits 36..39 fall off the top
    ld a, (xprod + 0)       ; product byte1 = bits 8..15
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    or a, l                 ; low nibble of L is 0 after the shifts
    ld l, a
    ret
