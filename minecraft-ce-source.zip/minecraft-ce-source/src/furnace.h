/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef FURNACE_H
#define FURNACE_H

#include "common.h"
#include "player.h"   /* slot_t */

/*
 * furnace.c — up to FURNACE_MAX (4) live furnace entities. Each owns three slots (input,
 * fuel, output) and two timers (burn = fuel remaining, progress = smelt
 * accumulator). Smelting ticks in the BACKGROUND from the main loop
 * (furnaces_tick, called every player_tick) AND while the furnace UI is open,
 * exactly the same code path. The smelt/fuel tables live in craft.c.
 *
 * A burning furnace swaps its world block id B_FURNACE <-> B_FURNACE_LIT, which
 * re-meshes the block (the lit-front tile swap) via mesh_dirty_block. Pure /
 * portable: the host harness drives furnaces_tick directly.
 */

#define FURNACE_MAX  4    /* push3 S0: was 8; the freed 64 B of .bss fund the
                              S2 chest entities (CHEST_MAX 3) */
#define SMELT_TICKS  120   /* ticks (30Hz) to smelt one item (~4s) */

typedef struct {
    uint8_t active;        /* 1 = a live furnace occupies this slot */
    uint8_t x, y, z;       /* world cell */
    slot_t  in, fuel, out; /* the three furnace slots */
    uint16_t burn;         /* ticks of fuel left in the current burn (0 = out) */
    uint16_t burn_max;     /* burn budget of the last-lit fuel unit (flame gauge) */
    uint16_t progress;     /* smelt accumulator 0..SMELT_TICKS (arrow gauge) */
} furnace_t;

extern furnace_t furnaces[FURNACE_MAX];

/* push3 S2: chest entities. A B_CHEST block owns a chest_t (27 slots, the
 * backpack's size). CHEST_MAX 3 (174 B of .bss): a 4th chest refuses to
 * place (popup), like a 5th furnace. Created on place (or at Skyblock gen,
 * with the starter kit), removed on break (survival: contents go to the
 * inventory first). Saved verbatim in the MC10 tail after furnaces[]. */
#define CHEST_MAX    3
#define CHEST_SLOTS  27

typedef struct {
    uint8_t active;        /* 1 = a live chest occupies this slot */
    uint8_t x, y, z;       /* world cell */
    slot_t  slots[CHEST_SLOTS];
} chest_t;

extern chest_t chests[CHEST_MAX];

void furnaces_reset(void);                         /* clear all (session/init) */
furnace_t *furnace_at(int x, int y, int z);        /* live furnace at cell, or 0 */
furnace_t *furnace_create(int x, int y, int z);    /* on place; 0 if all FURNACE_MAX used */
void furnace_remove(int x, int y, int z);          /* on break */
void furnaces_tick(void);                          /* background smelting, all */

void chests_reset(void);                           /* clear all (world_gen) */
chest_t *chest_at(int x, int y, int z);            /* live chest at cell, or 0 */
chest_t *chest_create(int x, int y, int z);        /* on place; 0 if all CHEST_MAX used */
/* on break: survival moves the contents into the inventory. false = they did
 * not all fit: the chest stays (holding the rest) and must not break. */
bool chest_break(int x, int y, int z);

int furnace_smelt_out(uint8_t in_id);              /* smelt result id, or 0 */
int fuel_value(uint8_t id);                        /* smelts per fuel unit, or 0 */

#endif
