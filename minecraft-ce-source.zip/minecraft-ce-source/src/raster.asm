; Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
; raster.asm — textured span inner loop.
;
; void span_tex_asm(uint8_t *dst, uint8_t count, int u, int v,
;                   int du, int dv, uint8_t bank);
;
; Samples the 16x16 texture in the 256-aligned page at (_tpage_ptr):
;   texel = page[((v >> 8) & 15) << 4 | ((u >> 8) & 15)] | bank
; u, v are 12.12-style uv units (1 texel = 1<<8) — the nibble of byte 1
; is the texel coordinate, which is what makes this loop cheap.
; count <= 255 (C wrapper splits longer spans). Not reentrant (SMC bank).

assume adl=1

section .text
public _span_tex_asm
extern _tpage_ptr

_span_tex_asm:
    di                      ; OS interrupts use the shadow bank; keep them
                            ; out for the WHOLE time we borrow it
    ; ez80-clang keeps caller values in the shadow set — preserve it
    exx
    push hl
    push de
    exx
    push iy                 ; IY is callee-saved in the CE ABI
    ld iy, 9 + 3            ; saved regs (3x3 bytes) + return address
    add iy, sp
    push ix
    ld ix, (iy + 0)         ; dst
    ld b, (iy + 3)          ; count
    ld a, (iy + 18)         ; bank -> patch the OR immediate
    ld (.smc_bank + 1), a
    ld hl, (iy + 6)         ; u
    ld de, (iy + 12)        ; du
    exx
    ld hl, (iy + 9)         ; v
    ld de, (iy + 15)        ; dv
    exx
    ld iy, (_tpage_ptr)     ; 256-aligned texture page; iyl = index below

.loop:
    exx                     ; v side
    ld a, h                 ; v byte1 (pre-step)
    add hl, de              ; v += dv
    exx
    rlca                    ; low nibble -> high nibble
    rlca
    rlca
    rlca
    and a, 0F0h
    ld c, a
    ld a, h                 ; u byte1 (pre-step)
    and a, 0Fh
    or a, c                 ; texel index
    ld iyl, a
    add hl, de              ; u += du
    ld a, (iy)
.smc_bank:
    or a, 0
    ld (ix), a
    inc ix
    djnz .loop

    pop ix
    pop iy
    exx
    pop de
    pop hl
    exx
    ei
    ret
