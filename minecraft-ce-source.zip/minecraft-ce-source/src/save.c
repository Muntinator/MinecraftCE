/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * save.c — world persistence (push3 SV, format MC10).
 *
 * A save is one IMAGE (header + sections, built in render_scratch) split
 * into AppVar parts of at most SAVE_PART bytes named "MCW<slot><bank><k>"
 * (MCW1A0, MCW1A1, ...). Every part is archived before the next one is
 * created, so RAM only ever holds one part. (MC09 built the whole ~13 KB
 * save in ONE RAM AppVar; in game only ~10.6 KB is free, so it truncated.)
 *
 * Atomic: each slot has two banks, A and B. A save writes the bank that is
 * NOT live, reads it back from the archive and verifies it (magic, part
 * count, total length, Fletcher-16 over the whole image), and only then
 * deletes the old bank. The loader takes the valid bank; if both are valid
 * (a crash between verify and cleanup) the newer generation wins. So a
 * failure or crash at any point leaves the previous save loadable. No
 * ti_Rename: renaming an ARCHIVED var needs free RAM >= its size, and when
 * RAM is short TI-OS throws ERR:MEMORY and ends the program instead of
 * returning an error (measured in CEmu, push3-log SV).
 *
 * Image: save_hdr_t, the world in LAYER order RLE (savefmt.c; raw when RLE
 * is not smaller), world_height RLE (or raw), hotbar, main_inv, armor
 * ({id,count} pairs), furnaces[] verbatim, chests[] verbatim (S2).
 *
 * Legacy: a single-var "MCWORLDn" MC09 save (memory-order RLE) still loads,
 * as worldtype 0; the first MC10 save of that slot deletes it.
 */

#include <stddef.h>
#include <string.h>

#include "save.h"
#include "savefmt.h"
#include "world.h"
#include "player.h"
#include "render.h"
#include "mob.h"
#include "furnace.h"

uint8_t g_daynight = 1;   /* 0 off, 1 normal, 2 fast */
uint8_t g_save_slot = 1;  /* active world slot, 1..3 */

uint32_t world_seed;

#if defined(__ez80__) || defined(HOST_TIFILE)

#ifdef __ez80__
#include <fileioc.h>
#endif  /* host: tools/host/timock.h (the harness includes it first) */

#define SAVE_MAGIC   0x4D433130u   /* "MC10" */
#define LEGACY_MAGIC 0x4D433039u   /* "MC09" */

/* The first LEGACY_HDR bytes are the MC09 header verbatim (so an MC09
 * save's header is read in place); MC10 appends its fields after it. */
typedef struct {
    uint32_t magic;
    uint32_t seed;
    int32_t px, py, pz;
    uint8_t yaw;
    int8_t pitch;
    uint8_t mode;
    uint8_t hotbar_sel;
    uint8_t unused[5];           /* MC09 prefs copies (MCPREFS has them) */
    int8_t health;
    uint8_t hunger;
    uint8_t saturation;
    uint8_t flags;               /* SF_*; MC09 "raw" (1 = world raw) */
    uint16_t wlen;               /* world section bytes; MC09 rle_len */
    /* ---- MC10 ---- */
    uint16_t hlen;               /* world_height section bytes */
    uint16_t total;              /* image bytes, this header included */
    uint16_t sum;                /* Fletcher-16 of the image with sum = 0 */
    uint8_t parts;               /* AppVars in this bank */
    uint8_t gen;                 /* bank generation: newer valid bank wins */
    uint8_t worldtype;           /* g_worldtype (0 normal, 1 superflat, 2 skyblock) */
} save_hdr_t;

#define LEGACY_HDR offsetof(save_hdr_t, hlen)   /* 35 B on the calc */
#define SF_WORLD_RAW  1
#define SF_HEIGHT_RAW 2
#define SF_MEMORDER   4          /* load-side only: MC09 memory-order RLE */

/* The image lives in the renderer's scaled-frame buffer (19200 B): save and
 * load never run mid-frame and the caller redraws everything afterwards;
 * .bss has no room for another big buffer. */
#define img render_scratch
#define SAVE_CAP ((unsigned)(SCREEN_W / 2) * (SCREEN_H / 2))
#define SAVE_MAXPARTS ((SAVE_CAP + SAVE_PART - 1) / SAVE_PART)  /* 19 */
#define HDR ((save_hdr_t *)img)

/* header fields <-> game state, and the image tail (verbatim arrays) */
typedef struct {
    void *var;
    uint8_t off, n;
} hfield_t;
#define HF(v, f) { &(v), offsetof(save_hdr_t, f), sizeof(v) }
static const hfield_t hfields[] = {
    HF(world_seed, seed), HF(plr.x, px), HF(plr.y, py), HF(plr.z, pz),
    HF(plr.yaw, yaw), HF(plr.pitch, pitch), HF(plr.mode, mode),
    HF(plr.hotbar_sel, hotbar_sel), HF(plr.health, health),
    HF(plr.hunger, hunger), HF(plr.saturation, saturation),
    HF(g_worldtype, worldtype),
};
typedef struct {
    void *var;
    uint16_t n;
} tfield_t;
static const tfield_t tfields[] = {
    { plr.hotbar, sizeof plr.hotbar }, { plr.main_inv, sizeof plr.main_inv },
    { plr.armor, sizeof plr.armor }, { furnaces, sizeof furnaces },
    { chests, sizeof chests },      /* push3 S2 (older MC10 tails: none) */
};
#define NELEM(a) (sizeof(a) / sizeof((a)[0]))

static char pname[9];

/* "MCW<slot><A|B><k>", k = 0..9 then A.. */
static const char *part_name(uint8_t slot, uint8_t bank, uint8_t k)
{
    memcpy(pname, "MCW", 3);
    pname[3] = (char)('0' + slot);
    pname[4] = (char)('A' + bank);
    pname[5] = (char)(k < 10 ? '0' + k : 'A' - 10 + k);
    pname[6] = 0;
    return pname;
}

/* the legacy single-var name "MCWORLDn" */
static const char *world_name(int slot)
{
    memcpy(pname, "MCWORLD", 7);
    pname[7] = (char)('0' + slot);
    pname[8] = 0;
    return pname;
}

/* read every part of a bank into img; true iff it is a complete, valid
 * MC10 image */
static bool bank_read(uint8_t slot, uint8_t bank)
{
    unsigned got = 0;
    uint8_t parts = 1;
    for (uint8_t k = 0; k < parts; k++) {
        uint8_t f = ti_Open(part_name(slot, bank, k), "r");
        if (!f)
            return false;
        unsigned n = ti_GetSize(f);
        bool ok = n && got + n <= SAVE_CAP &&
                  ti_Read(img + got, n, 1, f) == 1;
        ti_Close(f);
        if (!ok)
            return false;
        got += n;
        if (k == 0) {
            if (got < sizeof(save_hdr_t) || HDR->magic != SAVE_MAGIC ||
                !HDR->parts || HDR->parts > SAVE_MAXPARTS)
                return false;
            parts = HDR->parts;
        }
    }
    if (got != HDR->total)
        return false;
    uint16_t s = HDR->sum;
    HDR->sum = 0;
    uint16_t c = sf_fletcher16(img, got);
    HDR->sum = s;
    return c == s;
}

/* the live bank of a slot, -1 = none valid; *gen = its generation */
static int8_t live_bank(uint8_t slot, uint8_t *gen)
{
    int8_t best = -1;
    uint8_t bg = 0;
    for (uint8_t b = 0; b < 2; b++) {
        if (!bank_read(slot, b))
            continue;
        uint8_t g = HDR->gen;
        if (best < 0 || (int8_t)(g - bg) > 0) {
            best = (int8_t)b;
            bg = g;
        }
    }
    *gen = bg;
    return best;
}

/* delete every possible part of a bank (absent names are fine) */
static void bank_clear(uint8_t slot, uint8_t bank)
{
    for (uint8_t k = 0; k < SAVE_MAXPARTS; k++)
        ti_Delete(part_name(slot, bank, k));
}

/* one part: create in RAM, write, archive, close; every return checked */
static bool write_part(const char *name, const uint8_t *p, unsigned n)
{
    uint8_t f = ti_Open(name, "w");
    if (!f)
        return false;
    bool ok = ti_Write(p, n, 1, f) == 1 && ti_SetArchiveStatus(true, f);
    if (!ti_Close(f))
        ok = false;
    return ok;
}

/* build the MC10 image in img (total/parts/gen/sum filled by the caller);
 * returns its length */
static unsigned build_image(void)
{
    save_hdr_t *h = HDR;
    memset(h, 0, sizeof *h);
    h->magic = SAVE_MAGIC;
    for (uint8_t i = 0; i < NELEM(hfields); i++)
        memcpy(img + hfields[i].off, hfields[i].var, hfields[i].n);

    uint8_t *p = img + sizeof *h;
    /* RLE is kept only when it is smaller than the raw array */
    unsigned n = sf_rle_enc(p, sizeof world - 1, world, WORLD_SY,
                            WORLD_SX * WORLD_SZ, WORLD_SY);
    if (!n) {
        memcpy(p, world, sizeof world);
        n = sizeof world;
        h->flags |= SF_WORLD_RAW;
    }
    h->wlen = (uint16_t)n;
    p += n;
    n = sf_rle_enc(p, sizeof world_height - 1, world_height, 1,
                   sizeof world_height, 1);
    if (!n) {
        memcpy(p, world_height, sizeof world_height);
        n = sizeof world_height;
        h->flags |= SF_HEIGHT_RAW;
    }
    h->hlen = (uint16_t)n;
    p += n;
    for (uint8_t i = 0; i < NELEM(tfields); i++) {
        memcpy(p, tfields[i].var, tfields[i].n);
        p += tfields[i].n;
    }
    return (unsigned)(p - img);
}

bool save_world(void)
{
    uint8_t slot = g_save_slot, gen;
    int8_t live = live_bank(slot, &gen);
    uint8_t bank = live == 0 ? 1 : 0;      /* never touch the live bank */

    unsigned total = build_image();
    uint8_t parts = (uint8_t)((total + SAVE_PART - 1) / SAVE_PART);
    HDR->total = (uint16_t)total;
    HDR->parts = parts;
    HDR->gen = live < 0 ? 0 : (uint8_t)(gen + 1);
    HDR->sum = sf_fletcher16(img, total);

    bank_clear(slot, bank);                /* leftovers of a failed save */
    bool ok = true;
    for (uint8_t k = 0; ok && k < parts; k++) {
        unsigned off = (unsigned)k * SAVE_PART;
        unsigned n = total - off < SAVE_PART ? total - off : SAVE_PART;
        ok = write_part(part_name(slot, bank, k), img + off, n);
    }
    /* verify from the archive (refills img with the same bytes) */
    if (!ok || !bank_read(slot, bank)) {
        bank_clear(slot, bank);
        return false;
    }
    /* committed: the new bank is valid and newer. Drop the old bank and a
     * legacy MC09 var; a failure here only leaves older data behind. */
    if (live >= 0)
        bank_clear(slot, (uint8_t)live);
    ti_Delete(world_name(slot));
    return true;
}

/* Fetch a slot's save into img as an MC10-shaped image: a verified bank,
 * or an MC09 var whose body is shifted up behind a completed header.
 * Returns the image length, 0 = no loadable header. */
static unsigned fetch(uint8_t slot)
{
    uint8_t gen;
    int8_t b = live_bank(slot, &gen);
    /* img already holds bank 1 when it won; bank 0 must be re-read */
    if (b == 1 || (b == 0 && bank_read(slot, 0)))
        return HDR->total;
    uint8_t f = ti_Open(world_name(slot), "r");
    if (!f)
        return 0;
    unsigned n = ti_GetSize(f);
    const unsigned shift = sizeof(save_hdr_t) - LEGACY_HDR;
    bool ok = n >= LEGACY_HDR && n + shift <= SAVE_CAP &&
              ti_Read(img, n, 1, f) == 1;
    ti_Close(f);
    if (!ok || HDR->magic != LEGACY_MAGIC)
        return 0;
    memmove(img + sizeof(save_hdr_t), img + LEGACY_HDR, n - LEGACY_HDR);
    save_hdr_t *h = HDR;
    if (h->flags) {
        h->flags = SF_WORLD_RAW | SF_HEIGHT_RAW;
        h->wlen = sizeof world;
    } else {
        h->flags = SF_MEMORDER | SF_HEIGHT_RAW;
    }
    h->hlen = sizeof world_height;
    h->worldtype = 0;
    return n + shift;
}

bool load_world(void)
{
    unsigned total = fetch(g_save_slot);
    const save_hdr_t *h = HDR;
    if (!total || sizeof *h + h->wlen + h->hlen > total)
        return false;
    unsigned avail = total - sizeof *h - h->wlen - h->hlen;
    const uint8_t *p = img + sizeof *h;
    if (h->flags & SF_WORLD_RAW) {
        if (h->wlen != sizeof world)
            return false;
        memcpy(world, p, sizeof world);
    } else if (!((h->flags & SF_MEMORDER)   /* MC09: memory order */
                 ? sf_rle_dec(p, h->wlen, world, 1, sizeof world, 1)
                 : sf_rle_dec(p, h->wlen, world, WORLD_SY,
                              WORLD_SX * WORLD_SZ, WORLD_SY))) {
        return false;
    }
    p += h->wlen;
    /* the frozen gen-time terrain line (edits never touch it; a rebuild
     * would fold builds into it and corrupt the cave-cull rule) */
    if (h->flags & SF_HEIGHT_RAW) {
        if (h->hlen != sizeof world_height)
            return false;
        memcpy(world_height, p, sizeof world_height);
    } else if (!sf_rle_dec(p, h->hlen, world_height, 1,
                           sizeof world_height, 1)) {
        return false;
    }
    p += h->hlen;
    /* slot arrays + furnace entities, zeroed first so a short MC09 tail
     * leaves the rest empty; furnaces_tick reconciles each lit block id
     * with its burn state */
    for (uint8_t i = 0; i < NELEM(tfields); i++) {
        unsigned n = tfields[i].n < avail ? tfields[i].n : avail;
        memset(tfields[i].var, 0, tfields[i].n);
        memcpy(tfields[i].var, p, n);
        p += n;
        avail -= n;
    }
    for (uint8_t i = 0; i < NELEM(hfields); i++)
        memcpy(hfields[i].var, img + hfields[i].off, hfields[i].n);
    /* N6: survival stats clamped; transient hunger timers reset */
    if (plr.health > 10) plr.health = 10;
    if (plr.health < 0) plr.health = 0;
    if (plr.hunger > HUNGER_MAX || !g_hunger_drain)
        plr.hunger = HUNGER_MAX;
    plr.exhaustion = 0;
    plr.hunger_timer = plr.regen_timer = plr.starve_timer = 0;
    return true;
}

/* peek a slot for the Continue page (does not touch plr/world; uses img).
 * MC10: a fully verified bank; MC09: header magic only (a truncated MC09
 * save is listed, then load_world reports it). */
uint8_t slot_info(int slot, uint32_t *seed, uint8_t *mode)
{
    if (!fetch((uint8_t)slot))
        return 0;
    if (seed) *seed = HDR->seed;
    if (mode) *mode = HDR->mode;
    return (uint8_t)(1 + HDR->worldtype);
}

bool save_exists(void)
{
    return slot_info(g_save_slot, NULL, NULL);
}

#define PREFS_MAGIC 0x4D435033u   /* "MCP3" (older prefs are discarded — adds
                                     the auto-jump toggle) */

typedef struct {
    uint32_t magic;
    uint8_t radius, daynight, mobs_on, textures, fastgfx, viewport, autojump;
} prefs_t;

void prefs_save(void)
{
    prefs_t p;
    p.magic = PREFS_MAGIC;
    p.radius = view_radius;
    p.daynight = g_daynight;
    p.mobs_on = g_mobs_on;
    p.textures = g_textures;
    p.fastgfx = g_gfxmode;
    p.viewport = g_viewport;
    p.autojump = g_autojump;
    uint8_t f = ti_Open("MCPREFS", "w");
    if (!f)
        return;
    bool ok = ti_Write(&p, sizeof p, 1, f) == 1 && ti_SetArchiveStatus(true, f);
    if (!ti_Close(f) || !ok)
        ti_Delete("MCPREFS");     /* a partial prefs var would be ignored
                                     anyway; defaults next boot */
}

void prefs_load(void)
{
    uint8_t f = ti_Open("MCPREFS", "r");
    if (!f)
        return;
    prefs_t p;
    if (ti_Read(&p, sizeof p, 1, f) == 1 && p.magic == PREFS_MAGIC) {
        view_radius = p.radius ? p.radius : 10;
        g_daynight = p.daynight;
        g_mobs_on = p.mobs_on;
        g_textures = p.textures;
        g_gfxmode = p.fastgfx > 2 ? 1 : p.fastgfx;
        g_viewport = p.viewport > 2 ? 0 : p.viewport;
        g_autojump = p.autojump ? 1 : 0;
    }
    ti_Close(f);
}

#else

bool save_world(void) { return true; }
bool load_world(void) { return false; }
bool save_exists(void) { return false; }
uint8_t slot_info(int slot, uint32_t *seed, uint8_t *mode)
{ (void)slot; (void)seed; (void)mode; return 0; }
void prefs_save(void) {}
void prefs_load(void) {}

#endif
