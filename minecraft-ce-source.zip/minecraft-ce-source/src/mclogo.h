/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef MCLOGO_H
#define MCLOGO_H
#include <stdint.h>
#define MCLOGO_W 280
#define MCLOGO_ROWS 55
/* push3 DIET: ZX0-compressed MCLOGO_W x MCLOGO_ROWS index bitmap (255 =
 * transparent); ui_logo decodes it into render_scratch before the blit */
extern const unsigned char mclogo_zx0[];
#endif
