; Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
; project.asm — hand-written eZ80 fused perspective-divide + project (Stage P).
;
; void project_asm(const v3 *v, int *sx, int *sy);
;
; Computes EXACTLY the C in render.c's projection sites, bit-for-bit:
;   recip = fp_div(rfocal << 6, v->z);          ; trunc; v->z > NEAR_Z always
;   *sx   = rcx + (fp_mul(v->x, recip) >> 6);    ; arithmetic (floor) >> 6
;   *sy   = rcy - (fp_mul(v->y, recip) >> 6);    ; arithmetic (floor) >> 6
; where fp_mul = floor((a*b)>>12), fp_div = trunc((a<<12)/b). v3 x@0 y@3 z@6.
;
; P-b form (shipped): the fp_div core and the fp_mul core are INLINED — no
; external _fp_div/_fp_mul calls, no per-sub-call stack arg marshalling, and
; the shared `recip` is staged once as the second multiply operand and reused
; by both multiplies. This kills all the per-vertex call/return + push/pop
; overhead the three separate C calls paid.
;
; The div core is the POSITIVE-ONLY specialization of fpmath.asm's fp_div:
; both operands are provably > 0 (rfocal = FOCAL/rscale > 0; v->z > NEAR_Z),
; so the sign test / |a| / |b| negations and the final sign-apply all drop —
; fp_div's positive branch verbatim, giving trunc((a<<12)/b) bit-for-bit.
; The mul core is fpmath.asm's fp_mul core verbatim (full 24x24, 8 partials,
; both sign corrections kept — recip is positive but v->x/v->y are signed),
; reading X @ (iy+0..2) and Y=recip @ (iy+3..5) from the m_ops scratch.
;
; ABI copies xform.asm: args on the stack, `ld ix,N ; add ix,sp`; IX callee-
; saved (frame pointer); A/BC/DE/HL/IY caller scratch. MAIN bank only +
; private .bss scratch — no exx/ex af,af', so NO di/ei window is needed (the
; M10 shadow landmine is structurally absent). Not reentrant; fine for the
; single-threaded game (same contract as fpmath.asm / xform.asm).

assume adl=1

section .bss
private m_ops
m_ops:  rb 6           ; multiply operands: X @0..2, Y (recip) @3..5
private vy_s
vy_s:   rb 3           ; stashed v->y for the second multiply
private dvd
dvd:    rb 3           ; div |a| scratch (fp_div's "outb" role)
private prodp
prodp:  rb 4           ; product bytes 1..4 (mul) / S-assembly temp (div)
private outp
outp:   rb 3           ; assembled mul result (fp_mul's "outb" role)
private shf
shf:    rb 3           ; asr6 scratch

section .text
public _project_asm
extern _rfocal
extern _rcx
extern _rcy

_project_asm:
    push ix
    ld ix, 3 + 3           ; 1 saved reg (ix) + return address
    add ix, sp            ; ix -> arg0 (v ptr) @ ix+0, sx @ ix+3, sy @ ix+6

    ld iy, (ix + 0)        ; iy -> v {x@0, y@3, z@6}
    ld hl, (iy + 3)
    ld (vy_s), hl         ; stash v->y for the 2nd multiply
    ld hl, (iy + 0)
    ld (m_ops + 0), hl    ; X operand of the 1st multiply = v->x
    ld bc, (iy + 6)        ; BC = v->z = |b| (divisor, positive)

    ; ================= inline fp_div (positive-only) =================
    ; a = rfocal << 6 (positive, small); recip = trunc((a<<12)/v->z)
    ld hl, (_rfocal)
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl             ; HL = rfocal << 6 = |a|
    ld (dvd), hl

    ; R (HL) = |a| >> 12 = (a2 << 4) | (a1 >> 4)
    ld hl, 0
    ld a, (dvd + 1)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld d, a
    ld a, (dvd + 2)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, d
    ld l, a
    ld a, (dvd + 2)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld h, a                ; UHL = 0 from ld hl,0

    ; S (DE) = (|a| & 0xFFF) << 12
    ld de, 0
    ld a, (dvd + 0)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    ld d, a                ; s1 = a0 << 4
    ld a, (dvd + 0)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld e, a                ; temp: a0 >> 4
    ld a, (dvd + 1)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, e                ; s2 = (a1 & 0xF) << 4 | (a0 >> 4)
    ld (dvd + 0), a        ; stash s2
    ld a, d
    ld (prodp + 0), a      ; stash s1
    ld de, 0
    ld a, (prodp + 0)
    ld d, a
    ld a, (dvd + 0)
    ld (prodp + 1), a
    xor a, a
    ld (prodp + 2), a
    xor a, a
    ld (dvd + 0), a
    ld a, (prodp + 0)
    ld (dvd + 1), a
    ld a, (prodp + 1)
    ld (dvd + 2), a
    ld de, (dvd)           ; S ready

    ; 24 restoring iterations; BC = |b|; carry = previous quotient bit
    ld iyl, 24
    or a, a
.dloop:
    ex de, hl
    adc hl, hl             ; S = S<<1 | qprev; carry out = stream bit
    ex de, hl
    adc hl, hl             ; R = R<<1 | streambit
    or a, a
    sbc hl, bc             ; R -= |b|
    jr nc, .dq1
    add hl, bc             ; restore; carry := 0
    or a, a
    jr .dnext
.dq1:
    scf                    ; quotient bit 1
.dnext:
    dec iyl
    jr nz, .dloop
    ex de, hl
    adc hl, hl             ; final quotient bit -> HL = recip (positive)
    ld (m_ops + 3), hl     ; Y operand (recip), shared by both multiplies

    ; ================= *sx = rcx + (fp_mul(v->x, recip) >> 6) =========
    ld iy, m_ops           ; X @ iy+0..2 (v->x), Y @ iy+3..5 (recip)
    call mulcore           ; HL = fp_mul(v->x, recip)
    call asr6              ; HL >>= 6 (arithmetic)
    ld de, (_rcx)
    add hl, de
    ld iy, (ix + 3)
    ld (iy + 0), hl        ; *sx

    ; ================= *sy = rcy - (fp_mul(v->y, recip) >> 6) =========
    ld hl, (vy_s)
    ld (m_ops + 0), hl     ; X operand = v->y (recip still staged @ m_ops+3)
    ld iy, m_ops
    call mulcore           ; HL = fp_mul(v->y, recip)
    call asr6
    ex de, hl              ; DE = shifted term
    ld hl, (_rcy)
    or a, a
    sbc hl, de
    ld iy, (ix + 6)
    ld (iy + 0), hl        ; *sy

    pop ix
    ret

; ---------------------------------------------------------------------------
; mulcore — HL = floor((X * Y) >> 12), X @ (iy+0..2), Y @ (iy+3..5), both
; signed 24-bit, |X*Y| < 2^39. fpmath.asm's fp_mul core verbatim (8 partial
; products P(i,j)=Xi*Yj, two sign corrections, extract bits 12..35).
; Clobbers A, BC, DE, HL. Preserves IX, IY.
; ---------------------------------------------------------------------------
mulcore:
    ld de, 0                ; UDE stays 0 for every 24-bit add below

    ; ---- column 1: HL = P00.h + P01.l + P10.l
    ld hl, 0
    ld d, (iy + 0)
    ld e, (iy + 3)
    mlt de                  ; P00
    ld e, d
    ld d, 0
    add hl, de              ; += P00.h
    ld d, (iy + 0)
    ld e, (iy + 4)
    mlt de                  ; P01
    ld d, 0
    add hl, de              ; += P01.l
    ld d, (iy + 1)
    ld e, (iy + 3)
    mlt de                  ; P10
    ld d, 0
    add hl, de              ; += P10.l
    ld a, l
    ld (prodp + 0), a
    ld l, h
    ld h, 0

    ; ---- column 2: += P01.h P10.h P02.l P11.l P20.l
    ld d, (iy + 0)
    ld e, (iy + 4)
    mlt de                  ; P01
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 3)
    mlt de                  ; P10
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 0)
    ld e, (iy + 5)
    mlt de                  ; P02
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 4)
    mlt de                  ; P11
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 3)
    mlt de                  ; P20
    ld d, 0
    add hl, de
    ld a, l
    ld (prodp + 1), a
    ld l, h
    ld h, 0

    ; ---- column 3: += P02.h P11.h P20.h P12.l P21.l
    ld d, (iy + 0)
    ld e, (iy + 5)
    mlt de                  ; P02
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 4)
    mlt de                  ; P11
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 3)
    mlt de                  ; P20
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 5)
    mlt de                  ; P12
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 4)
    mlt de                  ; P21
    ld d, 0
    add hl, de
    ld a, l
    ld (prodp + 2), a
    ld l, h
    ld h, 0

    ; ---- column 4: += P12.h P21.h P22.l
    ld d, (iy + 1)
    ld e, (iy + 5)
    mlt de                  ; P12
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 4)
    mlt de                  ; P21
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 5)
    mlt de                  ; P22
    ld d, 0
    add hl, de
    ld a, l
    ld (prodp + 3), a       ; bits 32..39

    ; ---- signed correction: bits 24..39 -= (X<0 ? Y : 0) + (Y<0 ? X : 0)
    bit 7, (iy + 2)
    jr z, .x_pos
    ld a, (prodp + 2)
    sub a, (iy + 3)
    ld (prodp + 2), a
    ld a, (prodp + 3)
    sbc a, (iy + 4)
    ld (prodp + 3), a
.x_pos:
    bit 7, (iy + 5)
    jr z, .y_pos
    ld a, (prodp + 2)
    sub a, (iy + 0)
    ld (prodp + 2), a
    ld a, (prodp + 3)
    sbc a, (iy + 1)
    ld (prodp + 3), a
.y_pos:

    ; ---- extract bits 12..35: out[k] = (prod[k] >> 4) | (prod[k+1] << 4)
    ld a, (prodp + 0)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld b, a
    ld a, (prodp + 1)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, b
    ld (outp + 0), a

    ld a, (prodp + 1)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld b, a
    ld a, (prodp + 2)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, b
    ld (outp + 1), a

    ld a, (prodp + 2)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld b, a
    ld a, (prodp + 3)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, b
    ld (outp + 2), a

    ld hl, (outp)
    ret

; asr6 — HL = HL >> 6, ARITHMETIC (floor). |HL| < 2^23 so bit 23 is a true
; sign; in-memory sra/rra byte chain (like xform.asm's sra_z). Clobbers A, B,
; flags; preserves DE, IX, IY.
asr6:
    ld (shf), hl
    ld b, 6
.sh:
    ld a, (shf + 2)
    sra a
    ld (shf + 2), a
    ld a, (shf + 1)
    rra
    ld (shf + 1), a
    ld a, (shf + 0)
    rra
    ld (shf + 0), a
    djnz .sh
    ld hl, (shf)
    ret
