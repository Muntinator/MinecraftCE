/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef LUT_H
#define LUT_H

#include "common.h"

/* sin(2*pi*i/256) * 4096, 256-step angle */
extern const int16_t sin_lut[256];

#define SIN(a) ((fix)sin_lut[(uint8_t)(a)])
#define COS(a) ((fix)sin_lut[(uint8_t)((a) + 64)])

#endif
