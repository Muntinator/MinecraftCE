/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef INVPANEL_H
#define INVPANEL_H
#include <stdint.h>
#define INVPANEL_W 175
#define INVPANEL_H_PX 165
#define INVPANEL_X 72
#define INVPANEL_Y 37
extern const unsigned char invpanel_rle[];
extern const unsigned int invpanel_rle_len;
extern const unsigned char hotslot[400];
#endif
