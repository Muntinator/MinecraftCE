/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * player.c — physics, DDA block picking, break/place. Portable: runs
 * identically on host (playback parity) and calc. All math is fix/int24
 * safe per the common.h contract.
 */

#include "player.h"
#include "world.h"
#include "mesh.h"
#include "mob.h"
#include "drop.h"
#include "compose.h"
#include "furnace.h"
#include "light.h"
#include "lut.h"
#include "liquid.h"

player_t plr;
uint8_t g_autojump;  /* settings toggle: hop 1-block steps automatically */
uint8_t tnt_flash;   /* frames of white flash left; set by explosions */
uint8_t hurt_flash;  /* frames of red tint left; set on player damage */
uint8_t g_died;
/* Hunger drain switch (owner call 2026-09-23): pigs are too rare to feed on
 * yet, so the food bar stays full. 0 = no exhaustion ever drains food (so no
 * starvation; regen still heals while fed); a save loads with a full bar.
 * The N6 logic is intact: host --n6 turns it on and tests it. */
uint8_t g_hunger_drain;      /* set on death; the shell shows YOU DIED */

const uint8_t hotbar_blocks[HOTBAR_SLOTS] = {
    B_GRASS, B_DIRT, B_STONE, B_COBBLE, B_PLANKS,
    B_LOG, B_LEAVES, B_SAND, B_TNT,
};

/* per-block break time in ticks (30Hz), survival mode; 0 = instant */
static const uint8_t break_time[B_COUNT] = {
    0,   /* air */
    18,  /* grass */
    15,  /* dirt */
    45,  /* stone */
    45,  /* cobble */
    36,  /* log */
    6,   /* leaves */
    30,  /* planks */
    12,  /* sand */
    0,   /* water (never targeted) */
    8,   /* glass */
    255, /* bedrock: unbreakable in survival */
    3,   /* tnt */
    60,  /* coal ore */
    75,  /* iron ore */
    30,  /* crafting table (wood) */
    45,  /* furnace (stone) */
    0,   /* torch (instant) */
    45,  /* furnace_lit (same as furnace) */
    30,  /* chest (wood, axe-class like the table) */
    0,   /* water_flow (never targeted: the ray passes liquids) */
    0,   /* lava       (never targeted) */
    0,   /* lava_flow  (never targeted) */
    200, /* obsidian: iron pick to drop; /5 with one = 40 ticks */
    0,   /* sapling (instant) */
};

#define GRAVITY   82        /* 0.02 block/tick^2 */
#define TERMINAL  1638      /* 0.4 block/tick */
#define JUMP_V    920

/* ---- N6 hunger tuning (survival only; creative never runs these) ----
 * exhaustion accumulates in small units; every EXH_PER_DRAIN units drains one
 * hunger point (or one saturation point first, if any). Actions add units;
 * passive time adds one unit every PASSIVE_TICKS. */
#define EXH_PER_DRAIN   8
#define EXH_BREAK       2   /* per block broken */
#define EXH_JUMP        1   /* per jump */
#define PASSIVE_TICKS   150 /* ~5s: +1 exhaustion unit standing still */
#define REGEN_TICKS     80  /* ~2.7s per half-heart when well fed */
#define STARVE_TICKS    80  /* ~2.7s per starvation tick at hunger 0 */
#define HUNGER_REGEN_MIN 16 /* regen only while hunger is this high */
#define EAT_RAW          6  /* raw porkchop hunger restore */
#define EAT_COOKED       16 /* cooked porkchop hunger restore */
#define SAT_MEAL         12 /* cooked meal grants this many free drain events */
#define WALK_V    480
#define EYE_H     6636      /* 1.62 blocks */
#define HALF_W    1229      /* 0.3 block */
#define HEIGHT    7373      /* 1.8 blocks */
#define REACH     18432     /* 4.5 blocks */

/* N3 held tools + tier gating: mining speed comes from the HELD hotbar item
 * only. The block x tool truth table lives in items.c (mine_divisor /
 * block_harvestable) as a pure function; here we just feed it the held id.
 * Wrong/insufficient tool on a gated block = slow break (divisor 1) AND no
 * drop (see do_break). */
static uint8_t tool_divisor(uint8_t b)
{
    return (uint8_t)mine_divisor(b, hotbar_id(plr.hotbar_sel));
}

/* survival ticks-to-break for block b with the best owned tool applied.
 * bedrock (255) is guarded BEFORE dividing so it stays never-breakable; the
 * bare-hand path (divisor 1) short-circuits to the raw time, bit-identical. */
static uint8_t effective_break_time(uint8_t b)
{
    uint8_t t = break_time[b];
    if (t == 255)
        return 255;
    uint8_t d = tool_divisor(b);
    if (d == 1)
        return t;
    uint8_t e = (uint8_t)(t / d);
    return e ? e : 1;               /* floor, min 1 tick */
}

/* Held sword's melee damage: fist 1, wood 2, stone 3, iron 4. Only the swung
 * (selected) hotbar item counts (decision #1). */
static int sword_damage(void)
{
    uint8_t held = hotbar_id(plr.hotbar_sel);
    if (held == I_SWORD_IRON)  return 4;
    if (held == I_SWORD_STONE) return 3;
    if (held == I_SWORD_WOOD)  return 2;
    return 1;
}

/* N6: add exhaustion; each EXH_PER_DRAIN units spends one saturation point (if
 * any) else one hunger point. Survival only. */
static void hunger_drain(uint8_t units)
{
    if (plr.mode != MODE_SURVIVAL || !g_hunger_drain)
        return;
    unsigned e = plr.exhaustion + units;
    while (e >= EXH_PER_DRAIN) {
        e -= EXH_PER_DRAIN;
        if (plr.saturation)
            plr.saturation--;
        else if (plr.hunger)
            plr.hunger--;
    }
    plr.exhaustion = (uint8_t)e;
}

/* ---- slot inventory (creative held row uses the fixed hotbar_blocks[]) ---- */

uint8_t hotbar_id(int sel)
{
    if (plr.mode == MODE_CREATIVE)
        return hotbar_blocks[sel];
    return plr.hotbar[sel].count ? plr.hotbar[sel].id : 0;
}

int inv_stack_cap(uint8_t id)
{
    return IS_SINGLE(id) ? 1 : STACK_MAX;   /* tools, armour, buckets */
}

int inv_count(uint8_t id)
{
    int n = 0;
    for (int i = 0; i < HOTBAR_SLOTS; i++)
        if (plr.hotbar[i].id == id) n += plr.hotbar[i].count;
    for (int i = 0; i < MAIN_SLOTS; i++)
        if (plr.main_inv[i].id == id) n += plr.main_inv[i].count;
    return n;
}

int inv_add(uint8_t id, int n)
{
    if (!id || n <= 0)
        return n < 0 ? 0 : n;
    int cap = inv_stack_cap(id);
    slot_t *arrs[2] = { plr.hotbar, plr.main_inv };
    int lens[2] = { HOTBAR_SLOTS, MAIN_SLOTS };
    /* pass 1: top up existing stacks, hotbar-first */
    for (int a = 0; a < 2 && n > 0; a++)
        for (int i = 0; i < lens[a] && n > 0; i++) {
            slot_t *s = &arrs[a][i];
            if (s->count && s->id == id && s->count < cap) {
                int room = cap - s->count, add = n < room ? n : room;
                s->count = (uint8_t)(s->count + add);
                n -= add;
            }
        }
    /* pass 2: fill empty slots, hotbar-first */
    for (int a = 0; a < 2 && n > 0; a++)
        for (int i = 0; i < lens[a] && n > 0; i++) {
            slot_t *s = &arrs[a][i];
            if (!s->count) {
                s->id = id;
                int add = n < cap ? n : cap;
                s->count = (uint8_t)add;
                n -= add;
            }
        }
    return n;
}

int inv_remove(uint8_t id, int n)
{
    if (!id || n <= 0)
        return 0;
    int removed = 0;
    /* backpack first so the held row stays stocked longest */
    slot_t *arrs[2] = { plr.main_inv, plr.hotbar };
    int lens[2] = { MAIN_SLOTS, HOTBAR_SLOTS };
    for (int a = 0; a < 2 && n > 0; a++)
        for (int i = 0; i < lens[a] && n > 0; i++) {
            slot_t *s = &arrs[a][i];
            if (s->count && s->id == id) {
                int take = s->count < n ? s->count : n;
                s->count = (uint8_t)(s->count - take);
                if (!s->count) s->id = 0;
                n -= take;
                removed += take;
            }
        }
    return removed;
}

int inv_gain(uint8_t id, int n)
{
    return inv_add(id, n);
}

static bool coll_solid(uint8_t b)
{
    /* N5: walk through torches; S0: and saplings + every liquid */
    return b != B_AIR && !block_liquid(b) && b != B_TORCH && b != B_SAPLING;
}

/* does the player AABB at (px,py,pz) overlap any solid cell (lava = 0) /
 * any lava cell (lava = 1, push3 S3)? */
static bool box_scan(fix px, fix py, fix pz, uint8_t lava)
{
    int x0 = FIX_TO_INT(px - HALF_W), x1 = FIX_TO_INT(px + HALF_W - 1);
    int z0 = FIX_TO_INT(pz - HALF_W), z1 = FIX_TO_INT(pz + HALF_W - 1);
    int y0 = FIX_TO_INT(py), y1 = FIX_TO_INT(py + HEIGHT - 1);
    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++)
            for (int y = y0; y <= y1; y++)
            {
                uint8_t b = world_get(x, y, z);
                if (lava ? (b == B_LAVA || b == B_LAVA_FLOW) : coll_solid(b))
                    return true;
            }
    return false;
}

#define box_blocked(px, py, pz) box_scan(px, py, pz, 0)

static uint8_t lava_timer;        /* push3 S3: ticks to the next lava burn */

/* move along one axis with collision snap; returns 1 if blocked */
static int move_axis(fix *coord, fix delta, int axis)
{
    fix next = *coord + delta;
    fix tx = axis == 0 ? next : plr.x;
    fix ty = axis == 1 ? next : plr.y;
    fix tz = axis == 2 ? next : plr.z;
    if (!box_blocked(tx, ty, tz)) {
        *coord = next;
        return 0;
    }
    /* snap to the face we ran into */
    if (axis == 1) {
        if (delta < 0)
            *coord = INT_TO_FIX(FIX_TO_INT(next)) + FIX_ONE;
        else
            *coord = INT_TO_FIX(FIX_TO_INT(next + HEIGHT)) - HEIGHT;
    } else {
        if (delta > 0)
            *coord = INT_TO_FIX(FIX_TO_INT(next + HALF_W)) - HALF_W;
        else
            *coord = INT_TO_FIX(FIX_TO_INT(next - HALF_W)) + FIX_ONE + HALF_W;
    }
    return 1;
}

/* DDA voxel raycast from the eye; fills plr.hit_* / plr.face */
static void raycast(void)
{
    fix ox = plr.x, oy = plr.y + EYE_H, oz = plr.z;
    fix cp = COS(plr.pitch);
    fix dx = FMUL(SIN(plr.yaw), cp);
    fix dy = SIN(plr.pitch);
    fix dz = FMUL(COS(plr.yaw), cp);

    int cx = FIX_TO_INT(ox), cy = FIX_TO_INT(oy), cz = FIX_TO_INT(oz);
    int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;

    /* tMax = distance (in 12.12 "t" where dir has length ~1) to the next
     * cell boundary per axis; tDelta = per-cell step */
    fix adx = dx < 0 ? -dx : dx, ady = dy < 0 ? -dy : dy,
        adz = dz < 0 ? -dz : dz;
    fix tdx = adx > 4 ? FDIV(FIX_ONE, adx) : 0x7FFFFF;
    fix tdy = ady > 4 ? FDIV(FIX_ONE, ady) : 0x7FFFFF;
    fix tdz = adz > 4 ? FDIV(FIX_ONE, adz) : 0x7FFFFF;

    fix fx = ox - INT_TO_FIX(cx), fy = oy - INT_TO_FIX(cy),
        fz = oz - INT_TO_FIX(cz);
    fix tmx = FMUL(dx > 0 ? FIX_ONE - fx : fx, tdx);
    fix tmy = FMUL(dy > 0 ? FIX_ONE - fy : fy, tdy);
    fix tmz = FMUL(dz > 0 ? FIX_ONE - fz : fz, tdz);

    plr.hit_x = -1;
    int face = -1;
    /* push3 S3: an empty bucket targets the first liquid SOURCE on the ray
     * (everything else passes through liquids) */
    uint8_t grab = hotbar_id(plr.hotbar_sel) == I_BUCKET;
    for (int i = 0; i < 16; i++) {
        fix t;
        if (tmx <= tmy && tmx <= tmz) {
            t = tmx; tmx += tdx; cx += sx;
            face = sx > 0 ? DIR_NX : DIR_PX;
        } else if (tmy <= tmz) {
            t = tmy; tmy += tdy; cy += sy;
            face = sy > 0 ? DIR_NY : DIR_PY;
        } else {
            t = tmz; tmz += tdz; cz += sz;
            face = sz > 0 ? DIR_NZ : DIR_PZ;
        }
        if (t > REACH)
            return;
        uint8_t b = world_get(cx, cy, cz);
        if (b != B_AIR && (!block_liquid(b) ||
                           (grab && (b == B_WATER || b == B_LAVA)))) {
            if (cx < 0 || cx >= WORLD_SX || cy < 0 || cy >= WORLD_SY ||
                cz < 0 || cz >= WORLD_SZ)
                return;
            plr.hit_x = (int8_t)cx;
            plr.hit_y = (int8_t)cy;
            plr.hit_z = (int8_t)cz;
            plr.face = (int8_t)face;
            return;
        }
    }
}

/* ---- N3 leaves: 30% stick drop + budgeted decay ---- */
#define LEAF_STICK_PCT   30       /* chance a broken/decayed leaf drops a stick */
#define LEAF_LOG_DIST    4        /* Chebyshev range a supporting log must be in */
#define DECAY_COLS_TICK  3        /* columns scanned per tick (no full-world scan) */
#define SAPLING_GROW_ONE_IN 8     /* push3 S4: growth chance per cursor visit */

/* dedicated LCG so the stick roll is deterministic and never perturbs the mob
 * or spawn streams (keeps the m4 playback golden stable). */
static uint32_t leaf_rng;
static uint16_t decay_cursor;     /* next column index into the 32x32 grid */

void leaves_reset(void)
{
    leaf_rng = 0x1EAF5EEDu;
    decay_cursor = 0;
}

static __attribute__((noinline)) uint32_t leaf_roll(void)
{
    return leaf_rng = leaf_rng * 1664525u + 1013904223u;
}

/* does the player AABB overlap cells (x, y..y+h-1, z)? */
static bool in_player(int x, int y, int z, int h)
{
    fix bx0 = INT_TO_FIX(x), by0 = INT_TO_FIX(y), bz0 = INT_TO_FIX(z);
    return plr.x + HALF_W > bx0 && plr.x - HALF_W < bx0 + FIX_ONE &&
           plr.z + HALF_W > bz0 && plr.z - HALF_W < bz0 + FIX_ONE &&
           plr.y + HEIGHT > by0 && plr.y < by0 + INT_TO_FIX(h);
}

/* roll the 30% stick chance for a leaf at (x,y,z); spawns one world drop.
 * push3 S4: the same draw also rolls a 1/16 sapling from bits 12..15 (the
 * stick uses bits 16..31), so the stick stream is unchanged. */
static void leaf_maybe_stick(int x, int y, int z)
{
    uint32_t r = leaf_roll();
    if ((r >> 16) % 100u < LEAF_STICK_PCT)
        drop_spawn(x, y, z, I_STICK);
    if (!((uint16_t)r >> 12))           /* bits 12..15 == 0: 1 in 16 */
        drop_spawn(x, y, z, B_SAPLING);
}

/* push3 S4: a sapling on grass/dirt with 4 air cells above grows into the
 * world_gen tree with chance 1/SAPLING_GROW_ONE_IN per decay-cursor visit
 * (every 1024 / DECAY_COLS_TICK = 342 ticks): expected ~2565 ticks = 85 s at
 * 30 Hz. y <= WORLD_SY - 5 keeps the tree (and the air test) in the map. */
static void sapling_tick(int x, int y, int z)
{
    uint8_t *c = &world[WORLD_IDX(x, y, z)];
    if (y == 0 || y > WORLD_SY - 5 || (c[-1] != B_GRASS && c[-1] != B_DIRT) ||
        (c[1] | c[2] | c[3] | c[4]) != B_AIR)
        return;
    leaf_roll();
    if ((((const uint8_t *)&leaf_rng)[2] & (SAPLING_GROW_ONE_IN - 1)) ||
        in_player(x, y, z, 3))          /* never trap the player in a trunk */
        return;
    torch_list_del(x, y, z);
    grow_tree(x, y - 1, z);
    /* the 3x3's corner columns reach every chunk it touches */
    mesh_dirty_block(x - 1, z - 1);
    mesh_dirty_block(x - 1, z + 1);
    mesh_dirty_block(x + 1, z - 1);
    mesh_dirty_block(x + 1, z + 1);
    compose_invalidate();
}

/* budgeted decay: advance a small window of columns per tick and self-break any
 * leaf with no B_LOG within Chebyshev LEAF_LOG_DIST (same 30% stick chance).
 * Only a handful of the 1024 columns are touched per tick, so a chopped tree's
 * canopy fades over a second or two instead of a one-frame full-world scan. */
void leaves_decay_tick(void)
{
    for (int c = 0; c < DECAY_COLS_TICK; c++) {
        int col = decay_cursor;
        decay_cursor = (uint16_t)((decay_cursor + 1) %
                                  (WORLD_SX * WORLD_SZ));
        int x = col / WORLD_SZ, z = col % WORLD_SZ;
        for (int y = 0; y < WORLD_SY; y++) {
            uint8_t b = world_get(x, y, z);
            if (b == B_SAPLING)
                sapling_tick(x, y, z);
            if (b != B_LEAVES)
                continue;
            if (log_within(x, y, z, LEAF_LOG_DIST))
                continue;
            world_set(x, y, z, B_AIR);
            mesh_dirty_block(x, z);
            compose_add_block(x, y, z);
            leaf_maybe_stick(x, y, z);
        }
    }
}

static void do_break(void)
{
    if (plr.hit_x < 0)
        return;
    uint8_t b = world_get(plr.hit_x, plr.hit_y, plr.hit_z);
    if (block_liquid(b))                /* S3: a bucket-targeted source */
        return;
    if (plr.mode == MODE_SURVIVAL) {
        if (break_time[b] == 255)
            return;                 /* bedrock */
        if (plr.break_x != plr.hit_x || plr.break_y != plr.hit_y ||
            plr.break_z != plr.hit_z) {
            plr.break_x = plr.hit_x;
            plr.break_y = plr.hit_y;
            plr.break_z = plr.hit_z;
            plr.break_ticks = 0;
        }
        uint8_t need = effective_break_time(b);
        plr.break_max = need ? need : 1;
        if (++plr.break_ticks < need)
            return;
        hunger_drain(EXH_BREAK);        /* N6: breaking a block costs food */
    }
    /* push3 S2: a broken chest hands its contents to the inventory first
     * (survival; the furnace rule). What does not fit stays in the chest,
     * which then does not break ("Inventory full"): nothing is ever lost. */
    if (b == B_CHEST && !chest_break(plr.hit_x, plr.hit_y, plr.hit_z)) {
        plr.name_ticks = 75;
        plr.name_block = NAME_INV_FULL;
        plr.break_ticks = 0;
        return;
    }
    if (plr.mode == MODE_SURVIVAL && b != B_TNT) {
        /* N3 drop table with tier gating:
         *  - leaves never drop a leaf block; 30% chance of a stick;
         *  - a gated block (stone/ore/furnace) drops only with a sufficient
         *    held pick — the wrong/no tool broke it but yields nothing;
         *  - coal ore yields the coal item (fuel); iron ore yields the ore
         *    block (smelted to an ingot later); everything else drops itself. */
        uint8_t held = hotbar_id(plr.hotbar_sel);
        if (b == B_LEAVES) {
            leaf_maybe_stick(plr.hit_x, plr.hit_y, plr.hit_z);
        } else if (block_harvestable(b, held)) {
            uint8_t drop = b;
            if (b == B_COAL_ORE) drop = I_COAL;
            else if (b == B_FURNACE_LIT) drop = B_FURNACE;  /* lit -> plain */
            drop_spawn(plr.hit_x, plr.hit_y, plr.hit_z, drop);
        }
        /* a broken furnace returns its held stacks to the inventory (never
         * lost), independent of the pick gate on the furnace block itself */
        if (b == B_FURNACE || b == B_FURNACE_LIT) {
            furnace_t *f = furnace_at(plr.hit_x, plr.hit_y, plr.hit_z);
            if (f) {
                if (f->in.count)   inv_add(f->in.id, f->in.count);
                if (f->fuel.count) inv_add(f->fuel.id, f->fuel.count);
                if (f->out.count)  inv_add(f->out.id, f->out.count);
            }
        }
    }
    if (b == B_FURNACE || b == B_FURNACE_LIT)
        furnace_remove(plr.hit_x, plr.hit_y, plr.hit_z);
    torch_list_del(plr.hit_x, plr.hit_y, plr.hit_z);   /* torch/sapling */
    if (b == B_TNT) {
        do_explosion(plr.hit_x, plr.hit_y, plr.hit_z);
    } else {
        world_set(plr.hit_x, plr.hit_y, plr.hit_z, B_AIR);
        mesh_dirty_block(plr.hit_x, plr.hit_z);
        compose_add_block(plr.hit_x, plr.hit_y, plr.hit_z);
        if (b == B_TORCH)                /* N5: remove the light AFTER the cell
                                            is air so the box re-flood is clean */
            light_del_source(plr.hit_x, plr.hit_y, plr.hit_z);
        liquid_push(plr.hit_x, plr.hit_y, plr.hit_z);   /* S3: may flow in */
    }
    plr.break_ticks = 0;
    plr.break_x = -1;
}

static void do_place(void)
{
    if (plr.hit_x < 0)
        return;
    uint8_t blk = hotbar_id(plr.hotbar_sel);
    slot_t *s = &plr.hotbar[plr.hotbar_sel];
    /* push3 S3: an empty bucket scoops the targeted source (raycast only
     * stops on a source while one is held) */
    if (blk == I_BUCKET) {
        uint8_t t = world_get(plr.hit_x, plr.hit_y, plr.hit_z);
        if (t == B_WATER || t == B_LAVA) {
            s->id = t == B_WATER ? I_BUCKET_WATER : I_BUCKET_LAVA;
            liquid_set(plr.hit_x, plr.hit_y, plr.hit_z, B_AIR);
        }
        return;
    }
    static const int8_t off[6][3] = {
        {0, 1, 0}, {0, -1, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1},
    };
    int x = plr.hit_x + off[plr.face][0];
    int y = plr.hit_y + off[plr.face][1];
    int z = plr.hit_z + off[plr.face][2];
    if (x < 0 || x >= WORLD_SX || y < 0 || y >= WORLD_SY ||
        z < 0 || z >= WORLD_SZ)
        return;
    uint8_t cur = world_get(x, y, z);
    if (cur != B_AIR && !block_liquid(cur))
        return;
    /* S3: a full bucket pours a source into the placement cell (air or a
     * liquid; the player may stand in it) and is empty again */
    if (blk == I_BUCKET_WATER || blk == I_BUCKET_LAVA) {
        s->id = I_BUCKET;
        liquid_set(x, y, z, blk == I_BUCKET_WATER ? B_WATER : B_LAVA);
        return;
    }
    /* reject placing inside the player */
    if (in_player(x, y, z, 1))
        return;
    if (blk == 0 || blk >= B_COUNT)        /* nothing held, or held item isn't
                                              a placeable block */
        return;
    /* N5: a torch places on TOP of a solid block only (needs a floor under it) */
    if (blk == B_TORCH) {
        uint8_t below = world_get(x, y - 1, z);
        if (below == B_AIR || block_liquid(below) || below == B_TORCH ||
            below == B_SAPLING)
            return;
    }
    /* push3 S4: a sapling only on grass or dirt */
    if (blk == B_SAPLING) {
        uint8_t below = world_get(x, y - 1, z);
        if (below != B_GRASS && below != B_DIRT)
            return;
    }
    if (plr.mode == MODE_SURVIVAL && !s->count)   /* out of stock */
        return;
    /* push3 S0/S2: FURNACE_MAX is 4 and CHEST_MAX 3, so a 5th furnace / 4th
     * chest refuses to place (nothing is consumed; a popup says why)
     * instead of becoming an inert block with no entity. Claimed only after
     * the stock check, so no entity is left behind for a cell that stays
     * air. */
    if ((blk == B_FURNACE && !furnace_create(x, y, z)) ||
        (blk == B_CHEST && !chest_create(x, y, z))) {
        plr.name_ticks = 75;
        plr.name_block = blk == B_CHEST ? NAME_MAX_CHESTS : NAME_MAX_FURNACES;
        return;
    }
    if (plr.mode == MODE_SURVIVAL && --s->count == 0)
        s->id = 0;                         /* last one placed: free the slot */
    world_set(x, y, z, blk);
    if (blk == B_TORCH || blk == B_SAPLING)   /* small-box/sprite list */
        torch_list_add(x, y, z);
    if (blk == B_TORCH)              /* N5: light source, incremental BFS */
        light_add_source(x, y, z, LIGHT_MAX);
    mesh_dirty_block(x, z);
    compose_add_block(x, y, z);
    liquid_push(x, y, z);            /* S3: a block in a flow's way */
}

/* eat one porkchop: +3 hearts (cap 10), survival only, and only when hurt.
 * Returns true if one was consumed. Shared by the ITEMS-page UI and tests. */
bool player_eat_porkchop(void)
{
    if (plr.mode != MODE_SURVIVAL || plr.health >= 10 ||
        !inv_count(I_PORKCHOP))
        return false;
    plr.health = (int8_t)(plr.health + 3);
    if (plr.health > 10)
        plr.health = 10;
    inv_remove(I_PORKCHOP, 1);
    return true;
}

/* N6: percent damage reduction from equipped armor (helmet 15 / boots 15 /
 * legs 25 / chest 30), summed and capped at 85%. */
int armor_pct(void)
{
    int p = 0;
    for (int i = 0; i < ARMOR_SLOTS; i++) {
        if (!plr.armor[i].count)
            continue;
        switch (plr.armor[i].id) {
        case I_HELMET_IRON: p += 15; break;
        case I_CHEST_IRON:  p += 30; break;
        case I_LEGS_IRON:   p += 25; break;
        case I_BOOTS_IRON:  p += 15; break;
        default: break;
        }
    }
    return p > 85 ? 85 : p;
}

/* N6: armored hit (mob melee + TNT). Reduce d by the equipped armor percent,
 * rounding to the nearest whole point with ties in the player's favour (down),
 * then apply. A fully-blocked hit (0 remaining) is a no-op — no flash. Fall
 * damage and starvation deliberately bypass this and call player_damage(). */
void player_hurt(int d)
{
    if (d <= 0)
        return;
    int pct = armor_pct();
    /* nearest, ties down: (d*(100-pct) + 49) / 100 */
    int r = (d * (100 - pct) + 49) / 100;
    if (r <= 0)
        return;
    player_damage(r);
}

/* N6: eat the HELD porkchop — raw restores EAT_RAW hunger, cooked restores
 * EAT_COOKED and grants saturation (free drain events). Survival only; refused
 * when the food bar is already full or nothing edible is held. */
bool player_eat_held(void)
{
    if (plr.mode != MODE_SURVIVAL || plr.hunger >= HUNGER_MAX)
        return false;
    slot_t *s = &plr.hotbar[plr.hotbar_sel];
    if (!s->count)
        return false;
    int gain;
    bool cooked;
    if (s->id == I_PORKCHOP)              { gain = EAT_RAW;    cooked = false; }
    else if (s->id == I_PORKCHOP_COOKED)  { gain = EAT_COOKED; cooked = true; }
    else
        return false;
    int h = plr.hunger + gain;
    plr.hunger = (uint8_t)(h > HUNGER_MAX ? HUNGER_MAX : h);
    if (cooked) {
        int sat = plr.saturation + SAT_MEAL;
        plr.saturation = (uint8_t)(sat > 255 ? 255 : sat);
    }
    if (--s->count == 0)
        s->id = 0;
    return true;
}

/* N6: per-tick hunger bookkeeping (survival). Passive drain, food-fuelled
 * health regen while well fed, and starvation damage (floored at 1) at zero. */
static void hunger_update(void)
{
    if (plr.mode != MODE_SURVIVAL || g_died)
        return;
    /* passive drain over time */
    if (++plr.hunger_timer >= PASSIVE_TICKS) {
        plr.hunger_timer = 0;
        hunger_drain(1);
    }
    /* regen: well fed and hurt -> heal, and regen itself costs food */
    if (plr.hunger >= HUNGER_REGEN_MIN && plr.health < 10) {
        if (++plr.regen_timer >= REGEN_TICKS) {
            plr.regen_timer = 0;
            plr.health++;
            hunger_drain(EXH_PER_DRAIN);   /* one point per half-heart healed */
        }
    } else {
        plr.regen_timer = 0;
    }
    /* starvation: at empty, tick health down but never below 1 */
    if (plr.hunger == 0 && plr.health > 1) {
        if (++plr.starve_timer >= STARVE_TICKS) {
            plr.starve_timer = 0;
            plr.health--;
            hurt_flash = 2;
        }
    } else {
        plr.starve_timer = 0;
    }
}

void player_damage(int d)
{
    if (plr.mode != MODE_SURVIVAL || g_died)
        return;
    if (d >= plr.health) {
        plr.health = 0;
        g_died = 1;          /* shell shows YOU DIED + respawn */
    } else {
        plr.health = (int8_t)(plr.health - d);
        hurt_flash = 2;
    }
}

void player_respawn(void)
{
    plr.health = 10;
    plr.hunger = HUNGER_MAX;                  /* N6: respawn resets the food bar */
    plr.saturation = 0;
    plr.exhaustion = 0;
    plr.hunger_timer = plr.regen_timer = plr.starve_timer = 0;
    plr.x = 16 * FIX_ONE;
    plr.z = 16 * FIX_ONE;
    plr.y = INT_TO_FIX(world_height[16 * WORLD_SZ + 16] + 1);
    plr.vx = plr.vy = plr.vz = 0;
    plr.fall_top = plr.y;
    g_died = 0;
}

/* shared by TNT blocks and creepers: crater + proximity damage */
void do_explosion(int ex, int ey, int ez)
{
    for (int dx = -2; dx <= 2; dx++)
        for (int dy = -2; dy <= 2; dy++)
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dy * dy + dz * dz > 6)
                    continue;
                int x = ex + dx, y = ey + dy, z = ez + dz;
                if (y < 1)
                    continue;
                uint8_t t = world_get(x, y, z);
                if (t != B_AIR && t != B_BEDROCK) {
                    world_set(x, y, z, B_AIR);
                    mesh_dirty_block(x, z);
                    compose_add_block(x, y, z);
                    /* S3: only crater cells next to a liquid (16-cell
                     * queue); a blown-up lava cell loses its light */
                    if (liquid_near(x, y, z))
                        liquid_push(x, y, z);
                    if (t == B_LAVA || t == B_LAVA_FLOW)
                        light_del_source(x, y, z);
                }
            }
    tnt_flash = 3;
    /* player splash damage by Chebyshev distance */
    fix pdx = plr.x - INT_TO_FIX(ex), pdz = plr.z - INT_TO_FIX(ez);
    fix pdy = plr.y + 4096 - INT_TO_FIX(ey);
    if (pdx < 0) pdx = -pdx;
    if (pdy < 0) pdy = -pdy;
    if (pdz < 0) pdz = -pdz;
    fix m = pdx > pdy ? pdx : pdy;
    if (pdz > m) m = pdz;
    int dist = FIX_TO_INT(m);
    if (dist < 5)
        player_hurt(6 - dist);          /* N6: armour softens the blast */
}

void player_init(void)
{
    plr.x = 6 * FIX_ONE + FIX_ONE / 2;
    plr.z = 6 * FIX_ONE + FIX_ONE / 2;
    plr.y = INT_TO_FIX(world_height[6 * WORLD_SZ + 6] + 1);
    plr.vx = plr.vy = plr.vz = 0;
    plr.yaw = 224;
    plr.pitch = -4;
    plr.on_ground = 0;
    plr.mode = MODE_CREATIVE;
    plr.hotbar_sel = 0;
    plr.hotnext_latch = 0;
    plr.place_latch = 0;
    plr.fwd_latch = 0;
    plr.dtap_timer = 0;
    plr.sprint = 0;
    plr.break_x = -1;
    plr.hit_x = -1;
    plr.attack_cd = 0;
    plr.name_ticks = 0;
    plr.name_block = hotbar_blocks[0];
    plr.health = 10;
    plr.hunger = HUNGER_MAX;                  /* N6: start well fed */
    plr.saturation = 0;
    plr.exhaustion = 0;
    plr.hunger_timer = plr.regen_timer = plr.starve_timer = 0;
    plr.fall_top = plr.y;
    leaves_reset();                          /* N3: reset decay cursor + rng */
    furnaces_reset();                        /* N4: no live furnaces on init */
    for (int i = 0; i < HOTBAR_SLOTS; i++)   /* survival starts empty */
        plr.hotbar[i].id = plr.hotbar[i].count = 0;
    for (int i = 0; i < MAIN_SLOTS; i++)
        plr.main_inv[i].id = plr.main_inv[i].count = 0;
    for (int i = 0; i < ARMOR_SLOTS; i++)
        plr.armor[i].id = plr.armor[i].count = 0;
}

void player_tick(unsigned int in)
{
    if (g_died)
        return;
    /* look */
    if (in & IN_LOOK_L) plr.yaw -= 4;
    if (in & IN_LOOK_R) plr.yaw += 4;
    if ((in & IN_LOOK_U) && plr.pitch < 56) plr.pitch += 3;
    if ((in & IN_LOOK_D) && plr.pitch > -56) plr.pitch -= 3;

    /* sprint: a double-tap of FWD (two rising edges within ~8 ticks) makes
     * you sprint at 1.6x while FWD stays held; releasing FWD ends it. The
     * m4 play script holds FWD continuously (one rising edge) so it never
     * sprints -> the golden is untouched. */
    uint8_t fwd = (in & IN_FWD) != 0;
    if (fwd && !plr.fwd_latch) {         /* FWD rising edge */
        if (plr.dtap_timer)
            plr.sprint = 1;
        plr.dtap_timer = 8;
    }
    if (!fwd)
        plr.sprint = 0;
    if (plr.dtap_timer)
        plr.dtap_timer--;
    plr.fwd_latch = fwd;

    /* walk: camera-relative */
    fix fwdx = SIN(plr.yaw), fwdz = COS(plr.yaw);
    fix vx = 0, vz = 0;
    if (in & IN_FWD)  { vx += fwdx; vz += fwdz; }
    if (in & IN_BACK) { vx -= fwdx; vz -= fwdz; }
    if (in & IN_LEFT) { vx -= fwdz; vz += fwdx; }
    if (in & IN_RIGHT){ vx += fwdz; vz -= fwdx; }
    fix wv = plr.sprint ? (WALK_V * 8 / 5) : WALK_V;   /* 1.6x when sprinting */
    plr.vx = FMUL(vx, wv);
    plr.vz = FMUL(vz, wv);

    /* water (S3: any liquid, lava too): slow movement, float up with jump */
    bool inwater =
        block_liquid(world_get(FIX_TO_INT(plr.x), FIX_TO_INT(plr.y + 2048),
                               FIX_TO_INT(plr.z)));
    if (inwater) {
        plr.vx >>= 1;
        plr.vz >>= 1;
        plr.vy -= GRAVITY / 4;          /* gentler sink than air */
        if (plr.vy < -360)
            plr.vy = -360;
        if (in & IN_JUMP)
            plr.vy = 640;               /* brisk swim-up: carries momentum
                                           out of the water so you can climb
                                           onto an adjacent ledge */
    } else {
        plr.vy -= GRAVITY;
        if (plr.vy < -TERMINAL)
            plr.vy = -TERMINAL;
        if ((in & IN_JUMP) && plr.on_ground) {
            plr.vy = JUMP_V;
            hunger_drain(EXH_JUMP);     /* N6: jumping costs food */
        }
    }

    /* integrate per axis */
    int hbx = move_axis(&plr.x, plr.vx, 0);
    int hbz = move_axis(&plr.z, plr.vz, 2);
    /* auto-jump (setting, default off): grounded and walking into a wall
     * that a single 1-block step would clear -> hop it. Gated off by
     * default so the default-settings play golden is untouched. */
    if (g_autojump && plr.on_ground && !inwater && plr.vy <= 0 &&
        (hbx || hbz) &&
        (in & (IN_FWD | IN_BACK | IN_LEFT | IN_RIGHT)) &&
        !box_blocked(plr.x + plr.vx, plr.y + FIX_ONE, plr.z + plr.vz)) {
        plr.vy = JUMP_V;
        hunger_drain(EXH_JUMP);
    }
    /* invisible world-border walls */
    if (plr.x < HALF_W + 64) plr.x = HALF_W + 64;
    if (plr.x > INT_TO_FIX(WORLD_SX) - HALF_W - 64)
        plr.x = INT_TO_FIX(WORLD_SX) - HALF_W - 64;
    if (plr.z < HALF_W + 64) plr.z = HALF_W + 64;
    if (plr.z > INT_TO_FIX(WORLD_SZ) - HALF_W - 64)
        plr.z = INT_TO_FIX(WORLD_SZ) - HALF_W - 64;
    plr.on_ground = 0;
    if (plr.y > plr.fall_top)
        plr.fall_top = plr.y;
    if (move_axis(&plr.y, plr.vy, 1)) {
        if (plr.vy < 0) {
            plr.on_ground = 1;
            if (!inwater) {
                int drop = FIX_TO_INT(plr.fall_top - plr.y);
                if (drop > 3)
                    player_damage(drop - 3);
            }
            plr.fall_top = plr.y;
        }
        plr.vy = 0;
    }
    if (inwater)
        plr.fall_top = plr.y;       /* water breaks a fall */
    /* push3 S1: fell into the Skyblock void (only Skyblock can get here:
     * the other world types have a bedrock floor below y 0). Survival dies
     * (YOU DIED -> respawn on the island), creative is put back on spawn. */
    if (plr.y < -4 * FIX_ONE) {
        if (plr.mode == MODE_SURVIVAL)
            player_damage(100);
        else
            player_respawn();
    }

    /* push3 S3: lava burns 2 (armour applies) on contact, then every 10
     * ticks while the body touches it */
    if (box_scan(plr.x, plr.y, plr.z, 1)) {
        if (!lava_timer)
            player_hurt(2);
        if (++lava_timer >= 10)
            lava_timer = 0;
    } else {
        lava_timer = 0;
    }

    /* hotbar cycle (edge-triggered); empty survival slots show no popup */
    if (in & IN_HOTNEXT) {
        if (!plr.hotnext_latch) {
            plr.hotnext_latch = 1;
            plr.hotbar_sel = (uint8_t)((plr.hotbar_sel + 1) % HOTBAR_SLOTS);
            uint8_t id = hotbar_id(plr.hotbar_sel);
            if (id) {
                plr.name_ticks = 75;   /* ~2.5s popup, Minecraft-style */
                plr.name_block = id;
            }
        }
    } else {
        plr.hotnext_latch = 0;
    }

    raycast();

    if (plr.attack_cd)
        plr.attack_cd--;
    if (in & IN_BREAK) {
        /* a mob under the crosshair takes the punch instead of the block */
        fix cp = COS(plr.pitch);
        int tm = mobs_pick(plr.x, plr.y + EYE_H, plr.z,
                           FMUL(SIN(plr.yaw), cp), SIN(plr.pitch),
                           FMUL(COS(plr.yaw), cp));
        if (tm >= 0) {
            plr.break_ticks = 0;
            if (!plr.attack_cd) {
                mob_punch(tm, sword_damage());
                plr.attack_cd = 8;
            }
        } else {
            do_break();
        }
    } else {
        plr.break_ticks = 0;
    }

    if (in & IN_PLACE) {
        if (!plr.place_latch) {
            plr.place_latch = 1;
            do_place();
        }
    } else {
        plr.place_latch = 0;
    }

    if (plr.name_ticks)
        plr.name_ticks--;

    hunger_update();          /* N6: passive drain + regen + starvation */

    mobs_tick();
    drops_tick();
    leaves_decay_tick();
    furnaces_tick();          /* N4: background smelting (no-op with no furnaces) */
    liquids_tick();           /* S3: pops <= 4 queued cells (none: no-op) */
}

void player_camera(camera_t *cam)
{
    cam->x = plr.x;
    cam->y = plr.y + EYE_H;
    cam->z = plr.z;
    cam->yaw = plr.yaw;
    cam->pitch = plr.pitch;
}
