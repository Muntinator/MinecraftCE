/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * world.c — 48x48x16 block array + deterministic terrain generation.
 * Integer-only 2-octave value noise so host and calc generate identical
 * worlds from the same seed.
 */

#include <string.h>

#include "world.h"
#include "save.h"
#include "furnace.h"   /* push3 S2: chests (starter kit) */
#include "items.h"

uint8_t world[WORLD_SX * WORLD_SZ * WORLD_SY];
uint8_t g_worldtype;   /* 0 = normal, 1 = superflat, 2 = skyblock */
uint8_t world_height[WORLD_SX * WORLD_SZ];

/* 2D lattice hash -> 0..255, mixed LCG-style; all uint32 ops are identical
 * on both platforms */
static uint8_t noise2(uint32_t seed, uint32_t x, uint32_t z)
{
    uint32_t h = seed;
    h ^= x * 0x9E3779B1u;
    h ^= z * 0x85EBCA77u;
    h ^= h >> 13;
    h *= 0xC2B2AE35u;
    h ^= h >> 16;
    return (uint8_t)h;
}

/* value noise: bilinear interp of lattice hashes, cell size 2^cellbits,
 * returns 0..255 in 8.8 -> we keep 8 fractional bits out for smoothness */
static int32_t vnoise(uint32_t seed, int x, int z, int cellbits)
{
    int cx = x >> cellbits, cz = z >> cellbits;
    int32_t fx = (x - (cx << cellbits)) << (8 - cellbits);  /* 0..255 */
    int32_t fz = (z - (cz << cellbits)) << (8 - cellbits);
    int32_t a = noise2(seed, (uint32_t)cx,     (uint32_t)cz);
    int32_t b = noise2(seed, (uint32_t)(cx+1), (uint32_t)cz);
    int32_t c = noise2(seed, (uint32_t)cx,     (uint32_t)(cz+1));
    int32_t d = noise2(seed, (uint32_t)(cx+1), (uint32_t)(cz+1));
    int32_t ab = (a << 8) + (b - a) * fx;   /* 0..255<<8 */
    int32_t cd = (c << 8) + (d - c) * fx;
    return ab + (((cd - ab) * fz) >> 8);    /* 0..255<<8 */
}

bool log_within(int x, int y, int z, int r)
{
    for (int dx = -r; dx <= r; dx++)
        for (int dz = -r; dz <= r; dz++)
            for (int dy = -r; dy <= r; dy++)
                if (world_get(x + dx, y + dy, z + dz) == B_LOG)
                    return true;
    return false;
}

#define WATER_LEVEL 4

/* the world_gen tree, extracted (push3 S1; S4's sapling growth reuses it;
 * same cells in the same order, --worldstat unchanged): 3 logs on the
 * grass at y=h, a 3x3 leaf layer at h+3 and a plus-shaped cap at h+4,
 * leaves only into air. Column pointers: y is innermost. push3 S4: leaf
 * columns outside the map are skipped (a sapling may grow at the edge);
 * the caller guarantees 0 <= h and h + 4 < WORLD_SY. */
void grow_tree(int x, int h, int z)
{
    uint8_t *c = &world[WORLD_IDX(x, h, z)];
    c[1] = c[2] = c[3] = B_LOG;
    uint8_t *n = c - (WORLD_SZ + 1) * WORLD_SY;      /* (x-1, z-1) */
    for (int dx = 0; dx < 3; dx++, n += (WORLD_SZ - 3) * WORLD_SY) {
        unsigned lx = (unsigned)(x - 1 + dx);
        for (int dz = 0; dz < 3; dz++, n += WORLD_SY) {
            if (lx >= WORLD_SX || (unsigned)(z - 1 + dz) >= WORLD_SZ)
                continue;                /* S4: off the map edge */
            if (n[3] == B_AIR)
                n[3] = B_LEAVES;
            if ((dx == 1 || dz == 1) && n[4] == B_AIR)
                n[4] = B_LEAVES;
        }
    }
}

void world_gen(uint32_t seed)
{
    world_seed = seed;
    chests_reset();                 /* push3 S2: a new world has no chests */
    if (g_worldtype == 2) {
        /* push3 S1 Skyblock: a fixed island (the seed only drives the
         * mob/spawn RNG), all inside mesh chunk (2,2) = x,z 16..23: an L of
         * an 8x5 arm (z 16..20) + a 3x3 leg (x 16..18, z 21..23), dirt
         * y=2..3 under grass y=4, one bedrock under the spawn column, a tree
         * at the far end of the arm, a chest on the leg. Void columns have
         * world_height 0, island columns 4 (the grass line). */
        memset(world, B_AIR, sizeof world);
        memset(world_height, 0, sizeof world_height);
        for (int x = 16; x < 24; x++)
            for (int z = 16; z < 24; z++)
                if (z <= 20 || x <= 18) {        /* arm z 16..20, leg x 16..18 */
                    uint8_t *col = &world[WORLD_IDX(x, 0, z)];
                    col[2] = col[3] = B_DIRT;
                    col[4] = B_GRASS;
                    world_height[x * WORLD_SZ + z] = 4;
                }
        world[WORLD_IDX(16, 4, 16)] = B_BEDROCK;
        grow_tree(22, 4, 18);
        world[WORLD_IDX(17, 5, 22)] = B_CHEST;
        /* push3 S2: the starter chest + kit (owner: water + lava bucket) */
        chests[0].active = 1;
        chests[0].x = 17; chests[0].y = 5; chests[0].z = 22;
        chests[0].slots[0].id = I_BUCKET_WATER; chests[0].slots[0].count = 1;
        chests[0].slots[1].id = I_BUCKET_LAVA;  chests[0].slots[1].count = 1;
        return;
    }
    if (g_worldtype == 1) {
        /* superflat: bedrock, 2 dirt, grass at y=3 */
        for (int x = 0; x < WORLD_SX; x++)
            for (int z = 0; z < WORLD_SZ; z++) {
                uint8_t *col = &world[WORLD_IDX(x, 0, z)];
                col[0] = B_BEDROCK;
                col[1] = B_DIRT;
                col[2] = B_DIRT;
                col[3] = B_GRASS;
                for (int y = 4; y < WORLD_SY; y++)
                    col[y] = B_AIR;
                world_height[x * WORLD_SZ + z] = 3;
            }
        return;
    }
    for (int x = 0; x < WORLD_SX; x++) {
        for (int z = 0; z < WORLD_SZ; z++) {
            /* two octaves: broad hills + detail */
            int32_t n1 = vnoise(seed,          x, z, 4);  /* 0..255<<8 */
            int32_t n2 = vnoise(seed ^ 0xA5A5, x, z, 2);
            /* height 2..9: lows become lakes (water fills to y=4) */
            int h = 2 + (int)((n1 * 6 + n2 * 2) >> 16);
            if (h > WORLD_SY - 3) h = WORLD_SY - 3;
            world_height[x * WORLD_SZ + z] = (uint8_t)h;

            uint8_t *col = &world[WORLD_IDX(x, 0, z)];
            col[0] = B_BEDROCK;
            int y = 1;
            for (; y <= h - 3; y++) col[y] = B_STONE;
            bool beach = h <= WATER_LEVEL;
            for (; y < h; y++) col[y] = beach ? B_SAND : B_DIRT;
            col[h] = beach ? B_SAND : B_GRASS;
            for (y = h + 1; y < WORLD_SY; y++)
                col[y] = (y <= WATER_LEVEL) ? B_WATER : B_AIR;
        }
    }

    /* caves + ores, deterministic LCG walk (normal worlds only) */
    {
        uint32_t rng = seed ^ 0xCAFEBABEu;
        #define WRND() (rng = rng * 1664525u + 1013904223u, rng >> 8)

        /* worm caves: random-walk tunnels carved through stone/dirt.
         * Only underground cells are eaten (never a column's surface
         * block, sand, or water), so lakes stay sealed. */
        for (int w = 0; w < 3; w++) {
            int x = 3 + (int)(WRND() % (WORLD_SX - 6));
            int z = 3 + (int)(WRND() % (WORLD_SZ - 6));
            int y = 1 + (int)(WRND() % 3);
            int dx = (int)(WRND() % 3) - 1, dz = (int)(WRND() % 3) - 1;
            for (int step = 0; step < 40; step++) {
                for (int dy = 0; dy <= 1; dy++) {
                    int h = world_height[x * WORLD_SZ + z];
                    if (y + dy < h) {
                        uint8_t *c = &world[WORLD_IDX(x, y + dy, z)];
                        if (*c == B_STONE || *c == B_DIRT)
                            *c = B_AIR;
                    }
                }
                if ((WRND() & 7) == 0) dx = (int)(WRND() % 3) - 1;
                if ((WRND() & 7) == 0) dz = (int)(WRND() % 3) - 1;
                if ((WRND() & 7) == 0) y += (int)(WRND() % 3) - 1;
                x += dx;
                z += dz;
                if (y < 1) y = 1;
                if (y > 5) y = 5;
                if (x < 1 || x >= WORLD_SX - 1 ||
                    z < 1 || z >= WORLD_SZ - 1)
                    break;
            }
        }

        /* two entrance shafts on grassy hills so caves are findable */
        for (int e = 0, tries = 0; e < 2 && tries < 40; tries++) {
            int x = 3 + (int)(WRND() % (WORLD_SX - 6));
            int z = 3 + (int)(WRND() % (WORLD_SZ - 6));
            int h = world_height[x * WORLD_SZ + z];
            if (h >= 6 && world[WORLD_IDX(x, h, z)] == B_GRASS &&
                world[WORLD_IDX(x, h + 1, z)] == B_AIR) {
                for (int y = h; y >= h - 2 && y >= 1; y--)
                    world[WORLD_IDX(x, y, z)] = B_AIR;
                e++;
            }
        }

        /* ore pockets in stone: coal common, iron rare and deep */
        for (int p = 0; p < 14; p++) {
            int x = 1 + (int)(WRND() % (WORLD_SX - 2));
            int z = 1 + (int)(WRND() % (WORLD_SZ - 2));
            int y = 1 + (int)(WRND() % 5);
            if (world[WORLD_IDX(x, y, z)] != B_STONE)
                continue;
            world[WORLD_IDX(x, y, z)] = B_COAL_ORE;
            for (int n = 0; n < 2; n++) {
                int nx = x + (int)(WRND() % 3) - 1;
                int ny = y + (int)(WRND() % 3) - 1;
                int nz = z + (int)(WRND() % 3) - 1;
                if (nx >= 0 && nx < WORLD_SX && ny >= 1 && ny < WORLD_SY &&
                    nz >= 0 && nz < WORLD_SZ &&
                    world[WORLD_IDX(nx, ny, nz)] == B_STONE)
                    world[WORLD_IDX(nx, ny, nz)] = B_COAL_ORE;
            }
        }
        for (int p = 0; p < 5; p++) {
            int x = 1 + (int)(WRND() % (WORLD_SX - 2));
            int z = 1 + (int)(WRND() % (WORLD_SZ - 2));
            int y = 1 + (int)(WRND() % 2);
            if (world[WORLD_IDX(x, y, z)] != B_STONE)
                continue;
            world[WORLD_IDX(x, y, z)] = B_IRON_ORE;
            int nx = x + (int)(WRND() % 3) - 1;
            int nz = z + (int)(WRND() % 3) - 1;
            if ((WRND() & 1) && nx >= 1 && nx < WORLD_SX - 1 &&
                nz >= 1 && nz < WORLD_SZ - 1 &&
                world[WORLD_IDX(nx, y, nz)] == B_STONE)
                world[WORLD_IDX(nx, y, nz)] = B_IRON_ORE;
        }
        #undef WRND
    }

    /* trees: Bernoulli per grassy column, deterministic from the seed */
    for (int x = 2; x < WORLD_SX - 2; x++) {
        for (int z = 2; z < WORLD_SZ - 2; z++) {
            int h = world_height[x * WORLD_SZ + z];
            if (h > WATER_LEVEL && h <= 6 &&
                world[WORLD_IDX(x, h, z)] == B_GRASS &&
                noise2(seed ^ 0x7EE5u, (uint32_t)x, (uint32_t)z) < 9)
                grow_tree(x, h, z);
        }
    }
}
