/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef UI_H
#define UI_H

#include "common.h"

/*
 * ui.h — menu / page drawing (UI U2). Portable: main.c's input loops call
 * these on the calc and the host harness renders the same screens
 * (--title, --uiset, --uiload, --uimenu N), so every menu is golden-able
 * and eyeball-able. All text is mcfont (Minecraft font).
 */

#define BTN_W 200
#define BTN_H 18
#define BTN_PITCH (BTN_H + 6)

void ui_logo(uint8_t *fb, int y);
void ui_tile_dirt(uint8_t *fb, int y0, int y1);
void ui_button(uint8_t *fb, int y, const char *label, bool sel);
void ui_buttons(uint8_t *fb, const char *const *items, int n, int y0, int sel);
void ui_title_text(uint8_t *fb);                 /* version + credit */
void ui_banner(uint8_t *fb, int y, const char *s, int scale); /* PAUSED etc. */
void ui_load_screen(uint8_t *fb, const char *stage, int pct);
void ui_controls_page(uint8_t *fb);

/* Setting kinds; a row list picks a subset + order per variant. Per-world
 * options (day/night, mobs, game mode) only appear in the in-game menu. */
enum { OPT_RENDER, OPT_DAYNIGHT, OPT_MOBS, OPT_GAMEMODE, OPT_TEXTURES,
       OPT_GRAPHICS, OPT_VIEWPORT, OPT_AUTOJUMP, OPT_CONTROLS, OPT_DONE };
void ui_settings_page(uint8_t *fb, const uint8_t *items, int n, int sel);

void ui_create_page(uint8_t *fb, int sel, uint8_t wtype, uint8_t wmode);
void ui_select_page(uint8_t *fb, const char *const *items, int n, int sel);

#endif
