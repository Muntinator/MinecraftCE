/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * savefmt.c — portable save-image codec (see savefmt.h). Compiled into the
 * calc build and #included by the host harness (--save round trips it).
 */

#include "savefmt.h"

unsigned sf_rle_enc(uint8_t *out, unsigned cap, const uint8_t *src,
                    unsigned outer, unsigned inner, unsigned stride)
{
    unsigned o = 0;
    uint8_t run = 0, v = 0;
    for (unsigned a = 0; a < outer; a++) {
        const uint8_t *p = src + a;
        for (unsigned b = 0; b < inner; b++, p += stride) {
            uint8_t c = *p;
            if (run && c == v && run < 255) {
                run++;
                continue;
            }
            if (run) {
                if (o + 2 > cap)
                    return 0;
                out[o++] = run;
                out[o++] = v;
            }
            v = c;
            run = 1;
        }
    }
    if (run) {
        if (o + 2 > cap)
            return 0;
        out[o++] = run;
        out[o++] = v;
    }
    return o;
}

bool sf_rle_dec(const uint8_t *in, unsigned len, uint8_t *dst,
                unsigned outer, unsigned inner, unsigned stride)
{
    unsigned a = 0, b = 0, i = 0;
    uint8_t *p = dst;
    if (len & 1)
        return false;
    while (i < len) {
        uint8_t run = in[i++];
        uint8_t v = in[i++];
        if (!run)
            return false;
        do {
            if (a >= outer)
                return false;          /* stream longer than the array */
            *p = v;
            p += stride;
            if (++b == inner) {
                b = 0;
                p = dst + ++a;
            }
        } while (--run);
    }
    return a == outer;
}

uint16_t sf_fletcher16(const uint8_t *p, unsigned n)
{
    unsigned s1 = 0, s2 = 0;          /* both stay < 255 */
    while (n--) {
        s1 += *p++;
        if (s1 >= 255) s1 -= 255;
        s2 += s1;
        if (s2 >= 255) s2 -= 255;
    }
    return (uint16_t)((s2 << 8) | s1);
}
