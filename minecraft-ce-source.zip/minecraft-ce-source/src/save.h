/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef SAVE_H
#define SAVE_H

#include "common.h"

/* push3 SV (MC10): each slot is two banks of AppVar parts "MCW<slot><A|B><k>"
 * of at most SAVE_PART bytes (see save.c); a legacy single-var "MCWORLDn"
 * MC09 save still loads. Calc + host harness (--save, ti_* mock); other host
 * builds get stubs. g_save_slot (1..3) selects the slot save/load act on. */
#define SAVE_SLOTS 3
/* bytes per AppVar part; RAM holds one part at a time. In game only ~4.5 KB
 * of RAM is free (SV measure; every image byte costs one), so parts stay
 * small: a save needs SAVE_PART + a VAT entry of free RAM. */
#define SAVE_PART 1024
extern uint8_t g_save_slot;  /* 1..3, the active slot */

bool save_world(void);       /* false = failed, the previous save is intact */
bool load_world(void);       /* true = save existed and was restored */
bool save_exists(void);
/* per-slot probe for the Continue page: fills seed/mode if the slot has a
 * valid save (MC10 bank or MC09 header) and returns 1 + its worldtype
 * (push3 S1: 3 = Skyblock); 0 = empty slot */
uint8_t slot_info(int slot, uint32_t *seed, uint8_t *mode);
void prefs_save(void);       /* device settings appvar MCPREFS */
void prefs_load(void);

extern uint32_t world_seed;  /* set by world_gen, kept for the save */
extern uint8_t g_daynight;   /* 0 off, 1 normal, 2 fast */

#endif
