/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * n5scene.h — the deterministic N5 torch-lit scene, shared verbatim by the
 * calc N5_TEST build (main.c) and the host --n5lit frame (harness.c) so their
 * framebuffers are byte-identical (CRC-checked by cemu-autotester).
 *
 * A superflat world (grass @ y=3) is used instead of the demo vista so the
 * geometry is independent of terrain gen: a 3x3 stone wall faces the camera,
 * with a torch on the grass one cell in front of the wall's centre. The torch
 * brightens the wall's camera-facing (-z / ±x) side faces via the baked light
 * banks — the whole point of N5 — and draws its own small box.
 */

#ifndef N5SCENE_H
#define N5SCENE_H

#include "world.h"
#include "mesh.h"
#include "demo.h"

#define N5_CAM_X (16 * FIX_ONE + FIX_ONE / 2)
#define N5_CAM_Y (5 * FIX_ONE)
#define N5_CAM_Z (6 * FIX_ONE)
#define N5_YAW   0
#define N5_PITCH (-4)

/* torch cell (in front of the wall) and wall plane */
#define N5_TORCH_X 16
#define N5_TORCH_Y 4
#define N5_TORCH_Z 11
#define N5_WALL_Z  12

static inline void n5_build_scene(int with_torch)
{
    g_worldtype = 1;                 /* superflat: bedrock/dirt/dirt/grass @ y=3 */
    world_gen(DEMO_SEED);
    for (int x = 15; x <= 17; x++)   /* 3x3 stone wall facing -z */
        for (int y = 4; y <= 6; y++)
            world_set(x, y, N5_WALL_Z, B_STONE);
    if (with_torch)
        world_set(N5_TORCH_X, N5_TORCH_Y, N5_TORCH_Z, B_TORCH);
    mesh_init();                     /* rebuilds the light field + torch list */
}

#endif
