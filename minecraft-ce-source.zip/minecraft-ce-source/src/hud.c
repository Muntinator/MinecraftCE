/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * hud.c — crosshair, hotbar, hearts, block-name popup, debug overlay,
 * inventory screen. Portable (direct 8bpp framebuffer writes) so the
 * playback parity test covers it byte-for-byte.
 */

#include <string.h>

#include "hud.h"
#include "palette.h"
#include "textures.h"
#include "player.h"
#include "render.h"
#include "world.h"
#include "items.h"
#include "craft.h"
#include "mcfont.h"
#include "compose.h"

uint8_t hud_debug;       /* shell-toggled: fps/coords overlay */
uint16_t hud_fps10;      /* fps x10, measured by the shell (0 on host) */

#define SLOT_W  20                   /* reference hotbarslot sprite size */
#define SLOT_X0 ((SCREEN_W - HOTBAR_SLOTS * SLOT_W) / 2)
#define SLOT_Y  210                  /* reference hotbar position */
#define HEART_Y (SLOT_Y - 11)         /* 9-row MC icons: 199..207 */
/* item-name popup rows (8 px + shadow): survival clears the armour row
 * (ARMOR_Y = 189), creative sits just above the hotbar. main.c's
 * compositor rect for the popup is (80,178)-(240,207). */
#define HUD_NAME_Y_SURV 180
#define HUD_NAME_Y_CRE  197

/* palette-bank grays derived from white: 62=white, |64 ~80%, |128 ~62%,
 * |192 = 50% */
#define GRAY_LT  (PAL_WHITE | 64)
#define GRAY_MD  (PAL_WHITE | 128)
#define GRAY_DK  (PAL_WHITE | 192)

/* UI U2: all text is the Minecraft font (mcfont.c: mc_text, MC drop shadow).
 * Decimal formatter for counts / the debug overlay: writes v (may be
 * negative) at p, NUL-terminates, returns the end. */
static char *fmt_int(char *p, int v)
{
    char t[8];
    int n = 0;
    if (v < 0) { *p++ = '-'; v = -v; }
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *p++ = t[--n];
    *p = 0;
    return p;
}

/* indexed by any id (popup also announces item/ore pickups). Designated
 * initializers leave the id 25..31 gap as NULL — no id lives there. */
static const char *const block_names[ID_COUNT] = {
    [B_GRASS] = "Grass Block", [B_DIRT] = "Dirt", [B_STONE] = "Stone",
    [B_COBBLE] = "Cobblestone", [B_LOG] = "Oak Log", [B_LEAVES] = "Oak Leaves",
    [B_PLANKS] = "Oak Wood Planks", [B_SAND] = "Sand", [B_WATER] = "Water",
    [B_GLASS] = "Glass", [B_BEDROCK] = "Bedrock", [B_TNT] = "TNT",
    [B_COAL_ORE] = "Coal Ore", [B_IRON_ORE] = "Iron Ore",
    [B_CRAFTING_TABLE] = "Crafting Table", [B_FURNACE] = "Furnace",
    [B_TORCH] = "Torch", [B_FURNACE_LIT] = "Furnace",
    [B_CHEST] = "Chest", [B_WATER_FLOW] = "Water", [B_LAVA] = "Lava",
    [B_LAVA_FLOW] = "Lava", [B_OBSIDIAN] = "Obsidian",
    [B_SAPLING] = "Oak Sapling",
    [I_STICK] = "Stick", [I_GUNPOWDER] = "Gunpowder",
    [I_PORKCHOP] = "Raw Porkchop",
    [I_PICK_WOOD] = "Wooden Pickaxe", [I_PICK_STONE] = "Stone Pickaxe",
    [I_PICK_IRON] = "Iron Pickaxe", [I_AXE_WOOD] = "Wooden Axe",
    [I_AXE_STONE] = "Stone Axe", [I_AXE_IRON] = "Iron Axe",
    [I_SWORD_WOOD] = "Wooden Sword", [I_SWORD_STONE] = "Stone Sword",
    [I_SWORD_IRON] = "Iron Sword",
    [I_COAL] = "Coal", [I_IRON_INGOT] = "Iron Ingot",
    [I_PORKCHOP_COOKED] = "Cooked Porkchop",
    [I_HELMET_IRON] = "Iron Helmet", [I_CHEST_IRON] = "Iron Chestplate",
    [I_LEGS_IRON] = "Iron Leggings", [I_BOOTS_IRON] = "Iron Boots",
    [I_BUCKET] = "Bucket", [I_BUCKET_WATER] = "Water Bucket",
    [I_BUCKET_LAVA] = "Lava Bucket",
    /* push3 S2: refusal popups (ids in the block gap, items.h) */
    [NAME_MAX_FURNACES] = "Max 4 furnaces", [NAME_MAX_CHESTS] = "Max 3 chests",
    [NAME_INV_FULL] = "Inventory full",
};

/* ---- crosshair + break progress + name popup + debug (viewport) ---- */

void hud_crosshair(uint8_t *fb)
{
    int cx = 160, cy = view_h / 2;
    for (int i = -3; i <= 3; i++) {
        fb[cy * SCREEN_W + cx + i] = PAL_WHITE;
        fb[(cy + i) * SCREEN_W + cx] = PAL_WHITE;
    }
    if (plr.mode == MODE_SURVIVAL && plr.break_ticks) {
        /* a chunky progress bar below the crosshair: 36px inner width,
         * 6px tall, 1px black border, white fill proportional to how far
         * the current block has been chewed through */
        const int bw = 36, bh = 6;
        int bx = cx - bw / 2, by = cy + 10;
        int max = plr.break_max ? plr.break_max : 1;
        int fill = bw * plr.break_ticks / max;
        if (fill > bw) fill = bw;
        for (int yy = -1; yy <= bh; yy++)               /* black backing */
            memset(&fb[(by + yy) * SCREEN_W + bx - 1], PAL_BLACK,
                   (size_t)(bw + 2));
        for (int yy = 0; yy < bh; yy++)                 /* white fill */
            if (fill)
                memset(&fb[(by + yy) * SCREEN_W + bx], PAL_WHITE,
                       (size_t)fill);
    }

    /* held-item name popup (MC: white, shadowed, scale 1, centred above
     * the hotbar; above the armour row in survival, lower in creative) */
    if (plr.name_ticks)
        mc_text_center(fb, plr.mode == MODE_SURVIVAL ? HUD_NAME_Y_SURV
                                                     : HUD_NAME_Y_CRE,
                       block_names[plr.name_block], PAL_WHITE, 1);

    if (hud_debug) {
        /* MC F3 style: white shadowed lines, 10 px pitch, inside the
         * compositor's (0,0)-(96,52) debug rect */
        char buf[16];
        char *e = fmt_int(buf, hud_fps10 / 10);
        *e++ = '.';
        e = fmt_int(e, hud_fps10 % 10);
        e[0] = ' '; e[1] = 'f'; e[2] = 'p'; e[3] = 's'; e[4] = 0;
        mc_text(fb, 2, 2, buf, PAL_WHITE, 1);
        fix v[4];
        v[0] = plr.x; v[1] = plr.y; v[2] = plr.z;
        v[3] = INT_TO_FIX(view_radius);
        static const char ax[4] = { 'X', 'Y', 'Z', 'R' };
        for (int i = 0; i < 4; i++) {
            buf[0] = ax[i]; buf[1] = ':'; buf[2] = ' ';
            fmt_int(buf + 3, FIX_TO_INT(v[i]));
            mc_text(fb, 2, 12 + i * 10, buf, PAL_WHITE, 1);
        }
    }
}

/* ---- hearts / hunger / armour: the Mojang gui/icons.png sprites ----
 * UI U3: one 9x63 convimg sheet (tools/gen_lce_assets.py hud_icons()),
 * 7 sprites of 9x9, transparent texels on the magenta key slot 60. Every
 * state of a kind is composited over the same container, so a value
 * change repaints the same pixel set (no stale world pixels). */
extern unsigned char hud_icons_data[2 + 9 * 63];
enum { HI_HEART_EMPTY, HI_HEART_FULL, HI_FOOD_EMPTY, HI_FOOD_FULL,
       HI_FOOD_HALF, HI_ARMOR_EMPTY, HI_ARMOR_FULL };

static void draw_hud_icon(uint8_t *fb, int x, int y, int k)
{
    const uint8_t *s = hud_icons_data + 2 + k * 81;
    for (int r = 0; r < 9; r++) {
        uint8_t *row = fb + (y + r) * SCREEN_W + x;
        for (int c = 0; c < 9; c++, s++)
            if (*s != PAL_TEXBLACK)          /* the key slot (raw sheet) */
                row[c] = *s;
    }
}

/* HUD icon rows, MC layout: 9x9 icons on an 8 px pitch; hearts from the
 * hotbar's left edge, hunger right-aligned to its right edge (filled from
 * the right, like MC), armour 10 rows above the hearts */
#define ICON_DX   8
#define HEART_X0  SLOT_X0
#define HUNGER_X1 (SLOT_X0 + HOTBAR_SLOTS * SLOT_W)   /* right edge */
#define ARMOR_Y   (HEART_Y - 10)

/* ---- panel + hotbar ---- */

/* MC stack count: only when > 1, white + shadow, right-aligned so the last
 * digit ends on the icon's right column, digits on its bottom rows
 * (RenderItem: x + 19 - 2 - width, y + 6 + 3). (ix,iy) = the 16x16 icon's
 * top-left. */
static void draw_count(uint8_t *fb, int ix, int iy, int v)
{
    if (v <= 1)
        return;
    char b[8];
    fmt_int(b, v > 99 ? 99 : v);
    mc_text(fb, ix + 17 - mc_text_width(b, 1), iy + 9, b, PAL_WHITE, 1);
}

/* UI U3: 16x16 tile blit that skips the TEX_KEY texels (item icons are
 * transparent; whatever the cell already painted shows through). Portable:
 * the same bytes land on host and calc. */
static void blit16_t(uint8_t *fb, int x, int y, const uint8_t *t)
{
    for (int ty = 0; ty < 16; ty++) {
        uint8_t *row = fb + (y + ty) * SCREEN_W + x;
        for (int tx = 0; tx < 16; tx++) {
            uint8_t c = t[ty * 16 + tx];
            if (c != TEX_KEY)
                row[tx] = c;
        }
    }
}

/* thumbnail of a block or item id at (x,y): blocks keep the opaque tile
 * copy (block tiles carry no key), items go through the keyed blit */
static void thumb16(uint8_t *fb, int x, int y, uint8_t id)
{
    const uint8_t *t = tex_data[id_side_tile(id)];
    if (id >= ITEM_BASE) {
        blit16_t(fb, x, y, t);
        return;
    }
    for (int ty = 0; ty < 16; ty++)
        memcpy(fb + (y + ty) * SCREEN_W + x, t + ty * 16, 16);
}

/* ---- push3 HAND: the held item in first person ----
 * Fixed 48x48 box (HAND_X, HAND_Y) bottom-right, full-res, over the world.
 * A block is a small isometric cube: column-major, per column the top-face
 * rhombus rows then 24 side rows (left face bank SHADE_X, right SHADE_Z).
 * The top texel is (u, v) = ((x + 2y - 23) / 3, (2y - x + 24) / 3), read
 * through hand_d[] = floor(n / 3) clamped to 0..15 (index n + 1, n = -1..48)
 * followed by the same values * 16. Items (and the torch/sapling, which are
 * not cubes) are their 16x16 tile scaled 3x, keyed (items: TEX_KEY;
 * torch/sapling: the tile's corner texel, their inset background, like the
 * S4 sapling sprite). On the calc the whole cube and the 3x icon are
 * src/hand.asm (hud.c's C loops cost ~15 ms per cube there); the C twins
 * below are the host reference (calc goldens m4/s1sky: cube, n6hud: icon). */
#ifdef __ez80__
void hand_cube_asm(uint8_t *o, const uint8_t *side);
void hand_icon_asm(uint8_t *o, const uint8_t *t, int key);
#define hand_icon hand_icon_asm
#else
static const uint8_t hand_d[100] = {       /* = src/hand.asm _hand_d */
    0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7,
    7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13,
    14, 14, 14, 15, 15, 15, 15,
    0, 0, 0, 0, 16, 16, 16, 32, 32, 32, 48, 48, 48, 64, 64, 64, 80, 80, 80,
    96, 96, 96, 112, 112, 112, 128, 128, 128, 144, 144, 144, 160, 160, 160,
    176, 176, 176, 192, 192, 192, 208, 208, 208, 224, 224, 224, 240, 240,
    240, 240
};

/* one cube column: n top pixels, then 24 side pixels */
static void hand_col(uint8_t *p, const uint8_t *va, int k, int n,
                     const uint8_t *s, int bank, const uint8_t *top)
{
    for (; n; n--, p += SCREEN_W, va += 2)
        *p = top[(uint8_t)(va[0] + va[k])];
    for (int v = 0; v < 8; v++, s += 32) {
        uint8_t c = (uint8_t)(s[0] | bank);
        p[0] = p[SCREEN_W] = c;
        p[2 * SCREEN_W] = (uint8_t)(s[16] | bank);
        p += 3 * SCREEN_W;
    }
}

static void hand_icon(uint8_t *o, const uint8_t *t, int key)
{
    for (int v = 0; v < 16; v++, t += 16)
        for (int r = 0; r < 3; r++, o += SCREEN_W)
            for (int u = 0; u < 16; u++)
                if (t[u] != key)
                    o[3 * u] = o[3 * u + 1] = o[3 * u + 2] = t[u];
}
#endif

static void hud_hand(uint8_t *fb)
{
    uint8_t id = hotbar_id(plr.hotbar_sel);
    if (!id)
        return;                              /* empty hand: nothing */
    uint8_t *o = fb + HAND_Y * SCREEN_W + HAND_X;
    const uint8_t *t = tex_data[id_side_tile(id)];   /* icon / side tile */
    if (id >= ITEM_BASE || id == B_TORCH || id == B_SAPLING) {
        hand_icon(o, t, id >= ITEM_BASE ? TEX_KEY : t[0]);
        return;
    }
    const uint8_t *top = tex_data[block_tex[id][0]];
#ifdef __ez80__
    render_tpage(top);
    hand_cube_asm(o, t);
#else
    for (int x = 0; x < 48; x++, o++) {
        int h = x < 24 ? x : 47 - x;          /* distance from an edge */
        int y = 11 - (h >> 1);                /* top face: 2 + 2(h/2) rows */
        /* v entry hand_d[50 + 2y - x + 25], u entry hand_d[2y + x - 22]:
         * k = 2x - 97; side column u = 2 (x mod 24) / 3 */
        hand_col(o + y * SCREEN_W, hand_d + 75 + 2 * y - x, 2 * x - 97,
                 2 + (h & ~1), t + hand_d[(x < 24 ? 2 * x : 2 * x - 48) + 1],
                 x < 24 ? SHADE_X << 6 : SHADE_Z << 6, top);
    }
#endif
}

/* one overlay restore: full viewport -> a compositor rect (full-res);
 * windowed viewports -> 1 = redraw the letterbox instead */
static uint8_t ov_rect(int x0, int y0, int x1, int y1)
{
    if (g_viewport)
        return 1;
    compose_add_rect(x0, y0, x1, y1);
    return 0;
}

/* the compositor restore rects for the overlays hud_draw / hud_crosshair
 * draw after compose_frame (moved here from main.c's game loop so the host
 * --compose test runs the same logic). Returns 1 when a windowed viewport
 * needs its letterbox redrawn instead (render_present). */
uint8_t hud_restore_rects(void)
{
    static uint8_t pv_nameblk, pv_named, pv_bar, pv_dbg, pv_sel, pv_arm,
                   pv_hand;
    uint8_t bc = 0;
    uint8_t named = plr.name_ticks > 0;
    if (plr.name_block != pv_nameblk || named != pv_named)
        bc |= ov_rect(80, 178, 240, 207);   /* popup (HUD_NAME_Y_SURV/_CRE
                                               + shadow) */
    pv_nameblk = plr.name_block;
    pv_named = named;
    uint8_t bar = plr.mode == MODE_SURVIVAL && plr.break_ticks;
    if (bar || pv_bar)                      /* break bar: inside the view */
        compose_add_rect(140, 128, 180, 138);
    pv_bar = bar;
    if (hud_debug || pv_dbg)
        bc |= ov_rect(0, 0, 96, 52);        /* fps readout */
    pv_dbg = hud_debug;
    /* slot marker: the whole marker band. push3 HAND: the old (0,209)-
     * (320,211) left its bottom row 230 and the slot-0 left / slot-8 right
     * columns stale (found by --compose with the HUD) */
    if (plr.hotbar_sel != pv_sel)
        bc |= ov_rect(SLOT_X0 - 1, SLOT_Y - 1,
                      SLOT_X0 + HOTBAR_SLOTS * SLOT_W + 1, SLOT_Y + 21);
    pv_sel = plr.hotbar_sel;
    /* UI U3: the armour row (ARMOR_Y 189, 10 icons from x 70) disappears
     * when the last piece comes off / on death */
    uint8_t arm = plr.mode == MODE_SURVIVAL && armor_pct() > 0;
    if (pv_arm && !arm)
        bc |= ov_rect(70, 189, 151, 198);
    pv_arm = arm;
    /* push3 HAND: a different held id (or empty/non-empty) leaves the old
     * hand's pixels where the new one is transparent or absent */
    uint8_t hand = hotbar_id(plr.hotbar_sel);
    if (hand != pv_hand)
        bc |= ov_rect(HAND_X, HAND_Y, HAND_X + 48, HAND_Y + 48);
    pv_hand = hand;
    return bc;
}

void hud_draw(uint8_t *fb)
{
    hud_hand(fb);

    /* overlay HUD: no band — hearts + hunger + armor float over the world.
     * MC layout: hearts left (tight), hunger right, armor row above hearts. */
    if (plr.mode == MODE_SURVIVAL) {
        for (int i = 0; i < 10; i++)
            draw_hud_icon(fb, HEART_X0 + i * ICON_DX, HEART_Y,
                          i < plr.health ? HI_HEART_FULL : HI_HEART_EMPTY);
        /* hunger: 10 shanks of 2 points; MC fills from the RIGHT (icon 0 is
         * the rightmost): full if 2i+1 < hunger, half if 2i+1 == hunger */
        for (int i = 0; i < 10; i++) {
            int p = i * 2 + 1;
            draw_hud_icon(fb, HUNGER_X1 - 9 - i * ICON_DX, HEART_Y,
                          p < plr.hunger ? HI_FOOD_FULL :
                          p == plr.hunger ? HI_FOOD_HALF : HI_FOOD_EMPTY);
        }
        /* armor: proportional to the equipped reduction, hidden when none */
        int ap = armor_pct();
        if (ap > 0) {
            int af = (ap * 10 + 42) / 85;        /* 0..10 filled icons */
            for (int i = 0; i < 10; i++)
                draw_hud_icon(fb, HEART_X0 + i * ICON_DX, ARMOR_Y,
                              i < af ? HI_ARMOR_FULL : HI_ARMOR_EMPTY);
        }
    }

    /* hotbar: the reference's 20px slot sprite, 9 slots. Survival slots are
     * assignable (0 = empty -> bare sprite); creative shows the fixed bar. */
    for (int s = 0; s < HOTBAR_SLOTS; s++) {
        int x0 = SLOT_X0 + s * SLOT_W;
        /* clean recessed slot: a 2px light-gray border around a dark inset
         * (a filled slot's 16x16 thumbnail covers the inset). Drawn
         * procedurally — the baked reference sprite's indices were scrambled
         * by the M21 texture requant and showed as coloured stripes. */
        for (int y = 0; y < 20; y++)
            memset(fb + (SLOT_Y + y) * SCREEN_W + x0, GRAY_LT, 20);
        for (int y = 2; y < 18; y++)
            memset(fb + (SLOT_Y + y) * SCREEN_W + x0 + 2, GRAY_DK, 16);
        uint8_t id = hotbar_id(s);
        if (id) {
            thumb16(fb, x0 + 2, SLOT_Y + 2, id);
            if (plr.mode == MODE_SURVIVAL)
                draw_count(fb, x0 + 2, SLOT_Y + 2, plr.hotbar[s].count);
        }
        if (s == plr.hotbar_sel) {
            for (int i = -1; i <= 20; i++) {
                fb[(SLOT_Y - 1) * SCREEN_W + x0 + i] = PAL_WHITE;
                fb[(SLOT_Y + 20) * SCREEN_W + x0 + i] = PAL_WHITE;
            }
            for (int i = -1; i <= 20; i++) {
                fb[(SLOT_Y + i) * SCREEN_W + x0 - 1] = PAL_WHITE;
                fb[(SLOT_Y + i) * SCREEN_W + x0 + 20] = PAL_WHITE;
            }
        }
    }
}


/* N6: deterministic survival HUD seed for the autotest golden. Health 7/10,
 * hunger 13/20 (six full drumsticks + a half), helmet + chestplate equipped
 * (45% -> ~5 armor icons), and a small stocked hotbar. */
void hud_n6_demo(void)
{
    plr.mode = MODE_SURVIVAL;
    plr.health = 7;
    plr.hunger = 13;
    plr.hotbar_sel = 2;     /* push3 HAND: the cooked porkchop in hand, so
                               the calc golden covers the 3x item path */
    for (int i = 0; i < HOTBAR_SLOTS; i++)
        plr.hotbar[i].id = plr.hotbar[i].count = 0;
    for (int i = 0; i < ARMOR_SLOTS; i++)
        plr.armor[i].id = plr.armor[i].count = 0;
    plr.hotbar[0].id = B_STONE;  plr.hotbar[0].count = 12;
    plr.hotbar[1].id = B_PLANKS; plr.hotbar[1].count = 30;
    plr.hotbar[2].id = I_PORKCHOP_COOKED; plr.hotbar[2].count = 3;
    plr.armor[0].id = I_HELMET_IRON; plr.armor[0].count = 1;
    plr.armor[1].id = I_CHEST_IRON;  plr.armor[1].count = 1;
}

/* ================= N2: unified MATTIS inventory + crafting =================
 * A single full-screen panel replaces the old bitmap invpanel + the separate
 * console crafting screen. Top: category tabs (BLOCKS/TOOLS/ITEMS), a
 * horizontally scrollable recipe strip, and a detail band that shows either
 * the selected recipe (ingredients have/need + output + gate lock) or the
 * hovered stack's name. Bottom: the player grids — 27 backpack + 9 hotbar +
 * 4 armor — each stack drawn ONCE with its count. A cursor carries a
 * picked-up stack between slots. Kept legible at 320x240 (the user's #1
 * complaint about the old triple-drawn panel). */

/* ---- layout constants ---- */
#define IB_CELL      18                 /* grid slot pitch (16 thumb + border) */

#define IB_TAB_Y      4
#define IB_TAB_H     16
#define IB_TAB_W     72
#define IB_TAB_GAP    8
#define IB_TAB_X0    44                 /* (320 - (3*72 + 2*8)) / 2 */

#define IB_STRIP_X0  16
#define IB_STRIP_X1 304
#define IB_STRIP_Y   26
#define IB_STRIP_H   22
#define IB_SCELL     20                 /* recipe-strip cell pitch */
#define IB_STRIP_VIS 14                 /* visible recipe cells */

#define IB_DET_Y0    52
#define IB_DET_Y1   100

#define IB_ARM_X     66
#define IB_GRID_X    94                 /* 66 + 18 + 10 */
#define IB_GRID_Y   106
#define IB_HOT_Y   (IB_GRID_Y + 3 * IB_CELL + 6)   /* 166 */
#define IB_HINT_Y   210

/* slot cell colors (palette-bank grays) */
#define CELL_BORDER  GRAY_LT
#define CELL_INSET   GRAY_DK

static const char *const cat_names[CAT_COUNT] = { "Blocks", "Tools", "Items" };

/* full-screen tinted-dirt background */
static void inv_bg(uint8_t *fb)
{
    const uint8_t *d = tex_data[T_DIRT];
    for (int y = 0; y < SCREEN_H; y++) {
        uint8_t *row = fb + y * SCREEN_W;
        if (y >= 16) {               /* 16-row pattern: copy, don't recompute */
            memcpy(row, row - 16 * SCREEN_W, SCREEN_W);
            continue;
        }
        const uint8_t *tr = d + (y & 15) * 16;
        for (int x = 0; x < SCREEN_W; x++)
            row[x] = (uint8_t)(tr[x & 15] | 128);
    }
}

/* filled rect + black border + white top bevel (matches the old tab/panel look) */
static void inv_panel(uint8_t *fb, int x0, int y0, int x1, int y1, uint8_t body)
{
    for (int y = y0; y < y1; y++)
        memset(fb + y * SCREEN_W + x0, body, (size_t)(x1 - x0));
    memset(fb + y0 * SCREEN_W + x0, PAL_BLACK, (size_t)(x1 - x0));
    memset(fb + (y1 - 1) * SCREEN_W + x0, PAL_BLACK, (size_t)(x1 - x0));
    for (int y = y0; y < y1; y++) {
        fb[y * SCREEN_W + x0] = PAL_BLACK;
        fb[y * SCREEN_W + x1 - 1] = PAL_BLACK;
    }
    memset(fb + (y0 + 1) * SCREEN_W + x0 + 1, PAL_WHITE, (size_t)(x1 - x0 - 2));
}

static void inv_thumb(uint8_t *fb, int cx, int cy, uint8_t id)
{
    thumb16(fb, cx, cy, id);
}

/* a recessed slot cell of the given pitch (border + dark inset) */
static void inv_cell(uint8_t *fb, int x0, int y0, int pitch)
{
    for (int y = 0; y < pitch; y++)
        memset(fb + (y0 + y) * SCREEN_W + x0, CELL_BORDER, (size_t)pitch);
    for (int y = 1; y < pitch - 1; y++)
        memset(fb + (y0 + y) * SCREEN_W + x0 + 1, CELL_INSET,
               (size_t)(pitch - 2));
}

/* stack thumb + count inside a cell whose inner corner is (cx,cy) */
static void inv_stack(uint8_t *fb, int cx, int cy, slot_t s)
{
    if (!s.count)
        return;
    inv_thumb(fb, cx, cy, s.id);
    draw_count(fb, cx, cy, s.count);
}

/* white 1px frame `pitch` on a side, top-left corner (x0,y0) */
static void inv_frame(uint8_t *fb, int x0, int y0, int pitch)
{
    for (int i = 0; i < pitch; i++) {
        fb[y0 * SCREEN_W + x0 + i] = PAL_WHITE;
        fb[(y0 + pitch - 1) * SCREEN_W + x0 + i] = PAL_WHITE;
        fb[(y0 + i) * SCREEN_W + x0] = PAL_WHITE;
        fb[(y0 + i) * SCREEN_W + x0 + pitch - 1] = PAL_WHITE;
    }
}

/* a 9-wide grid of n slots at (x0,y0): cells + stacks, the red held-slot
 * marker under slot `mark` (hotbar), then the white cursor frame on slot
 * `cur` (-1 = none). Shared by the inventory, furnace and chest screens. */
static void inv_grid9(uint8_t *fb, int x0, int y0, const slot_t *sl, int n,
                      int cur, int mark)
{
    for (int s = 0; s < n; s++) {
        int x = x0 + (s % 9) * IB_CELL, y = y0 + (s / 9) * IB_CELL;
        inv_cell(fb, x, y, IB_CELL);
        inv_stack(fb, x + 1, y + 1, sl[s]);
        if (s == mark)
            for (int i = 2; i < IB_CELL - 2; i++)
                fb[(y + IB_CELL - 1) * SCREEN_W + x + i] = pal_red_idx;
    }
    if (cur >= 0)
        inv_frame(fb, x0 + (cur % 9) * IB_CELL, y0 + (cur / 9) * IB_CELL,
                  IB_CELL);
}

/* the player's backpack + hotbar under any screen, with the cursor frame
 * in whichever of the two is focused */
static void inv_player_grids(uint8_t *fb, int main_cur, int hot_cur)
{
    inv_grid9(fb, IB_GRID_X, IB_GRID_Y, plr.main_inv, MAIN_SLOTS, main_cur, -1);
    inv_grid9(fb, IB_GRID_X, IB_HOT_Y, plr.hotbar, HOTBAR_SLOTS, hot_cur,
              plr.hotbar_sel);
}

/* small padlock glyph (3-bit rows) for gated recipes */
static const uint8_t lock_px[7] = { 0x1C, 0x22, 0x22, 0x7F, 0x7F, 0x5D, 0x7F };
static void inv_lock(uint8_t *fb, int x, int y, uint8_t col)
{
    for (int r = 0; r < 7; r++)
        for (int b = 0; b < 7; b++)
            if (lock_px[r] & (0x40 >> b))
                fb[(y + r) * SCREEN_W + x + b] = col;
}

/* "xN" (MC/LCE lowercase x) */
static void inv_xn(uint8_t *fb, int x, int y, int n, uint8_t col)
{
    char b[8];
    b[0] = 'x';
    fmt_int(b + 1, n);
    mc_text(fb, x, y, b, col, 1);
}

/* ---- recipe-strip scroll bookkeeping (shared by draw + input) ---- */
static void strip_clamp(inv_ui_t *ui, int n)
{
    if (n <= 0) { ui->strip_sel = 0; ui->strip_scroll = 0; return; }
    if (ui->strip_sel >= n) ui->strip_sel = (uint8_t)(n - 1);
    if (ui->strip_sel < ui->strip_scroll)
        ui->strip_scroll = ui->strip_sel;
    if (ui->strip_sel >= ui->strip_scroll + IB_STRIP_VIS)
        ui->strip_scroll = (uint8_t)(ui->strip_sel - IB_STRIP_VIS + 1);
    if (ui->strip_scroll + IB_STRIP_VIS > n) {
        int s = n - IB_STRIP_VIS;
        ui->strip_scroll = (uint8_t)(s < 0 ? 0 : s);
    }
}

/* recipe is craftable right now (ingredients present AND gate satisfied) */
static bool recipe_ready(const recipe_t *r, const inv_ui_t *ui)
{
    if (r->needs_table && !ui->has_table)
        return false;
    return craft_can(r);
}

/* ---- the crafting region (tabs + strip + detail) ---- */
static void draw_craft_region(uint8_t *fb, const inv_ui_t *ui,
                              const uint8_t *idx, int n)
{
    /* category tabs */
    for (int t = 0; t < CAT_COUNT; t++) {
        int x0 = IB_TAB_X0 + t * (IB_TAB_W + IB_TAB_GAP);
        int x1 = x0 + IB_TAB_W;
        bool on = (t == ui->tab);
        inv_panel(fb, x0, IB_TAB_Y, x1, IB_TAB_Y + IB_TAB_H,
                  on ? GRAY_LT : GRAY_DK);
        int tw = mc_text_width(cat_names[t], 1) - 1;
        mc_text(fb, x0 + (IB_TAB_W - tw) / 2, IB_TAB_Y + 4, cat_names[t],
                on ? PAL_BLACK : PAL_WHITE, 1);
    }
    if (ui->focus == FOC_TABS) {
        int x0 = IB_TAB_X0 + ui->tab * (IB_TAB_W + IB_TAB_GAP);
        for (int i = 0; i < IB_TAB_W; i++) {
            fb[(IB_TAB_Y - 1) * SCREEN_W + x0 + i] = PAL_WHITE;
            fb[(IB_TAB_Y + IB_TAB_H) * SCREEN_W + x0 + i] = PAL_WHITE;
        }
    }

    /* recipe strip */
    inv_panel(fb, IB_STRIP_X0, IB_STRIP_Y, IB_STRIP_X1,
              IB_STRIP_Y + IB_STRIP_H, GRAY_DK);
    for (int c = 0; c < IB_STRIP_VIS; c++) {
        int li = ui->strip_scroll + c;
        if (li >= n) break;
        const recipe_t *r = &recipes[idx[li]];
        int cx = IB_STRIP_X0 + 4 + c * IB_SCELL;
        int cy = IB_STRIP_Y + 3;
        inv_cell(fb, cx, cy, IB_SCELL - 2);
        inv_thumb(fb, cx + 1, cy + 1, r->out);
        bool gated = r->needs_table && !ui->has_table;
        if (gated)
            inv_lock(fb, cx + 9, cy + 9, pal_red_idx);
        else if (!craft_can(r))
            inv_lock(fb, cx + 9, cy + 9, GRAY_MD);
        if (li == ui->strip_sel && ui->focus == FOC_STRIP)
            inv_frame(fb, cx - 1, cy - 1, IB_SCELL);
    }
    /* scroll hints: a small triangle on each side that has more recipes */
    if (ui->strip_scroll > 0)
        for (int i = 0; i < 5; i++)
            memset(fb + (IB_STRIP_Y + 6 + i) * SCREEN_W + IB_STRIP_X0 + 5 - (i < 3 ? i : 4 - i),
                   PAL_WHITE, 1);
    if (ui->strip_scroll + IB_STRIP_VIS < n)
        for (int i = 0; i < 5; i++)
            memset(fb + (IB_STRIP_Y + 6 + i) * SCREEN_W + IB_STRIP_X1 - 6,
                   PAL_WHITE, (size_t)(i < 3 ? i + 1 : 5 - i));

    /* detail band */
    inv_panel(fb, IB_STRIP_X0, IB_DET_Y0, IB_STRIP_X1, IB_DET_Y1, GRAY_DK);
    if (n <= 0)
        return;
    const recipe_t *r = &recipes[idx[ui->strip_sel]];
    bool gated = r->needs_table && !ui->has_table;
    bool ready = recipe_ready(r, ui);

    /* output name */
    mc_text(fb, IB_STRIP_X0 + 6, IB_DET_Y0 + 5, block_names[r->out],
            ready ? PAL_WHITE : GRAY_MD, 1);

    /* ingredients row: thumb + xNeed + have (black if short: red on the
     * mid-grey band was illegible; flat black, like the button labels) */
    for (int i = 0; i < r->n_in; i++) {
        int x = IB_STRIP_X0 + 6 + i * 78;
        int y = IB_DET_Y0 + 18;
        uint8_t id = r->in[i].id;
        int need = r->in[i].count, have = inv_count(id);
        uint8_t col = have >= need ? PAL_WHITE : PAL_BLACK;
        inv_thumb(fb, x, y, id);
        inv_xn(fb, x + 18, y, need, col);
        char h[8];
        fmt_int(h, have > 999 ? 999 : have);
        mc_text(fb, x + 18, y + 9, h, col, 1);
    }

    /* arrow (manual chevron) + output thumb on the right */
    {
        int ax = IB_STRIP_X1 - 60, ay = IB_DET_Y0 + 26;
        memset(fb + ay * SCREEN_W + ax, PAL_WHITE, 10);
        for (int i = 0; i < 4; i++) {
            fb[(ay - i) * SCREEN_W + ax + 9 - i] = PAL_WHITE;
            fb[(ay + i) * SCREEN_W + ax + 9 - i] = PAL_WHITE;
        }
    }
    int ox = IB_STRIP_X1 - 42, oy = IB_DET_Y0 + 18;   /* thumb 70..85 */
    inv_cell(fb, ox - 1, oy - 1, 18);
    inv_thumb(fb, ox, oy, r->out);
    if (r->out_count > 1)
        draw_count(fb, ox, oy, r->out_count);

    if (gated)
        mc_text(fb, IB_STRIP_X0 + 6, IB_DET_Y1 - 11, "Needs a Crafting Table",
                PAL_BLACK, 1);
}

/* ---- the player grids (backpack + hotbar + armor) ---- */
static const char *const armor_lbl[ARMOR_SLOTS] = { "H", "C", "L", "B" };

static void draw_player_region(uint8_t *fb, const inv_ui_t *ui)
{
    /* backpack 3x9 + hotbar row */
    inv_player_grids(fb, ui->focus == FOC_MAIN ? ui->main_cur : -1,
                     ui->focus == FOC_HOT ? ui->hot_cur : -1);

    /* armor column */
    for (int s = 0; s < ARMOR_SLOTS; s++) {
        int x0 = IB_ARM_X, y0 = IB_GRID_Y + s * IB_CELL;
        inv_cell(fb, x0, y0, IB_CELL);
        if (plr.armor[s].count)
            inv_stack(fb, x0 + 1, y0 + 1, plr.armor[s]);
        else                                     /* empty: slot-kind letter */
            mc_text(fb, x0 + 7, y0 + 5, armor_lbl[s], GRAY_MD, 1);
    }
    if (ui->focus == FOC_ARMOR)
        inv_frame(fb, IB_ARM_X, IB_GRID_Y + ui->arm_cur * IB_CELL, IB_CELL);
}

/* the hovered stack (for the detail band when a grid is focused) */
static slot_t hovered_stack(const inv_ui_t *ui)
{
    slot_t z = { 0, 0 };
    switch (ui->focus) {
    case FOC_MAIN:  return plr.main_inv[ui->main_cur];
    case FOC_HOT:   return plr.hotbar[ui->hot_cur];
    case FOC_ARMOR: return plr.armor[ui->arm_cur];
    default:        return z;
    }
}

/* creative: a simple palette picker over the fixed 9 blocks */
static void draw_creative(uint8_t *fb, const inv_ui_t *ui)
{
    inv_bg(fb);
    mc_text_center(fb, 40, "Select Block", PAL_WHITE, 2);
    int x0 = (SCREEN_W - HOTBAR_SLOTS * (IB_CELL + 4)) / 2;
    for (int s = 0; s < HOTBAR_SLOTS; s++) {
        int x = x0 + s * (IB_CELL + 4), y = 110;
        inv_cell(fb, x, y, IB_CELL);
        inv_thumb(fb, x + 1, y + 1, hotbar_blocks[s]);
        if (s == ui->hot_cur)
            inv_frame(fb, x, y, IB_CELL);
    }
    mc_text_center(fb, 140, block_names[hotbar_blocks[ui->hot_cur]],
                   PAL_WHITE, 2);
    mc_text_center(fb, IB_HINT_Y, "Left/Right Pick   2nd Select   Clear Exit",
                   GRAY_LT, 1);
}

void hud_inventory_screen(uint8_t *fb, const inv_ui_t *ui)
{
    if (plr.mode != MODE_SURVIVAL) {
        draw_creative(fb, ui);
        return;
    }

    inv_bg(fb);

    uint8_t idx[RECIPE_COUNT];
    int n = craft_list(ui->tab, idx);
    draw_craft_region(fb, ui, idx, n);
    draw_player_region(fb, ui);

    /* detail band shows the hovered stack when a grid is focused (the craft
     * region already draws recipe detail for the tab/strip focus) */
    if (ui->focus >= FOC_MAIN) {
        slot_t hv = hovered_stack(ui);
        inv_panel(fb, IB_STRIP_X0, IB_DET_Y0, IB_STRIP_X1, IB_DET_Y1, GRAY_DK);
        if (hv.count) {
            /* MC tooltip style: name + count at scale 1 beside the icon */
            inv_thumb(fb, IB_STRIP_X0 + 8, IB_DET_Y0 + 16, hv.id);
            mc_text(fb, IB_STRIP_X0 + 30, IB_DET_Y0 + 16, block_names[hv.id],
                    PAL_WHITE, 1);
            inv_xn(fb, IB_STRIP_X0 + 30, IB_DET_Y0 + 26, hv.count, GRAY_LT);
        } else {
            mc_text(fb, IB_STRIP_X0 + 8, IB_DET_Y0 + 20, "Empty", GRAY_LT, 1);
        }
    }

    /* the carried stack rides just off the focused cursor cell */
    if (ui->cursor.count) {
        int cx = 0, cy = 0;
        switch (ui->focus) {
        case FOC_MAIN:
            cx = IB_GRID_X + (ui->main_cur % 9) * IB_CELL;
            cy = IB_GRID_Y + (ui->main_cur / 9) * IB_CELL; break;
        case FOC_HOT:
            cx = IB_GRID_X + ui->hot_cur * IB_CELL; cy = IB_HOT_Y; break;
        case FOC_ARMOR:
            cx = IB_ARM_X; cy = IB_GRID_Y + ui->arm_cur * IB_CELL; break;
        default:
            cx = IB_GRID_X; cy = IB_GRID_Y; break;
        }
        cx += 7; cy += 7;
        if (cx > SCREEN_W - 17) cx = SCREEN_W - 17;
        if (cy > SCREEN_H - 17) cy = SCREEN_H - 17;
        inv_stack(fb, cx, cy, ui->cursor);
    }

    /* key hints */
    mc_text_center(fb, IB_HINT_Y,
                   "2nd Pick/Place   Del Return   1-9 Hotbar   Clear Exit",
                   GRAY_LT, 1);
}

/* ===================== interaction state machine ===================== */

void inv_ui_reset(inv_ui_t *ui)
{
    memset(ui, 0, sizeof *ui);
    ui->focus = plr.mode == MODE_SURVIVAL ? FOC_MAIN : FOC_HOT;
    ui->hot_cur = plr.hotbar_sel < HOTBAR_SLOTS ? plr.hotbar_sel : 0;
}

/* Shared pickup/place core over a carried stack + its origin slot. Used by both
 * the inventory and furnace UIs. armor_slot = destination accepts armor only;
 * out_only = destination is a furnace output (take/merge-out only, no place). */
static void slot_move(slot_t *cur, slot_t **origin, slot_t *dst,
                      bool armor_slot, bool out_only)
{
    if (out_only) {
        if (cur->count == 0) {                    /* take from output */
            if (dst->count == 0) return;
            *cur = *dst; dst->id = 0; dst->count = 0; *origin = dst;
        } else if (dst->count && dst->id == cur->id &&
                   !IS_SINGLE(cur->id)) {
            int cap = inv_stack_cap(cur->id);      /* pull more into the hand */
            int room = cap - cur->count;
            int mv = dst->count < room ? dst->count : room;
            cur->count = (uint8_t)(cur->count + mv);
            dst->count = (uint8_t)(dst->count - mv);
            if (dst->count == 0) dst->id = 0;
        }
        return;                                    /* never place INTO output */
    }
    if (cur->count == 0) {                          /* pick up */
        if (dst->count == 0) return;
        *cur = *dst; dst->id = 0; dst->count = 0; *origin = dst;
        return;
    }
    if (armor_slot && !IS_ARMOR(cur->id))           /* armor rejects non-armor */
        return;
    if (dst->count == 0) {                           /* place all */
        *dst = *cur; cur->id = 0; cur->count = 0; *origin = NULL;
    } else if (dst->id == cur->id && !IS_SINGLE(cur->id)) {
        int cap = inv_stack_cap(dst->id);            /* merge */
        int room = cap - dst->count;
        int mv = cur->count < room ? cur->count : room;
        dst->count = (uint8_t)(dst->count + mv);
        cur->count = (uint8_t)(cur->count - mv);
        if (cur->count == 0) { cur->id = 0; *origin = NULL; }
    } else {                                         /* swap */
        slot_t t = *dst; *dst = *cur; *cur = t; *origin = NULL;
    }
}

/* Del / close: return the carried stack to its origin (or the inventory) */
static void carry_return(slot_t *cur, slot_t **origin)
{
    if (!cur->count)
        return;
    if (*origin && (*origin)->count == 0) {
        **origin = *cur;
    } else {
        int left = inv_add(cur->id, cur->count);
        if (left) {                    /* no room anywhere: keep it carried */
            cur->count = (uint8_t)left;
            return;
        }
    }
    cur->id = 0; cur->count = 0;
    *origin = NULL;
}

/* thin inventory-UI wrappers */
static void slot_action(inv_ui_t *ui, slot_t *dst, bool armor_slot)
{
    slot_move(&ui->cursor, &ui->origin, dst, armor_slot, false);
}
static void return_carry(inv_ui_t *ui)
{
    carry_return(&ui->cursor, &ui->origin);
}

int inv_ui_input(inv_ui_t *ui, uint8_t ev, int digit)
{
    /* creative: palette picker */
    if (plr.mode != MODE_SURVIVAL) {
        if (ev & EV_LEFT)  { if (ui->hot_cur > 0) ui->hot_cur--; }
        if (ev & EV_RIGHT) { if (ui->hot_cur < HOTBAR_SLOTS - 1) ui->hot_cur++; }
        if (ev & EV_ENTER) {
            plr.hotbar_sel = ui->hot_cur;
            ui->last_craft = hotbar_blocks[ui->hot_cur];
            return 1;
        }
        if (ev & EV_CLOSE) return 1;
        return 0;
    }

    if (ev & EV_CLOSE) {
        /* return_carry always succeeds: a carried stack was picked up from a
         * slot that is still vacated, so inv_add/origin always has room */
        return_carry(ui);
        return 1;
    }

    uint8_t idx[RECIPE_COUNT];
    int n = craft_list(ui->tab, idx);

    switch (ui->focus) {
    case FOC_TABS:
        if ((ev & EV_LEFT) && ui->tab > 0) {
            ui->tab--; ui->strip_sel = 0; ui->strip_scroll = 0;
        }
        if ((ev & EV_RIGHT) && ui->tab < CAT_COUNT - 1) {
            ui->tab++; ui->strip_sel = 0; ui->strip_scroll = 0;
        }
        if (ev & (EV_DOWN | EV_ENTER)) ui->focus = FOC_STRIP;
        break;

    case FOC_STRIP:
        if ((ev & EV_LEFT) && ui->strip_sel > 0) ui->strip_sel--;
        if ((ev & EV_RIGHT) && ui->strip_sel < n - 1) ui->strip_sel++;
        if (ev & EV_UP)   ui->focus = FOC_TABS;
        if (ev & EV_DOWN) ui->focus = FOC_MAIN;
        if ((ev & EV_ENTER) && n > 0) {
            const recipe_t *r = &recipes[idx[ui->strip_sel]];
            if (recipe_ready(r, ui)) {
                craft_apply(r);
                ui->last_craft = r->out;
            }
        }
        strip_clamp(ui, n);
        break;

    case FOC_MAIN: {
        int col = ui->main_cur % 9, row = ui->main_cur / 9;
        if (ev & EV_LEFT) {
            if (col > 0) ui->main_cur--;
            else { ui->focus = FOC_ARMOR; ui->arm_cur = (uint8_t)row; }
        }
        if ((ev & EV_RIGHT) && col < 8) ui->main_cur++;
        if (ev & EV_UP) {
            if (row > 0) ui->main_cur -= 9;
            else ui->focus = FOC_STRIP;
        }
        if (ev & EV_DOWN) {
            if (row < 2) ui->main_cur += 9;
            else { ui->focus = FOC_HOT; ui->hot_cur = (uint8_t)col; }
        }
        if (ev & EV_ENTER) slot_action(ui, &plr.main_inv[ui->main_cur], false);
        if (ev & EV_DEL) return_carry(ui);
        if (digit >= 0 && ui->cursor.count == 0) {
            slot_t t = plr.main_inv[ui->main_cur];
            plr.main_inv[ui->main_cur] = plr.hotbar[digit];
            plr.hotbar[digit] = t;
        }
        break;
    }

    case FOC_HOT:
        if ((ev & EV_LEFT) && ui->hot_cur > 0) ui->hot_cur--;
        if ((ev & EV_RIGHT) && ui->hot_cur < HOTBAR_SLOTS - 1) ui->hot_cur++;
        if (ev & EV_UP) { ui->focus = FOC_MAIN; ui->main_cur = (uint8_t)(18 + ui->hot_cur); }
        if (ev & EV_ENTER) slot_action(ui, &plr.hotbar[ui->hot_cur], false);
        if (ev & EV_DEL) return_carry(ui);
        if (digit >= 0 && ui->cursor.count == 0 && digit != ui->hot_cur) {
            slot_t t = plr.hotbar[ui->hot_cur];
            plr.hotbar[ui->hot_cur] = plr.hotbar[digit];
            plr.hotbar[digit] = t;
        }
        break;

    case FOC_ARMOR:
        if ((ev & EV_UP) && ui->arm_cur > 0) ui->arm_cur--;
        if ((ev & EV_DOWN) && ui->arm_cur < ARMOR_SLOTS - 1) ui->arm_cur++;
        if (ev & EV_RIGHT) {
            ui->focus = FOC_MAIN;
            ui->main_cur = (uint8_t)((ui->arm_cur < 3 ? ui->arm_cur : 2) * 9);
        }
        if (ev & EV_ENTER) slot_action(ui, &plr.armor[ui->arm_cur], true);
        if (ev & EV_DEL) return_carry(ui);
        break;
    }
    return 0;
}

/* ---- deterministic test seed shared by calc UI_TEST + host --uiinv ---- */
void inv_ui_demo(inv_ui_t *ui)
{
    player_init();
    plr.mode = MODE_SURVIVAL;
    inv_add(B_DIRT, 34); inv_add(B_STONE, 12); inv_add(B_GRASS, 5);
    inv_add(B_LOG, 8);   inv_add(B_COBBLE, 17);
    inv_add(B_COAL_ORE, 9); inv_add(B_IRON_ORE, 3);
    inv_add(I_STICK, 24); inv_add(I_GUNPOWDER, 2); inv_add(I_PORKCHOP, 1);
    inv_add(I_COAL, 5);  inv_add(I_IRON_INGOT, 7);
    inv_add(I_PICK_WOOD, 1); inv_add(I_PICK_STONE, 1); inv_add(I_PICK_IRON, 1);
    inv_add(I_AXE_WOOD, 1);  inv_add(I_AXE_STONE, 1);
    plr.armor[0].id = I_HELMET_IRON; plr.armor[0].count = 1;
    plr.hotbar_sel = 0;

    inv_ui_reset(ui);
    ui->tab = CAT_TOOLS;
    ui->focus = FOC_STRIP;
    ui->strip_sel = 2;          /* Iron Pickaxe: short on ingots + needs a table */
    ui->has_table = 0;
}

/* ================= N4 furnace UI + push3 S2 chest UI =================
 * One container screen: the header, then either the furnace's in/fuel/out
 * slots + gauges or the chest's 3x9 grid, then the player's backpack +
 * hotbar; one state machine drives both (cont_ui_t, hud.h). */

#define FUR_SLOT    18
#define FUR_IN_X   128
#define FUR_IN_Y    40
#define FUR_FUEL_Y  82
#define FUR_OUT_X  208
#define FUR_OUT_Y   52
#define CH_Y        38                  /* chest grid rows 38..92 */

/* cursor cell top-left for the carried-stack overlay */
static void fur_cursor_xy(const cont_ui_t *ui, int *x0, int *y0)
{
    int c = ui->main_cur, y = IB_GRID_Y;
    switch (ui->focus) {
    case FUR_IN:   *x0 = FUR_IN_X;  *y0 = FUR_IN_Y;   return;
    case FUR_FUEL: *x0 = FUR_IN_X;  *y0 = FUR_FUEL_Y; return;
    case FUR_OUT:  *x0 = FUR_OUT_X; *y0 = FUR_OUT_Y;  return;
    case FUR_HOT:  c = ui->hot_cur; y = IB_HOT_Y; break;
    case CH_CHEST: c = ui->ch_cur;  y = CH_Y;     break;
    }
    *x0 = IB_GRID_X + (c % 9) * IB_CELL;
    *y0 = y + (c / 9) * IB_CELL;
}

void hud_cont_screen(uint8_t *fb, const cont_ui_t *ui)
{
    const furnace_t *f = ui->f;
    inv_bg(fb);
    mc_text_center(fb, 12, f ? "Furnace" : "Chest", PAL_WHITE, 2);

    if (!f) {
        inv_grid9(fb, IB_GRID_X, CH_Y, ui->c->slots, CHEST_SLOTS,
                  ui->focus == CH_CHEST ? ui->ch_cur : -1, -1);
    } else {
    /* input / fuel / output slots */
    inv_cell(fb, FUR_IN_X, FUR_IN_Y, FUR_SLOT);
    inv_stack(fb, FUR_IN_X + 1, FUR_IN_Y + 1, f->in);
    if (ui->focus == FUR_IN)   inv_frame(fb, FUR_IN_X, FUR_IN_Y, FUR_SLOT);
    inv_cell(fb, FUR_IN_X, FUR_FUEL_Y, FUR_SLOT);
    inv_stack(fb, FUR_IN_X + 1, FUR_FUEL_Y + 1, f->fuel);
    if (ui->focus == FUR_FUEL) inv_frame(fb, FUR_IN_X, FUR_FUEL_Y, FUR_SLOT);
    inv_cell(fb, FUR_OUT_X, FUR_OUT_Y, FUR_SLOT);
    inv_stack(fb, FUR_OUT_X + 1, FUR_OUT_Y + 1, f->out);
    if (ui->focus == FUR_OUT)  inv_frame(fb, FUR_OUT_X, FUR_OUT_Y, FUR_SLOT);

    /* flame gauge between input (top) and fuel (bottom): burn / burn_max */
    {
        int fx = FUR_IN_X + 5, fy = FUR_FUEL_Y - 16, h = 14;
        for (int y = 0; y < h; y++)
            memset(fb + (fy + y) * SCREEN_W + fx, GRAY_DK, 8);
        int fill = f->burn_max ? (int)((long)f->burn * h / f->burn_max) : 0;
        for (int y = 0; y < fill; y++)
            memset(fb + (fy + h - 1 - y) * SCREEN_W + fx, pal_red_idx, 8);
    }

    /* progress arrow input->output: progress / SMELT_TICKS */
    {
        int ax0 = FUR_IN_X + FUR_SLOT + 6, ax1 = FUR_OUT_X - 4;
        int ay = FUR_IN_Y + 6, w = ax1 - ax0;
        for (int y = 0; y < 5; y++)
            memset(fb + (ay + y) * SCREEN_W + ax0, GRAY_DK, (size_t)w);
        bool smelting = f->in.count && furnace_smelt_out(f->in.id) &&
                        (f->out.count == 0 ||
                         f->out.id == (uint8_t)furnace_smelt_out(f->in.id));
        int fill = smelting ? (int)((long)f->progress * w / SMELT_TICKS) : 0;
        for (int y = 1; y < 4; y++)
            memset(fb + (ay + y) * SCREEN_W + ax0, PAL_WHITE, (size_t)fill);
        for (int i = 0; i < 4; i++) {
            fb[(ay + 2 - i) * SCREEN_W + ax1 - 1 + i] = PAL_WHITE;
            fb[(ay + 2 + i) * SCREEN_W + ax1 - 1 + i] = PAL_WHITE;
        }
    }
    }

    /* player backpack + hotbar (the inventory grid geometry) */
    inv_player_grids(fb, ui->focus == FUR_MAIN ? ui->main_cur : -1,
                     ui->focus == FUR_HOT ? ui->hot_cur : -1);

    /* carried stack riding the cursor */
    if (ui->cursor.count) {
        int cx, cy;
        fur_cursor_xy(ui, &cx, &cy);
        cx += 7; cy += 7;
        if (cx > SCREEN_W - 17) cx = SCREEN_W - 17;
        if (cy > SCREEN_H - 17) cy = SCREEN_H - 17;
        inv_stack(fb, cx, cy, ui->cursor);
    }

    mc_text_center(fb, IB_HINT_Y,
                   "2nd Move   Del Return   1-9 Hotbar   Clear Exit",
                   GRAY_LT, 1);
}

void cont_ui_reset(cont_ui_t *ui, furnace_t *f, chest_t *c)
{
    memset(ui, 0, sizeof *ui);
    ui->f = f;
    ui->c = c;
    ui->focus = f ? FUR_IN : CH_CHEST;
    ui->hot_cur = plr.hotbar_sel < HOTBAR_SLOTS ? plr.hotbar_sel : 0;
}

/* move a cursor inside a 9-wide grid of `rows` rows; returns EV_UP / EV_DOWN
 * when the move would leave the grid at the top / bottom (the caller
 * changes zone), else 0 */
static uint8_t grid9_nav(uint8_t *cur, uint8_t rows, uint8_t ev)
{
    uint8_t col = *cur % 9, row = *cur / 9;
    if ((ev & EV_LEFT) && col > 0) (*cur)--;
    if ((ev & EV_RIGHT) && col < 8) (*cur)++;
    if (ev & EV_UP) {
        if (row > 0) *cur -= 9;
        else return EV_UP;
    }
    if (ev & EV_DOWN) {
        if (row < rows - 1) *cur += 9;
        else return EV_DOWN;
    }
    return 0;
}

int cont_ui_input(cont_ui_t *ui, uint8_t ev, int digit)
{
    furnace_t *f = ui->f;
    if (ev & EV_CLOSE) {
        carry_return(&ui->cursor, &ui->origin);
        return 1;
    }
    /* act on the focused slot: 2nd = pick/place/merge/swap, Del = return the
     * carried stack, a digit swaps the slot with that hotbar slot (not on
     * the furnace output: nothing is ever placed INTO it) */
    slot_t *sl;
    switch (ui->focus) {
    case FUR_IN:   sl = &f->in;   break;
    case FUR_FUEL: sl = &f->fuel; break;
    case FUR_OUT:  sl = &f->out;  break;
    case CH_CHEST: sl = &ui->c->slots[ui->ch_cur]; break;
    case FUR_MAIN: sl = &plr.main_inv[ui->main_cur]; break;
    default:       sl = &plr.hotbar[ui->hot_cur]; break;
    }
    bool out = ui->focus == FUR_OUT;
    if (ev & EV_ENTER) slot_move(&ui->cursor, &ui->origin, sl, false, out);
    if (ev & EV_DEL)   carry_return(&ui->cursor, &ui->origin);
    if (digit >= 0 && ui->cursor.count == 0 && !out) {
        slot_t t = *sl;
        *sl = plr.hotbar[digit];
        plr.hotbar[digit] = t;
    }

    /* navigation */
    uint8_t edge;
    switch (ui->focus) {
    case FUR_IN:
        if (ev & EV_DOWN)  ui->focus = FUR_FUEL;
        if (ev & EV_RIGHT) ui->focus = FUR_OUT;
        break;
    case FUR_FUEL:
        if (ev & EV_UP)    ui->focus = FUR_IN;
        if (ev & EV_RIGHT) ui->focus = FUR_OUT;
        if (ev & EV_DOWN)  { ui->focus = FUR_MAIN; ui->main_cur = 0; }
        break;
    case FUR_OUT:
        if (ev & EV_LEFT)  ui->focus = FUR_IN;
        if (ev & EV_DOWN)  { ui->focus = FUR_MAIN; ui->main_cur = 8; }
        break;
    case CH_CHEST:
        if (grid9_nav(&ui->ch_cur, 3, ev) == EV_DOWN) {
            ui->focus = CH_MAIN;
            ui->main_cur = (uint8_t)(ui->ch_cur - 18);
        }
        break;
    case FUR_MAIN: {
        uint8_t col = ui->main_cur % 9;
        edge = grid9_nav(&ui->main_cur, 3, ev);
        if (edge == EV_UP) {
            if (f) ui->focus = (col >= 6) ? FUR_OUT : FUR_FUEL;
            else { ui->focus = CH_CHEST; ui->ch_cur = (uint8_t)(18 + col); }
        }
        if (edge == EV_DOWN) { ui->focus = FUR_HOT; ui->hot_cur = col; }
        break;
    }
    default:                                   /* FUR_HOT / CH_HOT */
        if (grid9_nav(&ui->hot_cur, 1, ev) == EV_UP) {
            ui->focus = FUR_MAIN;
            ui->main_cur = (uint8_t)(18 + ui->hot_cur);
        }
        break;
    }
    return 0;
}

/* deterministic furnace-screen seed shared by the calc FUR_TEST build and the
 * host --n4fur eyeball/CRC (both fill the caller's furnace_t). */
void furnace_ui_demo(furnace_ui_t *ui, furnace_t *f)
{
    player_init();
    plr.mode = MODE_SURVIVAL;
    inv_add(B_IRON_ORE, 6); inv_add(I_COAL, 4);
    inv_add(I_PORKCHOP, 3); inv_add(B_STONE, 20);
    plr.hotbar_sel = 0;

    f->active = 1; f->x = 5; f->y = 4; f->z = 6;
    f->in.id = B_IRON_ORE;    f->in.count = 3;
    f->fuel.id = I_COAL;      f->fuel.count = 2;
    f->out.id = I_IRON_INGOT; f->out.count = 2;
    f->burn = 300; f->burn_max = 960; f->progress = 60;

    furnace_ui_reset(ui, f);
    ui->focus = FUR_IN;
}

/* push3 S2: deterministic chest-screen seed shared by the calc CHEST_TEST
 * build and host --s2chest (golden + logic). The chest holds the Skyblock
 * kit; then a scripted run of the REAL state machine: take the water
 * bucket to the backpack, put the hotbar's cobblestone into the chest, and
 * end carrying the iron ingots over the chest grid. */
static const uint8_t chest_demo_ev[] = {
    EV_ENTER,                                /* carry the water bucket */
    EV_DOWN, EV_DOWN, EV_DOWN,               /* chest 0 -> backpack 0 */
    EV_RIGHT, EV_RIGHT, EV_RIGHT, EV_ENTER,  /* drop it in backpack 3 */
    EV_DOWN, EV_DOWN, EV_DOWN,               /* -> hotbar 3 */
    EV_LEFT, EV_LEFT, EV_LEFT, EV_ENTER,     /* carry cobblestone x40 */
    EV_UP, EV_UP, EV_UP, EV_UP,              /* -> chest 18 */
    EV_RIGHT, EV_ENTER,                      /* into chest 19 */
    EV_DOWN, EV_LEFT, EV_LEFT, EV_ENTER,     /* backpack 0: carry ingots */
    EV_UP, EV_RIGHT, EV_UP,                  /* hover chest 10 */
};

void chest_ui_demo(chest_ui_t *ui, chest_t *c)
{
    player_init();
    plr.mode = MODE_SURVIVAL;
    inv_add(B_COBBLE, 40); inv_add(B_PLANKS, 12); inv_add(B_DIRT, 64);
    inv_add(I_STICK, 7);   inv_add(B_TORCH, 16);  inv_add(B_LOG, 5);
    inv_add(B_SAND, 30);   inv_add(B_GLASS, 4);   inv_add(I_PORKCHOP_COOKED, 3);
    inv_add(I_IRON_INGOT, 9); inv_add(I_COAL, 13); inv_add(B_DIRT, 20);
    plr.hotbar_sel = 2;

    memset(c, 0, sizeof *c);
    c->active = 1; c->x = 17; c->y = 5; c->z = 22;
    c->slots[0].id = I_BUCKET_WATER; c->slots[0].count = 1;
    c->slots[1].id = I_BUCKET_LAVA;  c->slots[1].count = 1;
    c->slots[8].id = B_SAPLING;      c->slots[8].count = 2;

    chest_ui_reset(ui, c);
    for (unsigned i = 0; i < sizeof chest_demo_ev; i++)
        chest_ui_input(ui, chest_demo_ev[i], -1);
}
