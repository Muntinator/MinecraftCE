/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * s3scene.h — push3 S3: the deterministic lava-lit night scene, shared by
 * the calc S3_TEST build (main.c) and host --s3liquid (harness.c) so their
 * framebuffers are byte-identical (autotest-s3lava.json).
 *
 * Superflat (grass @ y=3) like the N5 scene: a 3x3 stone wall at z=13, a
 * lava source and a water source poured on the grass in front of it and
 * left to the REAL liquid rules (liquids_tick until the queue is empty):
 * the lava spreads to a plus of lava flows, the water to a plus of water
 * flows, and where a lava flow touches a water flow it turns to cobble (the
 * generator rule). Lava lights the wall and the grass (light banks); stars
 * are on (g_night_sky) — the night palette itself is a palette effect and
 * not in the hashed framebuffer bytes.
 */

#ifndef S3SCENE_H
#define S3SCENE_H

#include "world.h"
#include "mesh.h"
#include "liquid.h"
#include "demo.h"

#define S3_CAM_X (16 * FIX_ONE + FIX_ONE / 2)
#define S3_CAM_Y (6 * FIX_ONE)
#define S3_CAM_Z (5 * FIX_ONE)
#define S3_YAW   0
#define S3_PITCH (-14)

static inline void s3_build_scene(void)
{
    g_worldtype = 1;                 /* superflat: grass @ y=3 */
    world_gen(DEMO_SEED);
    for (int x = 15; x <= 17; x++)   /* 3x3 stone wall facing -z */
        for (int y = 4; y <= 6; y++)
            world_set(x, y, 13, B_STONE);
    mesh_init();                     /* light field + empty liquid queue */
    liquid_set(17, 4, 10, B_LAVA);
    liquid_set(14, 4, 10, B_WATER);
    for (int t = 0; t < 64; t++)     /* settles in far fewer; no-op after */
        liquids_tick();
    g_night_sky = 1;
}

#endif
