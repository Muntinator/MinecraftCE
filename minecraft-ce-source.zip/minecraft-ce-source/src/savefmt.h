/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef SAVEFMT_H
#define SAVEFMT_H

/* savefmt.c — the portable part of the save format (calc + host harness):
 * run-length coding over a strided walk and the image checksum. Pure
 * functions over caller buffers; no ti_* and no globals. */

#include "common.h"

/* The walk visits element k = buf[(k % inner) * stride + k / inner] for k in
 * 0 .. outer*inner-1. World in LAYER order (all of y=0, then y=1, ...):
 * outer = WORLD_SY, inner = WORLD_SX*WORLD_SZ, stride = WORLD_SY. A flat
 * array in memory order: outer = 1, inner = n, stride = 1.
 * Coding: {run 1..255, value} byte pairs; runs continue across layers. */

/* bytes written to out, or 0 if the coding would exceed cap */
unsigned sf_rle_enc(uint8_t *out, unsigned cap, const uint8_t *src,
                    unsigned outer, unsigned inner, unsigned stride);

/* true iff in[0..len) decodes to EXACTLY outer*inner cells (no short or
 * overlong stream, no zero-length run) */
bool sf_rle_dec(const uint8_t *in, unsigned len, uint8_t *dst,
                unsigned outer, unsigned inner, unsigned stride);

/* Fletcher-16 (mod 255) over p[0..n) */
uint16_t sf_fletcher16(const uint8_t *p, unsigned n);

#endif
