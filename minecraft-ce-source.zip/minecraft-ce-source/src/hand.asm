; Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
; push3 HAND: inner loops of the first-person held item (hud.c hud_hand).
; The host build runs the C twins in hud.c; the calc goldens (m4 / s1sky:
; cube, n6hud: 3x item) prove the two byte-identical.
;
; void hand_cube_asm(uint8_t *o, const uint8_t *side);
;   the 48x48 isometric cube at o, column by column (x = 0..47, h = the
;   distance from the nearer edge): rows [11 - h/2, 13 + h/2) are the top
;   face, texel = page[hand_d[75 + 2y - x] + hand_d[2y + x - 22]] (the d3*16
;   half = v, the d3 half = u) from the 256-aligned page at (_tpage_ptr)
;   holding the top tile (render_tpage); then 24 side rows from side column
;   u = hand_d[2 (x mod 24) + 1] (texel rows 2,1,2,1,... pixels tall), OR
;   bank 0x40 (left, SHADE_X) / 0x80 (right, SHADE_Z). Same pixels as
;   hud.c's host hand_col loop.
; void hand_icon_asm(uint8_t *o, const uint8_t *t, int key);
;   the 16x16 tile t scaled 3x at o, texels == key skipped.

assume adl=1

section .text
public _hand_cube_asm
public _hand_icon_asm
extern _tpage_ptr

_hand_cube_asm:
    push ix
    push iy
    ld iy, 0
    add iy, sp              ; iy+6 ret, +9 o, +12 side
    ld hl, (iy + 9)
    ld (.o + 1), hl
    ld hl, (iy + 12)
    ld (.sd + 1), hl
    xor a, a
.col:                       ; a = x
    ld (.xv + 1), a
    ld c, a
    add a, a
    sub a, 97
    ld (.smc_k + 2), a      ; k = 2x - 97: u entry relative to the v entry
    ld a, c
    ld b, 040h              ; left face bank (SHADE_X)
    cp a, 24
    jr c, .lf
    ld b, 080h              ; right face bank (SHADE_Z)
    sub a, 24
.lf:                        ; a = x mod 24
    ld hl, _hand_d + 1
    ld de, 0
    add a, a
    ld e, a
    add hl, de
    ld e, (hl)              ; side u = hand_d[2 (x mod 24) + 1]
.sd:
    ld hl, 0                ; SMC: side tile
    add hl, de
    push hl                 ; side column
    ld a, b
    ld (.bank + 1), a
    ld a, c
    cp a, 24
    jr c, .h
    ld a, 47
    sub a, c
.h:                         ; a = h
    srl a
    ld b, a
    ld a, 11
    sub a, b
    ld b, a                 ; b = y0 = 11 - h/2
    ld hl, _hand_d + 75
    ld de, 0
    add a, a
    ld e, a
    add hl, de
    ld e, c
    or a, a
    sbc hl, de
    push hl                 ; va = hand_d + 75 + 2 y0 - x
    or a, a
    sbc hl, hl
    ld l, b
    push hl
    pop de
    add hl, hl
    add hl, hl
    add hl, de              ; 5 y0
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl
    add hl, hl              ; 320 y0
    ld de, 0
    ld e, c
    add hl, de
.o:
    ld de, 0                ; SMC: o
    add hl, de              ; p = o + x + 320 y0
    ld a, b
    add a, a
    neg
    add a, 24
    ld e, a                 ; n = 24 - 2 y0 = 2 + 2 (h/2) top rows
.bank:
    ld d, 0                 ; SMC: side bank
    pop ix                  ; va
    ld iy, (_tpage_ptr)     ; 256-aligned page; iyl = texel index
    ld bc, 320
.top:
    ld a, (ix + 0)          ; v * 16
.smc_k:
    add a, (ix + 0)         ; + u (displacement patched to k)
    ld iyl, a
    ld a, (iy + 0)
    ld (hl), a
    add hl, bc
    lea ix, ix + 2
    dec e
    jr nz, .top
    pop ix                  ; side column
    ld e, 8
.side:
    ld a, (ix + 0)          ; even texel row: 2 pixels
    or a, d
    ld (hl), a
    add hl, bc
    ld (hl), a
    add hl, bc
    ld a, (ix + 16)         ; odd texel row: 1 pixel
    or a, d
    ld (hl), a
    add hl, bc
    lea ix, ix + 32
    dec e
    jr nz, .side
.xv:
    ld a, 0                 ; SMC: x
    inc a
    cp a, 48
    jp nz, .col
    pop iy
    pop ix
    ret

_hand_icon_asm:
    push ix
    ld ix, 0
    add ix, sp              ; ix+3 ret, +6 o, +9 t, +12 key
    ld hl, (ix + 6)
    ld de, (ix + 9)
    ld c, (ix + 12)
    ld b, 16
.vrow:
    push bc
    ld b, 3                 ; each texel row 3 screen rows
.rep:
    push bc
    push hl
    push de
    ld b, 16
.tx:
    ld a, (de)
    inc de
    cp a, c
    jr z, .skip
    ld (hl), a
    inc hl
    ld (hl), a
    inc hl
    ld (hl), a
    inc hl
    djnz .tx
    jr .next
.skip:
    inc hl
    inc hl
    inc hl
    djnz .tx
.next:
    pop de
    pop hl
    ld bc, 320
    add hl, bc
    pop bc
    djnz .rep
    ex de, hl
    ld bc, 16
    add hl, bc
    ex de, hl
    pop bc
    djnz .vrow
    pop ix
    ret

; (kept in .text: one section, no cross-section symbol)
; floor(n / 3) clamped to 0..15 for n = -1..48 (index n + 1), then the same
; values * 16 (hud.c keeps the identical host copy)
_hand_d:
    db 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7
    db 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13
    db 14, 14, 14, 15, 15, 15, 15
    db 0, 0, 0, 0, 16, 16, 16, 32, 32, 32, 48, 48, 48, 64, 64, 64, 80, 80, 80
    db 96, 96, 96, 112, 112, 112, 128, 128, 128, 144, 144, 144, 160, 160, 160
    db 176, 176, 176, 192, 192, 192, 208, 208, 208, 224, 224, 224, 240, 240
    db 240, 240
