/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef CRAFT_H
#define CRAFT_H

#include "common.h"
#include "items.h"

/*
 * craft.c — the recipe-book crafting table. Pure data + logic, NO ez80/UI
 * dependencies, so the host harness compiles it directly and drives the
 * exact same code the calc UI calls (craft_can / craft_apply).
 *
 * Recipes are SHAPELESS: `in[]` lists the distinct ingredient ids consumed
 * (<= 3) with their counts; `out` x `out_count` is added on craft. The 3x3
 * grid in the inventory bitmap is a PREVIEW of the ingredients, not an input
 * surface. Counts index plr.inv uniformly by block OR item id.
 */

#define CRAFT_MAX_IN 3

/* recipe categories for the console (MATTIS) crafting screen tabs */
enum craft_cat { CAT_BLOCKS = 0, CAT_TOOLS = 1, CAT_ITEMS = 2, CAT_COUNT = 3 };

typedef struct {
    uint8_t id;
    uint8_t count;
} craft_in_t;

typedef struct {
    uint8_t n_in;
    craft_in_t in[CRAFT_MAX_IN];
    uint8_t out;
    uint8_t out_count;
    uint8_t cat;              /* CAT_BLOCKS / CAT_TOOLS / CAT_ITEMS */
    uint8_t needs_table;      /* 1 = only craftable at a placed crafting table
                                 (enforced N2/N4); 0 = hand-craftable */
} recipe_t;

#define RECIPE_COUNT 21

extern const recipe_t recipes[RECIPE_COUNT];

/* fill idx[] (caller supplies >= RECIPE_COUNT room) with the recipe indices
 * belonging to category `cat`, in table order; returns how many. */
int craft_list(uint8_t cat, uint8_t *idx);

/* true if the player's slot inventory holds every ingredient of r */
bool craft_can(const recipe_t *r);

/* consume r's ingredients from the slot inventory and add its output. Caller
 * must have checked craft_can first. */
void craft_apply(const recipe_t *r);

/* ---- N4 furnace data (settled here so the id space + tables are final) ---- */
typedef struct { uint8_t in; uint8_t out; } smelt_t;
typedef struct { uint8_t id; uint8_t items; } fuel_t;  /* items = smelts/unit */

#define SMELT_COUNT 2
#define FUEL_COUNT  2
extern const smelt_t smelts[SMELT_COUNT];
extern const fuel_t  fuels[FUEL_COUNT];

#endif
