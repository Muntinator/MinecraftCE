/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * Minecraft CE — calculator entry point.
 *
 * Build variants:
 *   make            interactive game
 *   make DEMO=1     static parity frame (autotest-m1.json)
 *   make PLAY=1     scripted-input playback parity (autotest-m4.json)
 *   make PERF=1     timed render loop, ticks as bit blocks on row 0
 *   make FPTEST=1   fp_mul/fp_div/span_tex_asm validation vectors
 *   make SKYDEMO=1  the interactive game driven by the scripted Skyblock
 *                   "day one" keypad (src/skydemo.h, autotest-s5demo.json)
 *
 * Controls (game): arrows walk/strafe; y=/window/zoom/trace look; 2nd
 * jump; del break (hold in survival) or attack a targeted mob; mode
 * place; graph cycles the hotbar; +/- render distance; clear pauses.
 */

#ifndef HOST_SHIM     /* push3 S5: host --s5demo brings its own shims */
#include <graphx.h>
#include <keypadc.h>
#include <ti/ui.h>
#endif
#include <string.h>
#include <stdlib.h>

#include "common.h"
#include "world.h"
#include "mesh.h"
#include "palette.h"
#include "textures.h"
#include "render.h"
#include "player.h"
#include "hud.h"
#include "save.h"
#include "mob.h"
#include "drop.h"
#include "compose.h"
#include "lut.h"
#include "craft.h"
#include "furnace.h"
#include "light.h"
#include "demo.h"

static camera_t cam;

static uint8_t day_rgb[256][3];

static void set_brightness(uint8_t level)   /* 0 = midnight, 15 = noon */
{
    unsigned s = 112 + level * 9;           /* 44%..97% + a night-blue cast */
    for (int i = 0; i < 256; i++) {
        unsigned r = (day_rgb[i][0] * s) >> 8;
        unsigned g = (day_rgb[i][1] * s) >> 8;
        unsigned b = (day_rgb[i][2] * s) >> 8;
        if (level < 6)
            b += (6 - level) * 4;           /* moonlight tint */
        if (b > 255) b = 255;
        gfx_palette[i] = gfx_RGBTo1555((uint8_t)r, (uint8_t)g, (uint8_t)b);
    }
    /* HUD-critical colors never darken: white/gray text family, hearts
     * red, black. Keeps hotbar counts, hearts, crosshair and the target
     * outline readable at night. */
    static const uint8_t keep[] = {
        PAL_BLACK, PAL_WHITE, PAL_WHITE | 64, PAL_WHITE | 128,
        PAL_WHITE | 192,
    };
    for (unsigned k = 0; k < sizeof keep; k++) {
        uint8_t i = keep[k];
        gfx_palette[i] = gfx_RGBTo1555(day_rgb[i][0], day_rgb[i][1],
                                       day_rgb[i][2]);
    }
    gfx_palette[pal_red_idx] = gfx_RGBTo1555(day_rgb[pal_red_idx][0],
                                             day_rgb[pal_red_idx][1],
                                             day_rgb[pal_red_idx][2]);
}

static void load_palette(void)
{
    palette_build(day_rgb);
    set_brightness(15);
}

static void wait_clear(void)
{
    do {
        kb_Scan();
    } while (!(kb_Data[6] & kb_Clear));
}

static void boot_world(uint32_t seed)
{
    os_RunIndicOff();
    gfx_Begin();
    load_palette();
    textures_init();
    world_gen(seed);
    mesh_init();
}

#if defined(FP_TEST)

/* Validates fpmath.asm + raster.asm against the host's int64 reference:
 * writes every result as bytes into vram; tools/host/genfptest.py
 * computes the same vector in python and CRC-compares via autotester. */

int fp_mul(int a, int b);
int fp_div(int a, int b);

static uint32_t lcg = 0x12345678u;
static uint32_t rnd(void)
{
    lcg = lcg * 1664525u + 1013904223u;
    return lcg;
}

static const int32_t mul_fixed[][2] = {
    {0, 0}, {1, 1}, {-1, 1}, {1, -1}, {-1, -1},
    {4095, 4095}, {-4096, 4096}, {4096, -4096}, {-4096, -4096},
    {0x7FFFF, 0x7FFF}, {-0x7FFFF, 0x7FFF}, {0x7FFFF, -0x7FFF},
    {-0x7FFFF, -0x7FFF}, {0x3FFFF, -0x1FFFF}, {-262143, 131071},
    {2048, 3},
};

static const int32_t div_fixed[][2] = {
    {4096, 4096}, {-4096, 4096}, {4096, -4096}, {-4096, -4096},
    {1, 1024}, {-1, 1024}, {0x3FFFF, 1024}, {-0x3FFFF, -1024},
};

int main(void)
{
    os_RunIndicOff();
    gfx_Begin();          /* own the LCD so the OS can't repaint over us */

    uint8_t *p = (uint8_t *)0xD40000;

    for (unsigned i = 0; i < sizeof mul_fixed / sizeof mul_fixed[0]; i++) {
        int r = fp_mul((int)mul_fixed[i][0], (int)mul_fixed[i][1]);
        *p++ = (uint8_t)(r & 0xFF);
        *p++ = (uint8_t)((r >> 8) & 0xFF);
        *p++ = (uint8_t)((r >> 16) & 0xFF);
    }
    for (int i = 0; i < 48; i++) {
        int a = (int)((int32_t)(rnd() & 0x7FFFFu) - 0x40000);
        int b = (int)((int32_t)(rnd() & 0x1FFFFu) - 0x10000);
        int r = fp_mul(a, b);
        *p++ = (uint8_t)(r & 0xFF);
        *p++ = (uint8_t)((r >> 8) & 0xFF);
        *p++ = (uint8_t)((r >> 16) & 0xFF);
    }
    for (unsigned i = 0; i < sizeof div_fixed / sizeof div_fixed[0]; i++) {
        int r = fp_div((int)div_fixed[i][0], (int)div_fixed[i][1]);
        *p++ = (uint8_t)(r & 0xFF);
        *p++ = (uint8_t)((r >> 8) & 0xFF);
        *p++ = (uint8_t)((r >> 16) & 0xFF);
    }
    for (int i = 0; i < 40; i++) {
        int a = (int)((int32_t)(rnd() & 0x7FFFFu) - 0x40000);
        int32_t bm = (int32_t)(rnd() & 0xFFFFu) + 1024;
        int b = (rnd() & 1u) ? (int)-bm : (int)bm;
        int r = fp_div(a, b);
        *p++ = (uint8_t)(r & 0xFF);
        *p++ = (uint8_t)((r >> 8) & 0xFF);
        *p++ = (uint8_t)((r >> 16) & 0xFF);
    }

    /* span_tex_asm standalone vectors against an identity page */
    {
        extern uint8_t *tpage_ptr;
        void span_tex_asm(uint8_t *dst, int count, fix u, fix v,
                          fix du, fix dv, int bank);
        static uint8_t raw[512];
        tpage_ptr = (uint8_t *)(((unsigned int)raw + 255) & ~255u);
        for (int i = 0; i < 256; i++)
            tpage_ptr[i] = (uint8_t)i;

        span_tex_asm(p, 16, 0, 0, 256, 0, 0);        p += 16;
        span_tex_asm(p, 16, 0, 0, 0, 256, 0);        p += 16;
        span_tex_asm(p, 20, 0x1280, 0x0340, -256, 512, 0x40); p += 20;
        span_tex_asm(p, 12, -4096, -256, 256, -512, 0x80);    p += 12;
        span_tex_asm(p, 8, 0x7FF00, 0, 30000, 0, 0); p += 8;
    }

    /* xform_asm + outcode5_asm vectors (M18c): 8 pseudo-random camera
     * configs (legal ranges: sy/cy/sp/cp in +/-4096, cx/cyy/cz in
     * 0..32<<12), 24 corners each (lattice coords -8..55 x -2..13, covering
     * the negative coords render_block_rect feeds transform). Each corner
     * emits out.x/y/z (3 bytes LE each) + the outcode5 byte. The LCG stream
     * CONTINUES from the vectors above — genfptest.py mirrors the order. */
    {
        typedef struct { fix x, y, z; } v3t;
        void xform_asm(int wx, int wy, int wz, v3t *out);
        uint8_t outcode5_asm(const v3t *v);
        v3t v;
        for (int c = 0; c < 9; c++) {
            if (c == 0) {
                /* edge config: coefficients exactly +/-4096 (the lut's
                 * extremes; the random configs below can only reach -4096) */
                rcam.sy = 4096;  rcam.cy = -4096;
                rcam.sp = 4096;  rcam.cp = -4096;
                rcam.cx = 0;  rcam.cyy = 131071;  rcam.cz = 48 << 12;
            } else {
                rcam.sy  = (fix)((int32_t)(rnd() & 0x1FFFu) - 4096);
                rcam.cy  = (fix)((int32_t)(rnd() & 0x1FFFu) - 4096);
                rcam.sp  = (fix)((int32_t)(rnd() & 0x1FFFu) - 4096);
                rcam.cp  = (fix)((int32_t)(rnd() & 0x1FFFu) - 4096);
                rcam.cx  = (fix)(rnd() & 0x1FFFFu);
                rcam.cyy = (fix)(rnd() & 0x1FFFFu);
                rcam.cz  = (fix)(rnd() & 0x1FFFFu);
            }
            for (int i = 0; i < 24; i++) {
                int wx = (int)(rnd() & 63u) - 8;
                int wy = (int)(rnd() & 15u) - 2;
                int wz = (int)(rnd() & 63u) - 8;
                xform_asm(wx, wy, wz, &v);
                *p++ = (uint8_t)(v.x & 0xFF);
                *p++ = (uint8_t)((v.x >> 8) & 0xFF);
                *p++ = (uint8_t)((v.x >> 16) & 0xFF);
                *p++ = (uint8_t)(v.y & 0xFF);
                *p++ = (uint8_t)((v.y >> 8) & 0xFF);
                *p++ = (uint8_t)((v.y >> 16) & 0xFF);
                *p++ = (uint8_t)(v.z & 0xFF);
                *p++ = (uint8_t)((v.z >> 8) & 0xFF);
                *p++ = (uint8_t)((v.z >> 16) & 0xFF);
                *p++ = outcode5_asm(&v);
            }
        }
    }

    /* project_asm vectors (Stage P): the fused perspective divide + project.
     * Two rfocal/rcx/rcy configs x a fixed view-space vertex table (+/-x,
     * +/-y, near and far z, z always > NEAR_Z) then a CONTINUED-LCG random
     * vertex stream (z forced > NEAR_Z). Each vertex emits sx,sy as int24 LE
     * triples. genfptest.py mirrors the order + math exactly. */
    {
        typedef struct { fix x, y, z; } v3t;
        void project_asm(const v3t *v, int *sx, int *sy);
        extern int rfocal, rcx, rcy;
        static const int32_t pcfg[][3] = {      /* rfocal, rcx, rcy */
            {256, 160, 120}, {160, 80, 60},
        };
        static const int32_t pvtx[][3] = {      /* view-space x,y,z (12.12) */
            {        0,        0,  2 << 12 },
            {  3 << 12,        0,  5 << 12 },
            { -3 << 12,        0,  5 << 12 },
            {        0,  3 << 12,  5 << 12 },
            {        0, -3 << 12,  5 << 12 },
            {  5 << 12,  5 << 12,  2 << 12 },
            { -5 << 12, -5 << 12, 20 << 12 },
            {  1 << 12, -1 << 12,     1100 },    /* z just above NEAR_Z */
            { -7 << 12,  4 << 12, 30 << 12 },
        };
        v3t v;
        int sx, sy;
        for (unsigned c = 0; c < sizeof pcfg / sizeof pcfg[0]; c++) {
            rfocal = (int)pcfg[c][0];
            rcx = (int)pcfg[c][1];
            rcy = (int)pcfg[c][2];
            for (unsigned i = 0; i < sizeof pvtx / sizeof pvtx[0]; i++) {
                v.x = (fix)pvtx[i][0];
                v.y = (fix)pvtx[i][1];
                v.z = (fix)pvtx[i][2];
                project_asm(&v, &sx, &sy);
                *p++ = (uint8_t)(sx & 0xFF);
                *p++ = (uint8_t)((sx >> 8) & 0xFF);
                *p++ = (uint8_t)((sx >> 16) & 0xFF);
                *p++ = (uint8_t)(sy & 0xFF);
                *p++ = (uint8_t)((sy >> 8) & 0xFF);
                *p++ = (uint8_t)((sy >> 16) & 0xFF);
            }
            for (int i = 0; i < 16; i++) {
                v.x = (fix)((int32_t)(rnd() & 0x3FFFFu) - 0x20000);
                v.y = (fix)((int32_t)(rnd() & 0x3FFFFu) - 0x20000);
                v.z = (fix)((rnd() & 0x1FFFFu) + 1100);
                project_asm(&v, &sx, &sy);
                *p++ = (uint8_t)(sx & 0xFF);
                *p++ = (uint8_t)((sx >> 8) & 0xFF);
                *p++ = (uint8_t)((sx >> 16) & 0xFF);
                *p++ = (uint8_t)(sy & 0xFF);
                *p++ = (uint8_t)((sy >> 8) & 0xFF);
                *p++ = (uint8_t)((sy >> 16) & 0xFF);
            }
        }
    }

    /* sentinel: 8 bytes of PAL_WHITE index */
    for (int k = 0; k < 8; k++)
        *p++ = PAL_WHITE;

    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(DEMO_FRAME)

int main(void)
{
    boot_world(DEMO_SEED);
    cam.x = DEMO_CAM_X; cam.y = DEMO_CAM_Y; cam.z = DEMO_CAM_Z;
    cam.yaw = DEMO_YAW; cam.pitch = DEMO_PITCH;

    render_frame((uint8_t *)0xD40000, &cam);
    render_present((uint8_t *)0xD40000);  /* no-op at GFXMODE=0 (rt==fb),
                                             so the m1 golden is unchanged;
                                             at GFXMODE=1/2 it exercises the
                                             asm expanders for a scaled
                                             byte-identity check vs host */

    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(DEMO_PLAY)

#include "script.h"

int main(void)
{
    boot_world(DEMO_SEED);
    player_init();
    mobs_spawn(DEMO_SEED);
    drops_reset();

    uint8_t *fb = (uint8_t *)0xD40000;
    for (unsigned s = 0; s < SCRIPT_LEN; s++)
        for (int f = 0; f < demo_script[s].frames; f++)
            player_tick(demo_script[s].input);

    player_camera(&cam);
    render_frame(fb, &cam);
    mobs_draw(fb, &cam);
    drops_draw(fb, &cam);
    render_present(fb);
    hud_draw(fb);
    hud_crosshair(fb);

    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(PERF_FRAME)

#include <sys/timers.h>

#if defined(PERF_IDLE) || defined(PERF_HAND)
#define PERF_FRAMES 256    /* idle frames are tiny; amortize the read */
#else
#define PERF_FRAMES 8
#endif

int main(void)
{
#ifdef PERF_WT
    /* push3 S1: make PERF=1 PERFWT=<0|1|2>: that world type, seen from the
     * new-world spawn camera (Skyblock: the first frame a player sees) */
    g_worldtype = PERF_WT;
    boot_world(DEMO_SEED);
    player_init();
    plr.x = 16 * FIX_ONE; plr.z = 16 * FIX_ONE;
    plr.y = INT_TO_FIX(world_height[16 * WORLD_SZ + 16] + 1);
    plr.yaw = SKY_SPAWN_YAW; plr.pitch = SKY_SPAWN_PITCH;
    player_camera(&cam);
#else
    boot_world(DEMO_SEED);
    cam.x = DEMO_CAM_X; cam.y = DEMO_CAM_Y; cam.z = DEMO_CAM_Z;
    cam.yaw = DEMO_YAW; cam.pitch = DEMO_PITCH;
#endif

    uint8_t *fb = (uint8_t *)0xD40000;
#if defined(PERF_HAND)
    /* push3 HAND: make PERF=1 PERFHAND=<id>: 256 x hud_draw with <id> held
     * in survival slot 0 (0 = empty hand; the difference is the hand) */
    render_frame(fb, &cam);
    render_present(fb);
    player_init();
    plr.mode = MODE_SURVIVAL;
    plr.hotbar[0].id = PERF_HAND;
    plr.hotbar[0].count = 1;
    timer_Disable(1);
    timer_Set(1, 0);
    timer_Enable(1, TIMER_32K, TIMER_NOINT, TIMER_UP);
    for (int f = 0; f < PERF_FRAMES; f++)
        hud_draw(fb);
    uint32_t t = timer_GetSafe(1, TIMER_UP);
#elif defined(PERF_COMPOSE)
    /* dirty-frame cost: camera still, one zombie walking in view */
    player_init();
    plr.mode = MODE_SURVIVAL;
    mobs_spawn(DEMO_SEED);
    drops_reset();
    for (int i = 0; i < 30; i++)
        player_tick(0);
    fix fx = SIN(plr.yaw), fz = COS(plr.yaw);
    mobs[1].x = plr.x + fx * 4;
    mobs[1].z = plr.z + fz * 4;
    mobs[1].y = plr.y + 4096;
    mobs[1].vy = 0;
    mobs[1].alive = 1;
#ifdef PERF_IDLE
    mobs[0].alive = 0;                 /* pure idle: nothing in view */
    mobs[1].alive = 0;
    plr.pitch = 8;                     /* look up: no target outline */
#endif
    player_camera(&cam);
    compose_frame(fb, &cam);           /* warmup: full frame */

    timer_Disable(1);
    timer_Set(1, 0);
    timer_Enable(1, TIMER_32K, TIMER_NOINT, TIMER_UP);
    for (int f = 0; f < PERF_FRAMES; f++) {
        mobs_tick();                   /* zombie chases: real dirt */
        compose_frame(fb, &cam);
    }
    uint32_t t = timer_GetSafe(1, TIMER_UP);
#else
    render_frame(fb, &cam);            /* warmup: meshes get built */

    timer_Disable(1);
    timer_Set(1, 0);
    timer_Enable(1, TIMER_32K, TIMER_NOINT, TIMER_UP);
    for (int f = 0; f < PERF_FRAMES; f++) {
        render_frame(fb, &cam);
        render_present(fb);            /* scaled modes pay the upscale */
    }
    uint32_t t = timer_GetSafe(1, TIMER_UP);
#endif

    for (int i = 0; i < 24; i++) {
        uint8_t c = ((t >> (23 - i)) & 1) ? PAL_WHITE : PAL_BLACK;
        for (int k = 0; k < 8; k++)
            fb[i * 8 + k] = c;
    }
    for (int k = 0; k < 8; k++)
        fb[24 * 8 + k] = PAL_WHITE;

    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(UI_TEST)

/* Deterministic open-inventory frame for the N2 autotest. Seeds the shared
 * inv_ui_demo() state and renders the unified inventory+crafting screen once
 * to the draw buffer — byte-identical to the host harness `--uiinv`, which
 * calls the same inv_ui_demo() + hud_inventory_screen(). */
int main(void)
{
    boot_world(DEMO_SEED);
    inv_ui_t ui;
    inv_ui_demo(&ui);
    hud_inventory_screen((uint8_t *)0xD40000, &ui);
    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(FUR_TEST)

/* Deterministic furnace-UI frame for the N4 autotest. Seeds the shared
 * furnace_ui_demo() state (input/fuel/output filled, mid-burn) and renders the
 * furnace screen once — byte-identical to host `--n4fur`. */
int main(void)
{
    boot_world(DEMO_SEED);
    static furnace_t f;
    furnace_ui_t ui;
    furnace_ui_demo(&ui, &f);
    hud_furnace_screen((uint8_t *)0xD40000, &ui);
    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(CHEST_TEST)

/* push3 S2: deterministic chest-UI frame for autotest-s2chest. Seeds the
 * shared chest_ui_demo() (Skyblock kit + a scripted run of the real chest
 * state machine) and renders the chest screen once — byte-identical to host
 * `--s2chest`. */
int main(void)
{
    boot_world(DEMO_SEED);
    static chest_t c;
    chest_ui_t ui;
    chest_ui_demo(&ui, &c);
    hud_chest_screen((uint8_t *)0xD40000, &ui);
    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(N5_TEST)

#include "n5scene.h"

/* Deterministic torch-lit scene for the N5 autotest: superflat world, a stone
 * wall, a torch in front of it. Renders the world (light banks baked in) plus
 * the torch box once — byte-identical to host `--n5lit`. */
int main(void)
{
    boot_world(DEMO_SEED);      /* gfx/palette/textures init (world overridden) */
    n5_build_scene(1);
    camera_t c = { N5_CAM_X, N5_CAM_Y, N5_CAM_Z, N5_YAW, N5_PITCH };
    uint8_t *fb = (uint8_t *)0xD40000;
    render_frame(fb, &c);
    torches_draw(fb, &c);
    render_present(fb);
    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(S3_TEST)

#include "s3scene.h"

/* push3 S3: deterministic lava-lit night scene for autotest-s3lava: a lava
 * and a water source poured on superflat grass in front of a stone wall and
 * settled by the REAL liquid rules (lava/water plus shapes, a cobble where
 * they meet), lava light baked into the faces, stars on — byte-identical to
 * host `--s3liquid`. */
int main(void)
{
    boot_world(DEMO_SEED);      /* gfx/palette/textures init (world overridden) */
    s3_build_scene();
    set_brightness(3);          /* night palette (not in the hashed bytes) */
    camera_t c = { S3_CAM_X, S3_CAM_Y, S3_CAM_Z, S3_YAW, S3_PITCH };
    uint8_t *fb = (uint8_t *)0xD40000;
    render_frame(fb, &c);
    render_present(fb);
    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(S4_TEST)

#include "s4scene.h"

/* push3 S4: deterministic sapling scene for autotest-s4sapling: the Skyblock
 * island with three saplings, the real decay cursor ticked until one grows
 * into a tree, the other two drawn as keyed sprites — byte-identical to host
 * `--s4sapling`. */
int main(void)
{
    boot_world(DEMO_SEED);      /* gfx/palette/textures init (world overridden) */
    s4_build_scene();
    camera_t c = { S4_CAM_X, S4_CAM_Y, S4_CAM_Z, S4_YAW, S4_PITCH };
    uint8_t *fb = (uint8_t *)0xD40000;
    render_frame(fb, &c);
    torches_draw(fb, &c);
    render_present(fb);
    wait_clear();
    gfx_End();
    return 0;
}

#elif defined(N6_TEST)

/* Deterministic survival-HUD frame for the N6 autotest: the demo vista with
 * the polished hearts/hunger/armor overlay (hud_n6_demo state) — byte-identical
 * to host `--n6hud`. */
int main(void)
{
    boot_world(DEMO_SEED);
    player_init();
    hud_n6_demo();
    camera_t c = { DEMO_CAM_X, DEMO_CAM_Y, DEMO_CAM_Z, DEMO_YAW, DEMO_PITCH };
    uint8_t *fb = (uint8_t *)0xD40000;
    render_frame(fb, &c);
    render_present(fb);
    hud_draw(fb);
    hud_crosshair(fb);
    wait_clear();
    gfx_End();
    return 0;
}

#else

#ifndef HOST_SHIM
#include <sys/timers.h>
#endif
#include "ui.h"

#define TICK_32K 1092
#define VBUF ((uint8_t *)gfx_vbuffer)

#ifdef SKY_DEMO
/* push3 S5: kb_Scan / kb_Data come from the day-one script from here on
 * (everything below is the real game, unchanged) */
#include "skydemo.h"
#endif

/* ---- primitives: drawing lives in ui.c (portable, host-rendered) ---- */

static void menu_wait_release(void)
{
    for (;;) {
        kb_Scan();
        if (!kb_Data[6] && !kb_Data[7] && !kb_Data[1] && !kb_Data[2] &&
            !kb_Data[4])
            return;
    }
}

/* Menu loops (UI U3 follow-up): scan keys every pass, but repaint only when
 * something changed. The old loops redrew the whole page (dirt background +
 * MC font, ~0.1 s) before every single key scan, so input lagged and a quick
 * tap that fell between two scans was lost. `dirty` = passes still to draw:
 * 2 after a change, so BOTH display buffers end up holding the page (the
 * smoke suites hash buffer 0 under a menu), with a key scan between the two
 * draws. */
#define MENU_REDRAW 2

/* Returns the selected index, or -1 on a fresh `clear` press (back/exit;
 * `held` starts full so a clear still held from the previous screen can't
 * fire). Callers decide what -1 means: title = Quit, pause = Resume;
 * the death screen ignores it (Respawn must be explicit). */
static int ui_menu(const char *const *items, int n, int y0)
{
    int sel = 0;
    uint8_t held = 0xFF, dirty = MENU_REDRAW;
    for (;;) {
        kb_Scan();
        uint8_t now = 0;
        if (kb_Data[7] & kb_Up) now |= 1;
        if (kb_Data[7] & kb_Down) now |= 2;
        if ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd)) now |= 4;
        if (kb_Data[6] & kb_Clear) now |= 8;
        uint8_t pressed = now & (uint8_t)~held;
        held = now;
        if ((pressed & 1) && sel > 0) { sel--; dirty = MENU_REDRAW; }
        if ((pressed & 2) && sel < n - 1) { sel++; dirty = MENU_REDRAW; }
        if (pressed & 4) return sel;
        if (pressed & 8) return -1;
        if (dirty) {
            if (dirty == MENU_REDRAW) {
                gfx_BlitScreen();
                ui_buttons(VBUF, items, n, y0, sel);
                gfx_SwapDraw();
            } else {
                gfx_BlitScreen();   /* shown page -> other buffer */
            }
            dirty--;
        }
    }
}

/* ---- boot/loading: white + red bar ---- */

static void load_present(const char *stage, int pct)
{
    for (int pass = 0; pass < 2; pass++) {
        ui_load_screen(VBUF, stage, pct);
        gfx_SwapDraw();
    }
}

/* ---- pages ---- */

/* Key/action reference page (ui_controls_page); any of 2nd/enter/clear
 * returns. */
static void controls_page(void)
{
    menu_wait_release();
    uint8_t held = 0xFF, dirty = MENU_REDRAW;
    for (;;) {
        kb_Scan();
        uint8_t now = ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd) ||
                       (kb_Data[6] & kb_Clear)) ? 1 : 0;
        uint8_t pressed = now & (uint8_t)~held;
        held = now;
        if (pressed)
            break;
        if (dirty) {
            if (dirty == MENU_REDRAW) {
                gfx_BlitScreen();
                ui_controls_page(VBUF);
                gfx_SwapDraw();
            } else {
                gfx_BlitScreen();   /* shown page -> other buffer */
            }
            dirty--;
        }
    }
    menu_wait_release();
}

static const uint8_t set_full[] = {
    OPT_RENDER, OPT_DAYNIGHT, OPT_MOBS, OPT_GAMEMODE, OPT_TEXTURES,
    OPT_GRAPHICS, OPT_VIEWPORT, OPT_AUTOJUMP, OPT_CONTROLS, OPT_DONE };
static const uint8_t set_title[] = {
    OPT_RENDER, OPT_TEXTURES, OPT_GRAPHICS, OPT_VIEWPORT, OPT_AUTOJUMP,
    OPT_CONTROLS, OPT_DONE };

static void settings_menu(bool in_game)
{
    const uint8_t *items = in_game ? set_full : set_title;
    int n = in_game ? (int)sizeof set_full : (int)sizeof set_title;
    int sel = 0;
    uint8_t held = 0xFF, dirty = MENU_REDRAW;
    set_brightness(15);          /* UI is never night-darkened */
    menu_wait_release();
    for (;;) {
        if (dirty) {
            if (dirty == MENU_REDRAW) {
                gfx_BlitScreen();
                ui_settings_page(VBUF, items, n, sel);
                gfx_SwapDraw();
            } else {
                gfx_BlitScreen();   /* shown page -> other buffer */
            }
            dirty--;
        }

        kb_Scan();
        uint8_t now = 0;
        if (kb_Data[7] & kb_Up) now |= 1;
        if (kb_Data[7] & kb_Down) now |= 2;
        if (kb_Data[7] & kb_Left) now |= 8;
        if (kb_Data[7] & kb_Right) now |= 16;
        if ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd)) now |= 4;
        if (kb_Data[6] & kb_Clear) now |= 32;
        uint8_t pressed = now & (uint8_t)~held;
        held = now;
        if (pressed)
            dirty = MENU_REDRAW;

        if ((pressed & 1) && sel > 0) sel--;
        if ((pressed & 2) && sel < n - 1) sel++;
        int dir = (pressed & 16) ? 1 : (pressed & 8) ? -1 : 0;
        int opt = items[sel];
        if (dir) {
            if (opt == OPT_RENDER) {
                int r = view_radius + dir * 2;
                if (r < 6) r = 6;
                if (r > 24) r = 24;
                view_radius = (uint8_t)r;
            } else if (opt == OPT_DAYNIGHT) {
                g_daynight = (uint8_t)((g_daynight + 3 + dir) % 3);
            } else if (opt == OPT_MOBS) g_mobs_on ^= 1;
            else if (opt == OPT_GAMEMODE) { plr.mode ^= 1; plr.health = 10; }
            else if (opt == OPT_TEXTURES) g_textures ^= 1;
            else if (opt == OPT_GRAPHICS)
                g_gfxmode = (uint8_t)((g_gfxmode + 3 + dir) % 3);
            else if (opt == OPT_VIEWPORT)
                g_viewport = (uint8_t)((g_viewport + 3 + dir) % 3);
            else if (opt == OPT_AUTOJUMP) g_autojump ^= 1;
        }
        if (pressed & 4) {
            if (opt == OPT_CONTROLS) { controls_page(); held = 0xFF; }
            else if (opt == OPT_DONE) break;
        }
        if (pressed & 32) break;
    }
    prefs_save();
    menu_wait_release();
}

/* Numpad 1..9 -> slot index 0..8. One table + edge-triggered reader shared
 * by the inventory screen and the in-game hotbar select (C-4). Groups/masks
 * verified against $CEDEV/include/keypadc.h. `held` persists the caller's
 * per-digit held state across calls; returns 0..8 on a fresh press else -1. */
static const struct { uint8_t grp, msk; } digit_keys[9] = {
    {3, kb_1}, {4, kb_2}, {5, kb_3}, {3, kb_4}, {4, kb_5},
    {5, kb_6}, {3, kb_7}, {4, kb_8}, {5, kb_9} };

static int read_digit(uint16_t *held)
{
    uint16_t dnow = 0;
    for (int d = 0; d < 9; d++)
        if (kb_Data[digit_keys[d].grp] & digit_keys[d].msk) dnow |= (1u << d);
    int digit = -1;
    for (int d = 0; d < 9; d++)
        if ((dnow & (1u << d)) && !(*held & (1u << d))) { digit = d; break; }
    *held = dnow;
    return digit;
}

/* N2 unified MATTIS inventory + crafting screen. All layout/draw lives in
 * hud.c (hud_inventory_screen) and the interaction is a portable state
 * machine (inv_ui_input) the host harness drives too; this shell loop only
 * translates key edges into events and repaints on change (M26f dirty flag).
 * Survival: full crafting + slot pickup/place/swap + armor. Creative: a
 * simple block palette picker. Crafting here is HAND crafting (has_table 0);
 * N4 opens the same screen with has_table 1 at a placed crafting table. */
static void inventory_screen(uint8_t has_table)
{
    inv_ui_t ui;
    inv_ui_reset(&ui);
    ui.has_table = has_table;
    uint8_t held = 0xFF;
    uint16_t dheld = 0xFFFF;         /* digits held on entry can't fire */
    uint8_t dirty = 1;
    set_brightness(15);
    menu_wait_release();
    for (;;) {
        if (dirty) {
            hud_inventory_screen(VBUF, &ui);   /* full-screen: no blit */
            gfx_SwapDraw();
            dirty = 0;
        }
        kb_Scan();
        uint8_t now = 0;
        if (kb_Data[7] & kb_Left)  now |= 1;
        if (kb_Data[7] & kb_Right) now |= 2;
        if (kb_Data[7] & kb_Up)    now |= 4;
        if (kb_Data[7] & kb_Down)  now |= 8;
        if ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd)) now |= 16;
        if (kb_Data[1] & kb_Del)   now |= 32;
        if ((kb_Data[2] & kb_Alpha) || (kb_Data[6] & kb_Clear) ||
            (kb_Data[5] & kb_Vars)) now |= 64;
        uint8_t pressed = now & (uint8_t)~held;
        held = now;
        int digit = read_digit(&dheld);
        if (pressed || digit >= 0)
            dirty = 1;

        uint8_t ev = 0;
        if (pressed & 1)  ev |= EV_LEFT;
        if (pressed & 2)  ev |= EV_RIGHT;
        if (pressed & 4)  ev |= EV_UP;
        if (pressed & 8)  ev |= EV_DOWN;
        if (pressed & 16) ev |= EV_ENTER;
        if (pressed & 32) ev |= EV_DEL;
        if (pressed & 64) ev |= EV_CLOSE;
        if (inv_ui_input(&ui, ev, digit))
            break;
    }
    if (ui.last_craft) {
        plr.name_ticks = 75;
        plr.name_block = ui.last_craft;
    }
    menu_wait_release();
}

/* N4 furnace UI / push3 S2 chest UI (one container screen, f or c set).
 * Same event/dirty loop as inventory_screen (repaint only on change), but a
 * furnace keeps SMELTING in the background: each real 32K tick that elapses
 * advances furnaces_tick so the flame/arrow gauges move live while the
 * screen is open (the same furnaces_tick the game loop calls, so opening the
 * UI changes nothing about the smelt rate). A chest screen does not tick
 * (like the inventory screen), so it repaints only on a key. read_digit +
 * cont_ui_input drive the portable state machine the host --n4 / --s2chest
 * tests also exercise. */
static void container_screen(furnace_t *f, chest_t *c)
{
    if (!f && !c)
        return;
    cont_ui_t ui;
    cont_ui_reset(&ui, f, c);
    uint8_t held = 0xFF;
    uint16_t dheld = 0xFFFF;
    uint8_t dirty = 1;
    set_brightness(15);
    menu_wait_release();
    uint32_t last_t = timer_GetSafe(1, TIMER_UP);
    for (;;) {
        uint32_t now = timer_GetSafe(1, TIMER_UP);
        int steps = (int)((now - last_t) / TICK_32K);
        if (steps > 0 && f) {
            if (steps > 8) steps = 8;
            last_t += (uint32_t)steps * TICK_32K;
            while (steps--)
                furnaces_tick();
            dirty = 1;                    /* gauges advanced */
        }
        if (dirty) {
            hud_cont_screen(VBUF, &ui);
            gfx_SwapDraw();
            dirty = 0;
        }
        kb_Scan();
        uint8_t now_k = 0;
        if (kb_Data[7] & kb_Left)  now_k |= 1;
        if (kb_Data[7] & kb_Right) now_k |= 2;
        if (kb_Data[7] & kb_Up)    now_k |= 4;
        if (kb_Data[7] & kb_Down)  now_k |= 8;
        if ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd)) now_k |= 16;
        if (kb_Data[1] & kb_Del)   now_k |= 32;
        if ((kb_Data[2] & kb_Alpha) || (kb_Data[6] & kb_Clear) ||
            (kb_Data[5] & kb_Vars)) now_k |= 64;
        uint8_t pressed = now_k & (uint8_t)~held;
        held = now_k;
        int digit = read_digit(&dheld);

        uint8_t ev = 0;
        if (pressed & 1)  ev |= EV_LEFT;
        if (pressed & 2)  ev |= EV_RIGHT;
        if (pressed & 4)  ev |= EV_UP;
        if (pressed & 8)  ev |= EV_DOWN;
        if (pressed & 16) ev |= EV_ENTER;
        if (pressed & 32) ev |= EV_DEL;
        if (pressed & 64) ev |= EV_CLOSE;
        if (ev || digit >= 0) {
            if (cont_ui_input(&ui, ev, digit))
                break;
            dirty = 1;
        }
    }
    menu_wait_release();
}

/* ---- input: arrows walk, top-row function keys look ----
 * Keys are ALSO polled during rendering (render_poll hook): at 1-4 fps
 * a tap shorter than a frame would otherwise fall between scans —
 * "jump while walking" was unplayable without this. */

static unsigned int in_latch;
static uint8_t shell_latch;
static uint8_t digit_latch;      /* 0 = none, else selected hotbar slot + 1 */
static uint8_t ate_latch;        /* N6: 2nd consumed by an eat -> suppress jump
                                    until the key is released */

static unsigned int read_input(void)
{
    unsigned int in = 0;
    if (kb_Data[7] & kb_Up)     in |= IN_FWD;
    if (kb_Data[7] & kb_Down)   in |= IN_BACK;
    if (kb_Data[7] & kb_Left)   in |= IN_LEFT;
    if (kb_Data[7] & kb_Right)  in |= IN_RIGHT;
    if (kb_Data[1] & kb_Yequ)   in |= IN_LOOK_U;
    if (kb_Data[1] & kb_Window) in |= IN_LOOK_L;
    if (kb_Data[1] & kb_Zoom)   in |= IN_LOOK_D;
    if (kb_Data[1] & kb_Trace)  in |= IN_LOOK_R;
    if (kb_Data[1] & kb_2nd)    in |= IN_JUMP;
    if (kb_Data[1] & kb_Del)    in |= IN_BREAK;
    if (kb_Data[1] & kb_Mode)   in |= IN_PLACE;
    if (kb_Data[1] & kb_Graph)  in |= IN_HOTNEXT;
    return in;
}

static void poll_input(void)
{
    kb_Scan();
    in_latch |= read_input();
    if (kb_Data[6] & kb_Clear)    shell_latch |= 1;
    if (kb_Data[4] & kb_Stat)     shell_latch |= 2;
    if (kb_Data[2] & kb_Alpha)    shell_latch |= 4;
    if (kb_Data[3] & kb_GraphVar) shell_latch |= 8;  /* X,T,0,n: group 3 */
    if (kb_Data[5] & kb_Vars)     shell_latch |= 16; /* vars: group 5, crafting */
    if (kb_Data[1] & kb_2nd)      shell_latch |= 32; /* 2nd: interact (N4) */
    /* numpad 1..9 selects a hotbar slot; edge-latch through the poll hook so
     * a tap between shell scans isn't lost at low fps (C-4) */
    {
        static uint16_t poll_dheld = 0xFFFF;
        int d = read_digit(&poll_dheld);
        if (d >= 0)
            digit_latch = (uint8_t)(d + 1);
    }
}

/* ---- combined create-world screen ---- */

static bool create_screen(uint32_t *out_seed, uint8_t *out_type,
                          uint8_t *out_mode)
{
    int sel = 0;                 /* 0 type, 1 mode, 2 create */
    uint8_t wtype = 0, wmode = 0;
    uint8_t held = 0xFF, dirty = MENU_REDRAW;
    menu_wait_release();
    for (;;) {
        if (dirty) {
            if (dirty == MENU_REDRAW) {
                ui_create_page(VBUF, sel, wtype, wmode);
                gfx_SwapDraw();
            } else {
                gfx_BlitScreen();   /* shown page -> other buffer */
            }
            dirty--;
        }

        kb_Scan();
        uint8_t now = 0;
        if (kb_Data[7] & kb_Up) now |= 1;
        if (kb_Data[7] & kb_Down) now |= 2;
        if (kb_Data[7] & kb_Left) now |= 4;
        if (kb_Data[7] & kb_Right) now |= 8;
        if ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd)) now |= 16;
        if (kb_Data[6] & kb_Clear) now |= 32;
        uint8_t pressed = now & (uint8_t)~held;
        held = now;
        if (pressed)
            dirty = MENU_REDRAW;

        if ((pressed & 1) && sel > 0) sel--;
        if ((pressed & 2) && sel < 2) sel++;
        if (pressed & (4 | 8)) {
            /* push3 S1: Normal -> Superflat -> Skyblock (right; left back) */
            if (sel == 0)
                wtype = (uint8_t)((wtype + ((pressed & 8) ? 1 : 2)) % 3);
            if (sel == 1) wmode ^= 1;
        }
        if (pressed & 16) {
            if (sel == 2) {
                /* seed: silently random from the free-running timer */
                *out_seed = timer_GetSafe(1, TIMER_UP) * 2654435761u
                            % 1000000000u;
#ifdef SKY_DEMO
                *out_seed = DEMO_SEED;   /* deterministic mob RNG */
#endif
                *out_type = wtype;
                *out_mode = wmode;
                menu_wait_release();
                return true;
            }
            sel++;
        }
        if (pressed & 32) {
            menu_wait_release();
            return false;
        }
    }
}

static void gen_with_loading(uint32_t seed)
{
    bool sky = g_worldtype == 2;
    load_present(sky ? "Placing island" : "Building terrain", 10);
    world_gen(seed);
    load_present(sky ? "Growing tree" : "Growing trees", 40);
    mesh_init();
    for (int ci = 0; ci < NCHUNKS; ci++)
        mesh_update_chunk(ci);
    load_present("Meshing chunks", 90);
}

static void draw_title(const camera_t *tc)
{
    uint8_t *fb = VBUF;
    uint8_t saved = view_radius;
    uint8_t savedvp = g_viewport;
    view_radius = 24;
    g_viewport = 0;
    render_frame(fb, tc);
    render_present(fb);
    view_radius = saved;
    g_viewport = savedvp;
    ui_logo(fb, 10);
    ui_title_text(fb);
}

/* world-slot select page: its own dirt screen (like CREATE NEW WORLD).
 * Each slot shows its mode or "Empty"; a trailing "Back" button and clear
 * both back out. Returns the chosen index 0..SAVE_SLOTS-1, or -1 on back. */
static int pick_slot(void)
{
    static char lbl[SAVE_SLOTS][16];
    const char *items[SAVE_SLOTS + 1];
    for (int s = 0; s < SAVE_SLOTS; s++) {
        char *L = lbl[s];
        L[0] = (char)('1' + s); L[1] = ' '; L[2] = ' ';
        uint8_t mode;
        uint8_t k = slot_info(s + 1, NULL, &mode);   /* 1 + worldtype */
        const char *w = !k ? "Empty" : k == 3 ? "Skyblock"
                      : mode == MODE_SURVIVAL ? "Survival" : "Creative";
        int n = 3;
        for (const char *p = w; *p; p++) L[n++] = *p;
        L[n] = 0;
        items[s] = L;
    }
    items[SAVE_SLOTS] = "Back";
    int n = SAVE_SLOTS + 1;

    int sel = 0;
    uint8_t held = 0xFF, dirty = MENU_REDRAW;
    menu_wait_release();
    for (;;) {
        if (dirty) {
            if (dirty == MENU_REDRAW) {
                ui_select_page(VBUF, items, n, sel);
                gfx_SwapDraw();
            } else {
                gfx_BlitScreen();   /* shown page -> other buffer */
            }
            dirty--;
        }

        kb_Scan();
        uint8_t now = 0;
        if (kb_Data[7] & kb_Up) now |= 1;
        if (kb_Data[7] & kb_Down) now |= 2;
        if ((kb_Data[6] & kb_Enter) || (kb_Data[1] & kb_2nd)) now |= 4;
        if (kb_Data[6] & kb_Clear) now |= 8;
        uint8_t pressed = now & (uint8_t)~held;
        held = now;
        if (pressed)
            dirty = MENU_REDRAW;
        if ((pressed & 1) && sel > 0) sel--;
        if ((pressed & 2) && sel < n - 1) sel++;
        if (pressed & 4) {
            menu_wait_release();
            return sel == SAVE_SLOTS ? -1 : sel;
        }
        if (pressed & 8) {
            menu_wait_release();
            return -1;
        }
    }
}

/* One game session: assumes the world is already generated + meshed and the
 * player is set up. Resets per-session state, runs the shell/render loop, and
 * returns to the caller (the title loop) when the player picks "Save and Quit"
 * from the pause menu — saving world + prefs first. Death respawns in-place;
 * only Save and Quit ends the session. */
static void game_session(void)
{
    mobs_spawn(world_seed);
    mobs_boot_pigs();
    drops_reset();
#ifdef SKY_DEMO
    (void)poll_input;           /* S5: one scripted scan per frame, no poll */
#else
    render_poll = poll_input;
#endif
    in_latch = 0;
    shell_latch = 0;
    digit_latch = 0;
    ate_latch = 0;
    g_died = 0;
    compose_invalidate();

    uint32_t last_t = timer_GetSafe(1, TIMER_UP);
    uint32_t last_frame_t = last_t;
    uint8_t cur_bright = 15;
    uint8_t cur_tint = 0;
    uint8_t shell_held = 0xFF;
    set_brightness(15);
    menu_wait_release();

    for (;;) {
#ifdef SKY_DEMO
        if (sk_end())
            return;             /* S5: script over */
#endif
        kb_Scan();

        uint8_t snow = shell_latch;
        shell_latch = 0;
        if (kb_Data[6] & kb_Clear) snow |= 1;
        if (kb_Data[4] & kb_Stat) snow |= 2;
        if (kb_Data[2] & kb_Alpha) snow |= 4;
        if (kb_Data[3] & kb_GraphVar) snow |= 8;   /* X,T,0,n: group 3 */
        if (kb_Data[5] & kb_Vars) snow |= 16;      /* vars: group 5, crafting */
        if (kb_Data[1] & kb_2nd) snow |= 32;       /* 2nd: interact (N4) */
        uint8_t spressed = snow & (uint8_t)~shell_held;
        shell_held = snow;

        if (spressed & 1) {
            static const char *const pm[] = { "Resume", "Save and Quit" };
            set_brightness(15);
            cur_tint = 1;
            gfx_BlitScreen();
            ui_banner(VBUF, 56, "Paused", 2);
            gfx_SwapDraw();
            int c;
            while ((c = ui_menu(pm, 2, 96)) == 1) {  /* Save and Quit */
                if (save_world()) {
                    prefs_save();
                    render_poll = NULL;
                    return;            /* -> back to the title */
                }
                /* SV: nothing was lost (the previous save is intact); say
                 * so and keep the pause menu up: retry or resume */
                gfx_BlitScreen();
                ui_banner(VBUF, 80, "Save failed", 1);
                gfx_SwapDraw();
                menu_wait_release();
            }
            menu_wait_release();
            compose_invalidate();
            in_latch = 0;
            shell_latch = 0;
            last_t = timer_GetSafe(1, TIMER_UP);
            continue;
        }
        if (spressed & 2) {
            settings_menu(true);
            cur_tint = 1;        /* force brightness re-apply */
            compose_invalidate();
            in_latch = 0;
            shell_latch = 0;
            last_t = timer_GetSafe(1, TIMER_UP);
            continue;
        }
        /* alpha OR vars open the unified inventory+crafting screen (N2 folded
         * the separate console crafting screen into it) */
        if (spressed & (4 | 16)) {
            inventory_screen(0);       /* alpha/vars: hand crafting (no table) */
            cur_tint = 1;
            compose_invalidate();
            in_latch = 0;
            shell_latch = 0;
            last_t = timer_GetSafe(1, TIMER_UP);
            continue;
        }
        /* 2nd interacts with the pointed-at crafting table / furnace / chest (decision
         * #7). Only a fresh 2nd press WHILE looking at one opens its UI; every
         * other 2nd (and the same press when not aimed at an interactable) is
         * still a jump via in_latch/read_input, so movement is unaffected. */
        if ((spressed & 32) && plr.hit_x >= 0) {
            uint8_t tb = world_get(plr.hit_x, plr.hit_y, plr.hit_z);
            if (tb == B_CRAFTING_TABLE || tb == B_FURNACE ||
                tb == B_FURNACE_LIT || tb == B_CHEST) {
                if (tb == B_CRAFTING_TABLE) {
                    inventory_screen(1);           /* full recipes unlocked */
                } else if (tb == B_CHEST) {
                    /* chest_create returns the live entity, or heals a
                     * lost one (an S1 Skyblock save has the block only) */
                    container_screen(0, chest_create(plr.hit_x, plr.hit_y,
                                                     plr.hit_z));
                } else {
                    container_screen(furnace_create(plr.hit_x, plr.hit_y,
                                                    plr.hit_z), 0);
                }
                cur_tint = 1;
                compose_invalidate();
                in_latch = 0;
                shell_latch = 0;
                last_t = timer_GetSafe(1, TIMER_UP);
                continue;
            }
        }
        /* N6: 2nd EATS the held porkchop when NOT aimed at an interactable
         * (the table/furnace branch above already consumed the press via
         * `continue`, so interaction precedence is preserved). Eating consumes
         * the press and suppresses the jump until 2nd is released. When the food
         * bar is full player_eat_held() refuses, so 2nd still jumps. */
        if (!(kb_Data[1] & kb_2nd))
            ate_latch = 0;
        if ((spressed & 32) && plr.mode == MODE_SURVIVAL && player_eat_held())
            ate_latch = 1;

        if (spressed & 8)
            hud_debug ^= 1;

        if ((kb_Data[6] & kb_Add) && view_radius < 24) {
            view_radius++;
            compose_invalidate();
        }
        if ((kb_Data[6] & kb_Sub) && view_radius > 6) {
            view_radius--;
            compose_invalidate();
        }

        /* numpad 1..9: select a hotbar slot (both modes). The slot-marker
         * repaint is handled by the pv_sel compositor logic below. */
        if (digit_latch) {
            plr.hotbar_sel = (uint8_t)(digit_latch - 1);
            digit_latch = 0;
            uint8_t id = hotbar_id(plr.hotbar_sel);
            if (id) { plr.name_ticks = 75; plr.name_block = id; }
        }

        /* death overlay */
        if (g_died) {
            /* red-tint palette while the screen is up */
            for (int i = 0; i < 256; i++) {
                unsigned rr = day_rgb[i][0] / 2 + 96;
                unsigned gg = day_rgb[i][1] / 3;
                unsigned bb = day_rgb[i][2] / 3;
                gfx_palette[i] = gfx_RGBTo1555((uint8_t)(rr > 255 ? 255 : rr),
                                               (uint8_t)gg, (uint8_t)bb);
            }
            gfx_BlitScreen();
            ui_banner(VBUF, 60, "You died!", 3);
            gfx_SwapDraw();
            static const char *const dm[] = { "Respawn" };
            while (ui_menu(dm, 1, 120) < 0)
                ;                    /* clear doesn't skip the death screen */
            player_respawn();
            set_brightness(cur_bright);
            menu_wait_release();
            compose_invalidate();
            in_latch = 0;
            shell_latch = 0;
            in_latch = 0;
            shell_latch = 0;
            last_t = timer_GetSafe(1, TIMER_UP);
            continue;
        }

        uint32_t now = timer_GetSafe(1, TIMER_UP);
        int steps = (int)((now - last_t) / TICK_32K);
#ifdef SKY_DEMO
        steps = SK_TPF;         /* S5: fixed ticks per frame */
        sk_ticks += SK_TPF;
#endif
        if (steps > 0) {
            if (steps > 4) {
                steps = 4;
                last_t = now;
            } else {
                last_t += (uint32_t)steps * TICK_32K;
            }
            unsigned int in = read_input() | in_latch;
            in_latch = 0;
            if (ate_latch)               /* N6: an eat-press must not also jump */
                in &= ~IN_JUMP;
            while (steps--)
                player_tick(in);     /* mobs_tick advances g_daytime */
            uint8_t phase = (uint8_t)((g_daytime >> 9) & 31);
            uint8_t b = phase < 16 ? phase : (uint8_t)(31 - phase);
            if (g_daynight == 0) b = 15;
            {
                uint8_t ns = (b < 4);   /* deep night: stars over the sky */
                if (ns != g_night_sky) {
                    g_night_sky = ns;
                    compose_invalidate();   /* repaint the whole sky once */
                }
            }
            if (tnt_flash) {
                tnt_flash--;
                for (int i = 0; i < 256; i++)
                    gfx_palette[i] = 0xFFFF;
                cur_tint = 2;
            } else if (hurt_flash) {
                hurt_flash--;
                for (int i = 0; i < 256; i++) {
                    unsigned rr = day_rgb[i][0] / 2 + 110;
                    gfx_palette[i] =
                        gfx_RGBTo1555((uint8_t)(rr > 255 ? 255 : rr),
                                      (uint8_t)(day_rgb[i][1] / 2),
                                      (uint8_t)(day_rgb[i][2] / 2));
                }
                cur_tint = 1;
            } else if (cur_tint || b != cur_bright) {
                cur_tint = 0;
                cur_bright = b;
                set_brightness(b);
            }
        }

        player_camera(&cam);
        uint8_t *fb = VBUF;
        /* the compositor patches the previous frame: fetch it */
        gfx_BlitScreen();
        /* overlays the HUD draws post-present leave stale pixels when
         * they move or vanish; hand their rects to the compositor */
        uint8_t border_clear = hud_restore_rects();
        compose_frame(fb, &cam);
        if (border_clear) {
            /* redraw the letterbox: cheapest correct restore */
            render_present(fb);
        }
        hud_draw(fb);
        hud_crosshair(fb);
        gfx_SwapDraw();

        uint32_t ft = timer_GetSafe(1, TIMER_UP);
        uint32_t dt = ft - last_frame_t;
        last_frame_t = ft;
        if (dt)
            hud_fps10 = (uint16_t)(327680u / dt);
    }
}

/* Regenerate the throwaway title-backdrop world (a played session clobbers
 * this state) and draw the title screen over it. Reuses the loading bar. */
static void title_backdrop(const camera_t *tc)
{
    set_brightness(15);          /* title/menus are never night-darkened */
    g_worldtype = 0;
    world_gen(0x00C0FFEEu);
    load_present("Loading", 55);
    mesh_init();
    mesh_update();
    load_present("Loading", 85);
    draw_title(tc);
    gfx_SwapDraw();
}

int main(void)
{
    os_RunIndicOff();
    gfx_Begin();
    gfx_SetDrawBuffer();
    load_palette();
    textures_init();

    timer_Disable(1);
    timer_Set(1, 0);
    timer_Enable(1, TIMER_32K, TIMER_NOINT, TIMER_UP);

    player_init();
    g_gfxmode = 1;
    prefs_load();                 /* device settings, if saved */
#ifdef SKY_DEMO
    /* push3 S5: the script's moves assume the default gameplay settings;
     * the device's look settings (mode, distance, viewport) are kept */
    g_autojump = 0;
    g_daynight = 1;
#endif

    load_present("Loading", 15);

    camera_t tc;
    tc.x = DEMO_CAM_X; tc.y = DEMO_CAM_Y + 4096; tc.z = DEMO_CAM_Z;
    tc.yaw = DEMO_YAW; tc.pitch = -4;

    /* ---- title / world-select outer loop ---- */
    for (;;) {
        title_backdrop(&tc);

        static const char *const with_save[] =
            { "Continue", "New World", "Settings", "Quit" };
        static const char *const no_save[] =
            { "New World", "Settings", "Quit" };
        for (;;) {
            bool have_save = slot_info(1, NULL, NULL) ||
                             slot_info(2, NULL, NULL) ||
                             slot_info(3, NULL, NULL);
#ifdef SKY_DEMO
            have_save = false;   /* S5: the script expects this title */
#endif
            int c;
            if (have_save) {
                c = ui_menu(with_save, 4, 84);
            } else {
                c = ui_menu(no_save, 3, 92);
                if (c >= 0)          /* don't turn clear (-1) into Continue */
                    c++;
            }
            if (c < 0)               /* clear on the title = Quit */
                c = 3;
            if (c == 3) {
                gfx_End();
                return 0;            /* the only process exit */
            }
            if (c == 2) {
                settings_menu(false);   /* title settings: no per-world opts */
                draw_title(&tc);
                gfx_SwapDraw();
                continue;
            }
            if (c == 0) {
                int s = pick_slot();             /* choose a world to load */
                draw_title(&tc);
                gfx_SwapDraw();
                if (s < 0 || !slot_info(s + 1, NULL, NULL))
                    continue;                    /* back, or an empty slot */
                g_save_slot = (uint8_t)(s + 1);
                if (!load_world()) {
                    /* SV: say it instead of silently returning; a failed
                     * decode may have touched world[], so rebuild the
                     * title backdrop afterwards */
                    gfx_BlitScreen();
                    ui_banner(VBUF, 116, "Could not load world", 1);
                    gfx_SwapDraw();
                    uint32_t t0 = timer_GetSafe(1, TIMER_UP);
                    while (timer_GetSafe(1, TIMER_UP) - t0 < 65536u)
                        ;              /* ~2 s on the 32 kHz timer 1 */
                    title_backdrop(&tc);
                    continue;
                }
                load_present("Loading world", 30);
                mesh_init();
                for (int ci = 0; ci < NCHUNKS; ci++)
                    mesh_update_chunk(ci);
                load_present("Loading world", 95);
            } else {
                /* New World: auto-use the first empty slot (no extra prompt,
                 * so the create flow is unchanged); only if all three are
                 * full do we ask which to overwrite */
                int slot = 0;
                for (int s = 1; s <= SAVE_SLOTS; s++)
                    if (!slot_info(s, NULL, NULL)) { slot = s; break; }
#ifdef SKY_DEMO
                slot = 1;        /* S5: never prompts (the demo never saves) */
#endif
                if (!slot) {
                    int s = pick_slot();
                    draw_title(&tc);
                    gfx_SwapDraw();
                    if (s < 0)
                        continue;
                    slot = s + 1;
                }
                g_save_slot = (uint8_t)slot;
                uint32_t seed;
                uint8_t wtype, wmode;
                if (!create_screen(&seed, &wtype, &wmode)) {
                    draw_title(&tc);
                    gfx_SwapDraw();
                    continue;
                }
                g_worldtype = wtype;
                gen_with_loading(seed);
                player_init();
                plr.mode = wmode;
                plr.x = 16 * FIX_ONE; plr.z = 16 * FIX_ONE;
                plr.y = INT_TO_FIX(world_height[16 * WORLD_SZ + 16] + 1);
                if (wtype == 2) {
                    /* push3 S1: Skyblock turns mobs on (the mob platform
                     * is part of the mode; the create page says so) and
                     * spawns facing the island + tree, not the void */
                    g_mobs_on = 1;
                    plr.yaw = SKY_SPAWN_YAW;
                    plr.pitch = SKY_SPAWN_PITCH;
                }
            }
            break;                   /* a world is ready: run it */
        }

        game_session();              /* returns on Save and Quit -> title */
#ifdef SKY_DEMO
        /* push3 S5: script over: the shown frame into buffer 0 (hashed),
         * then wait for a real clear */
        if (VBUF == gfx_vram)
            gfx_BlitScreen();
        wait_clear();
        gfx_End();
        return 0;
#endif
    }
}

#endif
