/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef ITEMS_H
#define ITEMS_H

#include "common.h"
#include "world.h"       /* B_* / B_COUNT — blocks share the id space */

/*
 * Item ids live ABOVE the block range in one shared 8-bit id space. Blocks
 * stay < 32 so mesh/quad_t.block bit 7 can flag cave faces (draw_quad masks
 * 0x7F); items are 32.. and are NEVER placeable world blocks — world/mesh/
 * render never see an id >= ITEM_BASE. plr.inv is indexed by block OR item
 * id uniformly.
 */
#define ITEM_BASE 32           /* blocks are < 32 (bit7/cave rule) */

enum item_id {
    I_STICK = ITEM_BASE,       /* 32 */
    I_GUNPOWDER,               /* 33 */
    I_PORKCHOP,                /* 34 */
    I_PICK_WOOD, I_PICK_STONE, I_PICK_IRON,   /* 35 36 37 */
    I_AXE_WOOD,  I_AXE_STONE,  I_AXE_IRON,    /* 38 39 40 */
    I_SWORD_WOOD, I_SWORD_STONE, I_SWORD_IRON,/* 41 42 43 */
    /* N1 additions: iron economy + furnace outputs + full iron armour set.
     * Tools (35..43) and armour (47..50) stack to 1; everything else to 64. */
    I_COAL,                    /* 44  coal-ore drop; furnace fuel */
    I_IRON_INGOT,              /* 45  smelted from B_IRON_ORE */
    I_PORKCHOP_COOKED,         /* 46  smelted porkchop */
    I_HELMET_IRON,             /* 47 */
    I_CHEST_IRON,              /* 48 */
    I_LEGS_IRON,               /* 49 */
    I_BOOTS_IRON,              /* 50 */
    /* push3 S0: buckets (stack 1; pick-up/pour behaviour lands S3) */
    I_BUCKET,                  /* 51 */
    I_BUCKET_WATER,            /* 52 */
    I_BUCKET_LAVA,             /* 53 */
    ID_COUNT                   /* 54 */
};

/* contiguous ranges used by stack-cap and armour-slot logic */
#define IS_TOOL(id)  ((id) >= I_PICK_WOOD && (id) <= I_SWORD_IRON)
#define IS_ARMOR(id) ((id) >= I_HELMET_IRON && (id) <= I_BOOTS_IRON)
#define IS_BUCKET(id) ((id) >= I_BUCKET && (id) <= I_BUCKET_LAVA)
/* stack-to-1 ids: tools, armour, buckets (armour..buckets is one run) */
#define IS_SINGLE(id) (IS_TOOL(id) || ((id) >= I_HELMET_IRON && (id) <= I_BUCKET_LAVA))

_Static_assert(ID_COUNT <= 64, "id space must fit in 6 bits of headroom");
_Static_assert(B_COUNT <= ITEM_BASE, "block ids must stay below ITEM_BASE");

#define ITEM_COUNT (ID_COUNT - ITEM_BASE)

/* push3 S2: popup messages in the unused block-id gap (B_COUNT..ITEM_BASE-1)
 * of hud.c's name table, shown via plr.name_block like any item name. Never
 * a real block/item id. */
#define NAME_MAX_FURNACES 29
#define NAME_MAX_CHESTS   30
#define NAME_INV_FULL     31
_Static_assert(B_COUNT <= NAME_MAX_FURNACES, "popup ids must stay in the gap");

/* representative drop/thumb tile per item id, indexed by (id - ITEM_BASE) */
extern const uint8_t items_tile[ITEM_COUNT];

/* tile (T_*) used to draw any id as a thumb/drop cube: block side tile for
 * a block id, the representative item tile for an item id */
uint8_t id_side_tile(uint8_t id);

/* ---- N3 tool-tier gating (pure block x held-item truth table) ----
 *
 * These are the single source of truth for "which tool mines what". They take
 * the block id and the HELD item id explicitly (no player-state dependency) so
 * the host harness can exercise the full block x tool matrix directly. player.c
 * calls them with hotbar_id(hotbar_sel). MC-faithful rules:
 *   - stone / cobble / coal-ore / furnace need a WOOD pick or better;
 *   - iron ore needs a STONE pick or better;
 *   - obsidian (push3) needs an IRON pick;
 *   - everything else (dirt/grass/sand/log/planks/glass/tnt/leaves/table/torch)
 *     is hand-harvestable.
 * With the wrong / no tool a gated block still breaks, but SLOWLY (divisor 1)
 * and drops NOTHING. */

/* pick tier of a held item id: 0 none, 1 wood, 2 stone, 3 iron */
int held_pick_tier(uint8_t held);
/* axe tier of a held item id: 0 none, 1 wood, 2 stone, 3 iron */
int held_axe_tier(uint8_t held);
/* minimum pick tier block b needs to yield a drop: 0 hand-harvestable,
 * 1 = wood pick or better, 2 = stone pick or better, 3 = iron pick (obsidian) */
int block_req_pick(uint8_t b);
/* does breaking b while holding `held` produce a drop? (bedrock never breaks;
 * tnt/leaves are handled specially by the caller — this covers the pick gate) */
bool block_harvestable(uint8_t b, uint8_t held);
/* break-time speed divisor for b with `held`: 1 = no speed-up (slow break),
 * else 2/3/5 for a matching wood/stone/iron tool at a SUFFICIENT tier. */
int mine_divisor(uint8_t b, uint8_t held);

#endif
