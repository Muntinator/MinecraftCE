/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef LIQUID_H
#define LIQUID_H

#include "common.h"

/*
 * push3 S3 — liquids. No per-cell level (no RAM for one): a fixed-radius
 * cellular model over four ids, B_WATER / B_LAVA (sources) and
 * B_WATER_FLOW / B_LAVA_FLOW (flows):
 *  - a flow exists only while supported: the cell above holds the same
 *    liquid, or a horizontal neighbour at the same y is a source of it;
 *  - a source spreads into the cell below when that is open, else into
 *    its 4 open horizontal neighbours (radius 1); flows only fall, so a
 *    waterfall chains down and ends at the floor or in the void;
 *  - infinite water: an open cell wanted by >= 2 water sources, with
 *    something solid below it, becomes a source;
 *  - water + lava: a cell wanted by both -> cobble; a lava flow touching
 *    water -> cobble; a lava source touching water -> obsidian.
 * "Open" = air, torch, sapling or a flow; liquids never replace anything
 * else. Nothing scans the world: edits push the cell into a 16-entry ring
 * queue (32 B) and liquids_tick pops 4 per tick, re-evaluating the cell and
 * its 6 neighbours; every change pushes its own cell. A loaded world (and
 * a Normal world's lakes) stays static until something next to it changes.
 */

#define LIQ_QMAX 16            /* power of two */

void liquids_reset(void);                   /* empty queue (mesh_init) */
void liquid_push(int x, int y, int z);      /* re-evaluate around a cell */
void liquids_tick(void);                    /* from player_tick */
/* set a cell as a liquid event (bucket, flow): mesh + compositor + light +
 * torch list, then push it */
void liquid_set(int x, int y, int z, uint8_t b);
/* is any of the 6 neighbours of (x,y,z) a liquid? (explosions push only
 * those crater cells) */
bool liquid_near(int x, int y, int z);

#endif
