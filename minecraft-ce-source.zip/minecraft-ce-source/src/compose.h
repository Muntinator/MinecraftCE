/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef COMPOSE_H
#define COMPOSE_H

#include "common.h"
#include "render.h"

/*
 * Frame compositor: renders world + entities + target outline into fb.
 * When the camera is unchanged since the previous composed frame, only
 * the dirty screen rects are re-rendered (entity movement, block edits,
 * expired overlays) — fb must already hold the previous frame's pixels
 * (on calc: gfx_BlitScreen() before calling; on host the buffer
 * persists). The HUD is NOT drawn here; draw it after, full-res.
 */

void compose_invalidate(void);   /* next frame renders fully */

/* register a full-res rect whose world pixels must be restored this
 * frame (an overlay drawn after present vanished/moved: name popup,
 * break bar, debug readout) */
void compose_add_rect(int x0, int y0, int x1, int y1);

/* report a world edit at cell (x,y,z); player.c calls this next to
 * mesh_dirty_block so the compositor can redraw a tight rect */
void compose_add_block(int x, int y, int z);

void compose_frame(uint8_t *fb, const camera_t *cam);

extern uint16_t compose_stat_full, compose_stat_dirty;

#endif
