/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * s4scene.h — push3 S4: the deterministic sapling scene, shared by the calc
 * S4_TEST build (main.c) and host --s4sapling (harness.c) so their
 * framebuffers are byte-identical (autotest-s4sapling.json).
 *
 * The Skyblock island; three saplings planted on its grass (listed for the
 * sprite pass like placed ones) and the REAL decay cursor + leaf RNG ticked
 * from leaves_reset() until the first of them grows into the world_gen tree
 * (exercises the eZ80 32-bit LCG, the growth roll, grow_tree and the remesh).
 * The camera looks from the spawn corner at the island: the grown tree, the
 * two remaining saplings as keyed camera-facing sprites (torches_draw).
 */

#ifndef S4SCENE_H
#define S4SCENE_H

#include "world.h"
#include "mesh.h"
#include "light.h"
#include "player.h"
#include "demo.h"

#define S4_CAM_X (16 * FIX_ONE)
#define S4_CAM_Y (6 * FIX_ONE + 2600)
#define S4_CAM_Z (16 * FIX_ONE)
#define S4_YAW   40
#define S4_PITCH (-12)

static const uint8_t s4_saplings[3][3] = {
    { 21, 5, 16 }, { 18, 5, 17 }, { 17, 5, 20 },
};

/* returns the decay ticks until the first sapling grew */
static inline int s4_build_scene(void)
{
    g_worldtype = 2;                 /* Skyblock island */
    world_gen(DEMO_SEED);
    for (int i = 0; i < 3; i++)
        world_set(s4_saplings[i][0], s4_saplings[i][1], s4_saplings[i][2],
                  B_SAPLING);
    mesh_init();                     /* light_reset lists the saplings */
    leaves_reset();
    plr.x = plr.y = plr.z = 0;       /* nobody stands in a trunk */
    int t = 0;
    while (torch_n == 3 && t < 30000) {
        leaves_decay_tick();
        t++;
    }
    return t;
}

#endif
