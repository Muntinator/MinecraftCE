/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * script.h — deterministic input playback for the M4 parity frame.
 * Both the calc DEMO_PLAY build and the host --play mode run exactly this
 * sequence (one 30Hz tick per frame) from the demo world/spawn, then the
 * final frame is hashed. Exercises walking, gravity, jumping, looking,
 * hotbar cycling, breaking, and placing through the whole game loop.
 */

#ifndef SCRIPT_H
#define SCRIPT_H

#include "player.h"

typedef struct {
    uint8_t frames;
    unsigned int input;
} script_step_t;

static const script_step_t demo_script[] = {
    { 30, 0 },                          /* settle: fall to the ground */
    { 20, IN_FWD },                     /* walk forward */
    { 10, IN_FWD | IN_JUMP },           /* hop */
    { 16, IN_LOOK_R },                  /* pan right */
    { 12, IN_FWD },
    { 10, IN_LOOK_D },                  /* look down at the ground */
    { 20, IN_BREAK },                   /* dig (instant in creative) */
    { 4,  IN_HOTNEXT },                 /* switch to dirt */
    { 6,  0 },
    { 4,  IN_PLACE },                   /* place it back */
    { 10, IN_LOOK_U | IN_LOOK_L },
    { 12, IN_BACK },
    { 1,  0 },
};

#define SCRIPT_LEN (sizeof demo_script / sizeof demo_script[0])

#endif
