/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef HUD_H
#define HUD_H

#include "common.h"
#include "player.h"   /* slot_t */
#include "furnace.h"  /* furnace_t (furnace UI) */

void hud_crosshair(uint8_t *fb);   /* into the 3D viewport */
void hud_draw(uint8_t *fb);        /* the bottom panel + hotbar + hand */
/* push3 HAND: the held item's fixed 48x48 box (bottom-right, clear of the
 * hotbar, hearts/hunger/armour and the m6/m7 hash row 216) */
#define HAND_X 264
#define HAND_Y 156
/* compositor restore rects for the post-present overlays (popup, break bar,
 * debug, slot marker, armour row, hand); returns 1 when a windowed viewport
 * must redraw its letterbox (render_present) instead. Call before
 * compose_frame. */
uint8_t hud_restore_rects(void);

/* N6: seed a deterministic survival HUD state (health/hunger/armor + a hotbar)
 * shared by the calc N6_TEST build and host --n6hud so the golden frame is
 * byte-identical on both. */
void hud_n6_demo(void);

/* ---- N2: unified MATTIS inventory + crafting screen ----
 * One full-screen panel: category tabs + horizontally scrollable recipe
 * strip + ingredient/output detail up top; the player grids (27 main + 9
 * hotbar + 4 armor) below. A cursor carries a picked-up stack. All state
 * lives in inv_ui_t so the draw is pure and the interaction is a portable
 * state machine the host harness can drive. */

/* focus zones the cursor can occupy */
enum inv_focus { FOC_TABS = 0, FOC_STRIP, FOC_MAIN, FOC_HOT, FOC_ARMOR };

/* edge-event bits fed to inv_ui_input */
enum inv_ev {
    EV_LEFT = 1, EV_RIGHT = 2, EV_UP = 4, EV_DOWN = 8,
    EV_ENTER = 16, EV_DEL = 32, EV_CLOSE = 64
};

typedef struct {
    uint8_t tab;            /* active category CAT_* (0..2) */
    uint8_t focus;          /* FOC_* */
    uint8_t strip_sel;      /* index within the active tab's recipe list */
    uint8_t strip_scroll;   /* first visible recipe in the strip */
    uint8_t main_cur;       /* 0..26 backpack cursor */
    uint8_t hot_cur;        /* 0..8 hotbar cursor */
    uint8_t arm_cur;        /* 0..3 armor cursor */
    slot_t  cursor;         /* the stack carried on the cursor (count 0 = none) */
    slot_t *origin;         /* slot a carried stack came from (Del returns it) */
    uint8_t has_table;      /* 1 = a crafting table is available (unlocks the
                               needs_table recipes); 0 = hand crafting only */
    uint8_t last_craft;     /* id of the most recent craft output (name popup) */
} inv_ui_t;

void inv_ui_reset(inv_ui_t *ui);              /* init on open */
int  inv_ui_input(inv_ui_t *ui, uint8_t ev, int digit);  /* returns 1 = close */
void hud_inventory_screen(uint8_t *fb, const inv_ui_t *ui);
void inv_ui_demo(inv_ui_t *ui);               /* shared deterministic test seed */

/* ---- N4: furnace UI (input / fuel / output + flame + arrow, over the
 * player grid). Same carried-cursor model; the same inv_ev events drive it.
 * Smelting keeps ticking in the background (furnaces_tick) while it's open.
 * push3 S2: the chest UI is the same screen with the 27-slot chest grid
 * where the furnace draws in/fuel/out: ONE container state machine + draw
 * (cont_ui_t; f set = furnace screen, c set = chest screen). The furnace_* /
 * chest_* names below are that one implementation. */
enum fur_focus { FUR_IN = 0, FUR_FUEL, FUR_OUT, FUR_MAIN, FUR_HOT, CH_CHEST };
#define CH_MAIN FUR_MAIN
#define CH_HOT  FUR_HOT

typedef struct {
    furnace_t *f;           /* the furnace being viewed (furnace screen) */
    chest_t *c;             /* the chest being viewed (chest screen) */
    uint8_t focus;          /* FUR_* / CH_* */
    uint8_t main_cur;       /* 0..26 backpack cursor */
    uint8_t hot_cur;        /* 0..8 hotbar cursor */
    uint8_t ch_cur;         /* 0..26 chest-grid cursor */
    slot_t  cursor;         /* carried stack (count 0 = none) */
    slot_t *origin;         /* slot a carried stack came from (Del returns it) */
} cont_ui_t;
typedef cont_ui_t furnace_ui_t;
typedef cont_ui_t chest_ui_t;

void cont_ui_reset(cont_ui_t *ui, furnace_t *f, chest_t *c);
int  cont_ui_input(cont_ui_t *ui, uint8_t ev, int digit);   /* 1 = close */
void hud_cont_screen(uint8_t *fb, const cont_ui_t *ui);
#define furnace_ui_reset(ui, f)   cont_ui_reset(ui, f, 0)
#define chest_ui_reset(ui, c)     cont_ui_reset(ui, 0, c)
#define furnace_ui_input          cont_ui_input
#define chest_ui_input            cont_ui_input
#define hud_furnace_screen        hud_cont_screen
#define hud_chest_screen          hud_cont_screen
void furnace_ui_demo(furnace_ui_t *ui, furnace_t *f);  /* deterministic seed */
void chest_ui_demo(chest_ui_t *ui, chest_t *c);        /* deterministic seed */

extern uint8_t hud_debug;
extern uint16_t hud_fps10;

#endif
