/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef MOB_H
#define MOB_H

#include "common.h"
#include "render.h"

#define MOB_MAX 10           /* must hold HOSTILE_MAX(6) + PIG_MAX(3) = 9
                               simultaneously (+1 spare). M26 raised the spawn
                               caps; at 6 slots hostiles starved pigs entirely
                               (no free slot -> pigs never spawned). */

/* mob kinds — retires the old (i & 1) creeper/zombie convention */
enum mob_kind { K_CREEPER = 0, K_ZOMBIE = 1, K_PIG = 2 };

typedef struct {
    fix x, y, z, vy;
    uint8_t yaw;
    uint8_t alive;
    uint8_t kind;         /* K_CREEPER / K_ZOMBIE / K_PIG */
    uint8_t hurt_cd;      /* zombie melee cooldown */
    uint8_t fuse;         /* creeper: >0 while hissing */
    uint8_t flee;         /* pig: ticks left fleeing after a punch */
    int8_t health;        /* punches left to kill */
    uint8_t flash;        /* white hit-flash ticks */
    int16_t bb[4];        /* last drawn screen bbox (render coords);
                             bb[0] > bb[2] = nothing drawn */
} mob_t;

extern mob_t mobs[MOB_MAX];
extern uint8_t g_mobs_on;
/* the day clock: 512 ticks per phase, 32 phases (brightness in main.c, night
 * spawns here); mobs_spawn sets noon, mobs_tick advances it per g_daynight */
extern uint16_t g_daytime;

void mobs_spawn(uint32_t seed);
void mobs_boot_pigs(void);                  /* game session: boot pair -> pigs */
void mobs_tick(void);                       /* call once per game tick */
void mobs_draw(uint8_t *fb, const camera_t *cam);

/* melee: walk the look ray (stops at walls); returns mob index or -1 */
int mobs_pick(fix ox, fix oy, fix oz, fix dx, fix dy, fix dz);
/* deal `dmg` hearts to mob i (fist 1 / wood 2 / stone 3 / iron 4 sword),
 * plus knockback + death drop */
void mob_punch(int i, int dmg);

#endif
