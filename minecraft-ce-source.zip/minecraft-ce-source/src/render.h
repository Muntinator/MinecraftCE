/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef RENDER_H
#define RENDER_H

#include "common.h"

typedef struct {
    fix x, y, z;        /* 12.12 world position */
    uint8_t yaw;        /* 256-step, 0 looks toward +z */
    int8_t pitch;       /* steps, clamped to +/-60; positive looks up */
} camera_t;

/* camera basis (sin/cos of yaw & pitch) + position for the current frame.
 * Exported as ONE struct with a fixed field order so the hand-written eZ80
 * vertex transform (src/xform.asm) can read the values at fixed byte
 * offsets. render_frame_rect writes it each frame exactly where the old
 * file-static camera globals were written. */
typedef struct { fix sy, cy, sp, cp, cx, cyy, cz; } rcam_t;
extern rcam_t rcam;

/* projection frame globals — exposed (non-static) so the hand-written eZ80
 * fused projection kernel (src/project.asm) can read _rfocal/_rcx/_rcy. */
extern int rfocal, rcx, rcy;

void render_frame(uint8_t *fb, const camera_t *cam);

/* expand the scaled render to fb (no-op in Quality); call after all
 * world-space drawing, before the HUD */
void render_present(uint8_t *fb);

/* ---- dirty-rect compositing (all coords in RENDER units: divide
 * full-res coords by render_scale()) ---- */
int render_scale(void);                       /* 1, 2 or 4 */
void render_window_info(int *ox, int *oy, int *scale);
void render_frame_rect(uint8_t *fb, const camera_t *cam,
                       int x0, int y0, int x1, int y1);
void render_present_rect(uint8_t *fb, int x0, int y0, int x1, int y1);
/* chunk -> screen rect; 0 = unreliable (chunk crosses the frustum) */
int render_chunk_rect(const camera_t *cam, int ci,
                      int *x0, int *y0, int *x1, int *y1);
/* edited block (3x3x3 neighborhood) -> screen rect; 0 = unreliable */
int render_block_rect(const camera_t *cam, int bx, int by, int bz,
                      int *x0, int *y0, int *x1, int *y1);
/* bbox accumulator grown by render_box / render_face_outline */
extern int rbb_x0, rbb_y0, rbb_x1, rbb_y1;
void render_bbox_reset(void);

/* 19200-byte scaled-frame buffer; safely reusable as scratch OUTSIDE
 * the render loop (save.c borrows it for RLE) */
extern uint8_t render_scratch[];

/* frame stats, for the fps/debug overlay and perf notes */
extern uint16_t rstat_faces;

/* render distance in blocks (Chebyshev, chunk centers); 6..24 sensible */
extern uint8_t view_radius;
extern uint8_t view_h;    /* viewport rows: 168 game, 240 title vista */
extern uint8_t g_textures; /* settings toggles */
extern uint8_t g_gfxmode;  /* pixel scale: 0 = 1x, 1 = 2x, 2 = 4x */
extern uint8_t g_viewport; /* window: 0 full, 1 160x120, 2 80x60 */
extern uint8_t g_night_sky; /* shell sets this at night: draw stars */

/* shell keypad-poll hook, called during rendering (may be NULL) */
extern void (*render_poll)(void);

/* test hook (harness --cavecull): force-disable Stage A cave culling so a
 * frame renders every cave face exactly as it did before Stage A */
extern uint8_t g_cave_cull_off;

/* flat-shaded axis-aligned box through the world pipeline (mobs) */
void render_face_outline(uint8_t *fb, int x, int y, int z, int dir);
void render_box(uint8_t *fb, fix bx, fix by, fix bz, fix half, fix height,
                uint8_t base, const uint8_t *tex);
/* per-face variant: independent tiles for the visible x side and z side
 * (either NULL -> flat); top stays a flat fill. */
void render_box_faces(uint8_t *fb, fix bx, fix by, fix bz, fix half,
                      fix height, uint8_t base,
                      const uint8_t *xtex, const uint8_t *ztex);

/* UI U3: transform + project one world point (12.12) with the frame's
 * camera (the same transform_fix + PROJECT_PT path render_box's corners
 * take). Returns 0 when the point is behind the near plane (outputs
 * untouched); *depth = camera-space z, 12.12, for distance sizing.
 * sx/sy are render-target coordinates (already divided by the pixel
 * scale), like every entity rect. */
int render_project(fix x, fix y, fix z, int *sx, int *sy, fix *depth);

/* UI U3: camera-facing sprite: a 16x16 tile drawn `size` render px square
 * (nearest-neighbour, at most SPRITE_MAX) centred on (sx,sy) into the
 * current render target, texels == key skipped (TEX_KEY for item icons;
 * push3 S4: the sapling passes its inset background index), no shading,
 * clipped to the scissor; grows the bbox accumulator like render_box. */
#define SPRITE_MAX 64
void render_sprite16(int sx, int sy, int size, const uint8_t *tile,
                     uint8_t key);

#ifdef __ez80__
/* push3 HAND: load a 16x16 tile into the asm rasterizer's 256-aligned
 * texture page (tpage_ptr), cached like span_tex's own loads */
void render_tpage(const uint8_t *tex);
#endif

#endif
