/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * common.h — shared basics for the calc build and the host harness.
 *
 * Parity contract: everything the renderer computes must be bit-identical
 * on eZ80 and host. The hot path uses `fix` — the platform's NATIVE int
 * (24-bit on eZ80, 32-bit on host) holding 12.12 fixed point. Values are
 * kept inside +/-2^22 so 24- and 32-bit arithmetic agree exactly.
 *
 * fp_mul / fp_div are the only multiply/divide kernels allowed on `fix`
 * values in hot code: on the calc they are exact asm (src/fpmath.asm,
 * validated bit-for-bit by `make FPTEST=1` + tools/host/genfptest.py);
 * on the host they are the int64 expressions below. Semantics:
 *   fp_mul(a,b) = floor((a*b) / 2^12)      requires |a*b| < 2^35
 *   fp_div(a,b) = trunc((a<<12) / b)       requires b != 0, |result| < 2^23
 *
 * Plain C * and / on `fix`/int are allowed only outside hot loops or where
 * both operands are provably small (the compiler's 24-bit helpers are
 * mediocre but fine in cold code). int32_t stays for world generation.
 */

#ifndef COMMON_H
#define COMMON_H

#include <stdint.h>
#include <stdbool.h>

typedef int32_t fix32;   /* cold-path / world-gen 32-bit values */

#ifdef __ez80__
typedef int fix;         /* 24-bit native */
int fp_mul(int a, int b);
int fp_div(int a, int b);
#else
typedef int32_t fix;
static inline fix fp_mul(fix a, fix b)
{
    return (fix)(((int64_t)a * (int64_t)b) >> 12);
}
static inline fix fp_div(fix a, fix b)
{
    return (fix)(((int64_t)a << 12) / b);
}
#endif

#define FMUL(a, b) fp_mul((a), (b))
#define FDIV(a, b) fp_div((a), (b))

#define FIX_ONE   4096
#define FIX_SHIFT 12

#define SCREEN_W 320
#define SCREEN_H 240

#define INT_TO_FIX(a) ((fix)(a) << FIX_SHIFT)
#define FIX_TO_INT(a) ((int)((a) >> FIX_SHIFT))

#endif
