/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef TEXTURES_H
#define TEXTURES_H

#include "common.h"
#include "world.h"

/* 16x16 8bpp texture tiles (convimg-generated; palette indices 0..60).
 * World-block tiles (UI U1) and item icons (UI U3) come from gfx/lce/
 * (tools/gen_lce_assets.py slices the official Mojang textures); mob tiles
 * still from gfx/.
 * UI U3: item icons are TRANSPARENT: after textures_init every texel of the
 * T_ICO_FIRST..T_ICO_LAST run that convimg put on the fixed magenta slot 60
 * is TEX_KEY (0xFF) and must be skipped by every blit (hud.c blit16_t,
 * render_sprite16). 0xFF can never be a real texel: raw tiles hold palette
 * indices 0..63 (shade banks are OR-ed in at draw time) and --palcheck
 * forbids PAL_SKY 63 in tiles. Icon tiles never reach the world rasterizer
 * (item drops are sprites), so the key never meets a bank OR.
 * Texture ids: */
enum tex_id {
    T_GRASS_TOP, T_GRASS_SIDE, T_DIRT, T_STONE, T_COBBLE,
    T_LOG_TOP, T_LOG_SIDE, T_LEAVES, T_PLANKS, T_SAND,
    T_WATER, T_GLASS, T_BEDROCK, T_TNT_TOP, T_TNT_SIDE, T_TNT_BOTTOM,
    T_CREEPER, T_ZOMBIE,
    T_COAL_ORE, T_IRON_ORE,               /* iron replaces gold (N1) */
    /* M21 per-face mob tiles (creeper/zombie fronts stay T_CREEPER/T_ZOMBIE) */
    T_CREEPER_SIDE, T_CREEPER_BODY,
    T_ZOMBIE_SIDE, T_ZOMBIE_BODY, T_ZOMBIE_BODY_S,
    T_PIG_FACE, T_PIG_SIDE, T_PIG_BODY,       /* pig entity arrives in M22 */
    /* N1 new world-block tiles (behaviour lands N4/N5) */
    T_FURNACE_FRONT, T_FURNACE_SIDE, T_FURNACE_TOP,
    T_TABLE_TOP, T_TABLE_SIDE, T_TORCH,
    /* N1 item icons (16x16 opaque; also wrap item drop-cubes) */
    T_ICO_STICK, T_ICO_COAL, T_ICO_INGOT, T_ICO_PORK, T_ICO_PORK_COOKED,
    T_ICO_PICK_W, T_ICO_PICK_S, T_ICO_PICK_I,
    T_ICO_AXE_W, T_ICO_AXE_S, T_ICO_AXE_I,
    T_ICO_SWORD_W, T_ICO_SWORD_S, T_ICO_SWORD_I,
    T_ICO_HELMET, T_ICO_CHEST, T_ICO_LEGS, T_ICO_BOOTS,
    /* push3 S0: bucket icons (kept right after the N1 icons so the icon run
     * T_ICO_STICK..T_ICO_BUCKET_LAVA stays contiguous), then the Skyblock
     * block tiles. Flowing water/lava reuse T_WATER/T_LAVA. */
    T_ICO_BUCKET, T_ICO_BUCKET_WATER, T_ICO_BUCKET_LAVA,
    /* UI U3: gunpowder gets its own icon (items.png 8,2) so every item id
     * maps into the icon run; kept inside the run (before the S0 blocks) */
    T_ICO_GUNPOWDER,
    T_CHEST_TOP, T_CHEST_SIDE, T_CHEST_FRONT,
    T_LAVA, T_OBSIDIAN, T_SAPLING,
    /* N4: lit-furnace front, appended after the S0 tiles so no existing
     * tile shifts. UI U1: a real convimg tile now (terrain.png #61, the
     * atlas' burning furnace front) instead of the runtime-painted glow. */
    T_FURNACE_FRONT_LIT,
    /* UI U1: the in-world torch box face (terrain.png #80's 2x10 stick +
     * flame scaled to the tile); T_TORCH stays the thumbnail/drop tile */
    T_TORCH_BOX,
    T_COUNT
};

/* the contiguous transparent-icon run (UI U3) and its transparent key */
#define T_ICO_FIRST T_ICO_STICK
#define T_ICO_LAST  T_ICO_GUNPOWDER
#define TEX_KEY     0xFF

extern const uint8_t *tex_data[T_COUNT];

/* per block: top / side / bottom texture id */
extern const uint8_t block_tex[B_COUNT][3];

/* most-common palette index per texture (deterministic mode; ties to the
 * lower index) — used for LOD flat fills and crack-patch edge lines */
extern uint8_t tex_avg[T_COUNT];

void textures_init(void);

#endif
