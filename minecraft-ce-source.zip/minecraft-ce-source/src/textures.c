/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#include "textures.h"
#include "palette.h"

/* raw convimg outputs (avoid gfx.h: it pulls graphx types the host build
 * doesn't have) */
extern unsigned char tex_creeper_data[258], tex_zombie_data[258];
extern unsigned char tex_grass_top_data[258], tex_grass_side_data[258],
    tex_dirt_data[258], tex_stone_data[258], tex_cobble_data[258],
    tex_log_top_data[258], tex_log_side_data[258], tex_leaves_data[258],
    tex_planks_data[258], tex_sand_data[258], tex_water_data[258],
    tex_glass_data[258], tex_bedrock_data[258], tex_tnt_top_data[258],
    tex_tnt_side_data[258], tex_tnt_bottom_data[258],
    tex_coal_ore_data[258], tex_iron_ore_data[258],
    tex_creeper_side_data[258], tex_creeper_body_data[258],
    tex_zombie_side_data[258], tex_zombie_body_data[258],
    tex_zombie_body_s_data[258],
    tex_pig_face_data[258], tex_pig_side_data[258], tex_pig_body_data[258],
    tex_furnace_front_data[258], tex_furnace_side_data[258],
    tex_furnace_top_data[258], tex_table_top_data[258], tex_table_side_data[258],
    tex_torch_data[258],
    tex_ico_stick_data[258], tex_ico_coal_data[258], tex_ico_ingot_data[258],
    tex_ico_pork_data[258], tex_ico_pork_cooked_data[258],
    tex_ico_pick_w_data[258], tex_ico_pick_s_data[258], tex_ico_pick_i_data[258],
    tex_ico_axe_w_data[258], tex_ico_axe_s_data[258], tex_ico_axe_i_data[258],
    tex_ico_sword_w_data[258], tex_ico_sword_s_data[258], tex_ico_sword_i_data[258],
    tex_ico_helmet_data[258], tex_ico_chest_data[258], tex_ico_legs_data[258],
    tex_ico_boots_data[258],
    tex_ico_bucket_data[258], tex_ico_bucket_water_data[258],
    tex_ico_bucket_lava_data[258], tex_ico_gunpowder_data[258],
    tex_chest_top_data[258], tex_chest_side_data[258], tex_chest_front_data[258],
    tex_lava_data[258], tex_obsidian_data[258], tex_sapling_data[258],
    tex_furnace_front_lit_data[258], tex_torch_box_data[258];

/* convimg sprites carry 2 header bytes (w, h) before the 256 texels.
 * textures_init writes through these pointers (black remap): the convimg
 * arrays live in RAM. */
const uint8_t *tex_data[T_COUNT] = {
    tex_grass_top_data + 2, tex_grass_side_data + 2, tex_dirt_data + 2,
    tex_stone_data + 2, tex_cobble_data + 2, tex_log_top_data + 2,
    tex_log_side_data + 2, tex_leaves_data + 2, tex_planks_data + 2,
    tex_sand_data + 2, tex_water_data + 2, tex_glass_data + 2,
    tex_bedrock_data + 2, tex_tnt_top_data + 2, tex_tnt_side_data + 2,
    tex_tnt_bottom_data + 2, tex_creeper_data + 2, tex_zombie_data + 2,
    tex_coal_ore_data + 2, tex_iron_ore_data + 2,
    tex_creeper_side_data + 2, tex_creeper_body_data + 2,
    tex_zombie_side_data + 2, tex_zombie_body_data + 2,
    tex_zombie_body_s_data + 2,
    tex_pig_face_data + 2, tex_pig_side_data + 2, tex_pig_body_data + 2,
    tex_furnace_front_data + 2, tex_furnace_side_data + 2,
    tex_furnace_top_data + 2, tex_table_top_data + 2, tex_table_side_data + 2,
    tex_torch_data + 2,
    tex_ico_stick_data + 2, tex_ico_coal_data + 2, tex_ico_ingot_data + 2,
    tex_ico_pork_data + 2, tex_ico_pork_cooked_data + 2,
    tex_ico_pick_w_data + 2, tex_ico_pick_s_data + 2, tex_ico_pick_i_data + 2,
    tex_ico_axe_w_data + 2, tex_ico_axe_s_data + 2, tex_ico_axe_i_data + 2,
    tex_ico_sword_w_data + 2, tex_ico_sword_s_data + 2, tex_ico_sword_i_data + 2,
    tex_ico_helmet_data + 2, tex_ico_chest_data + 2, tex_ico_legs_data + 2,
    tex_ico_boots_data + 2,
    tex_ico_bucket_data + 2, tex_ico_bucket_water_data + 2,
    tex_ico_bucket_lava_data + 2,
    tex_ico_gunpowder_data + 2,     /* T_ICO_GUNPOWDER (UI U3) */
    tex_chest_top_data + 2, tex_chest_side_data + 2, tex_chest_front_data + 2,
    tex_lava_data + 2, tex_obsidian_data + 2, tex_sapling_data + 2,
    tex_furnace_front_lit_data + 2, /* T_FURNACE_FRONT_LIT: terrain.png #61
                                       (UI U1; was built at runtime) */
    tex_torch_box_data + 2,         /* T_TORCH_BOX */
};

const uint8_t block_tex[B_COUNT][3] = {
    /* top          side          bottom */
    { 0, 0, 0 },                                      /* air */
    { T_GRASS_TOP, T_GRASS_SIDE, T_DIRT },            /* grass */
    { T_DIRT, T_DIRT, T_DIRT },
    { T_STONE, T_STONE, T_STONE },
    { T_COBBLE, T_COBBLE, T_COBBLE },
    { T_LOG_TOP, T_LOG_SIDE, T_LOG_TOP },             /* log */
    { T_LEAVES, T_LEAVES, T_LEAVES },
    { T_PLANKS, T_PLANKS, T_PLANKS },
    { T_SAND, T_SAND, T_SAND },
    { T_WATER, T_WATER, T_WATER },
    { T_GLASS, T_GLASS, T_GLASS },
    { T_BEDROCK, T_BEDROCK, T_BEDROCK },
    { T_TNT_TOP, T_TNT_SIDE, T_TNT_BOTTOM },          /* tnt */
    { T_COAL_ORE, T_COAL_ORE, T_COAL_ORE },
    { T_IRON_ORE, T_IRON_ORE, T_IRON_ORE },           /* iron ore */
    { T_TABLE_TOP, T_TABLE_SIDE, T_PLANKS },          /* crafting table */
    { T_FURNACE_TOP, T_FURNACE_FRONT, T_FURNACE_TOP },/* furnace (front on all
                                                         sides — non-directional,
                                                         the world stores no
                                                         per-block facing) */
    { T_TORCH, T_TORCH, T_TORCH },                    /* torch */
    { T_FURNACE_TOP, T_FURNACE_FRONT_LIT, T_FURNACE_TOP }, /* B_FURNACE_LIT:
                                                         lit front on all sides */
    { T_CHEST_TOP, T_CHEST_FRONT, T_CHEST_TOP },      /* chest: front on all
                                                         sides, like the furnace */
    { T_WATER, T_WATER, T_WATER },                    /* water_flow */
    { T_LAVA, T_LAVA, T_LAVA },                       /* lava */
    { T_LAVA, T_LAVA, T_LAVA },                       /* lava_flow */
    { T_OBSIDIAN, T_OBSIDIAN, T_OBSIDIAN },           /* obsidian */
    { T_SAPLING, T_SAPLING, T_SAPLING },              /* sapling (thumb/drop;
                                                         world draw is S4) */
};

uint8_t tex_avg[T_COUNT];

/* convimg's base palette (1555 LE) — the flat-colour pick needs real RGB */
extern unsigned char global_palette[128];

static void tex_rgb(int i, int *r, int *g, int *b)
{
    unsigned v = (unsigned)global_palette[i * 2] |
                 ((unsigned)global_palette[i * 2 + 1] << 8);
    int r5 = (v >> 10) & 31, g5 = (v >> 5) & 31, b5 = v & 31;
    *r = (r5 << 3) | (r5 >> 2);
    *g = (g5 << 3) | (g5 >> 2);
    *b = (b5 << 3) | (b5 >> 2);
}

void textures_init(void)
{
    /* UI U3: icon transparency. gen_lce_assets.py paints an icon's
     * transparent texels the placeholder magenta pinned on fixed slot 60
     * (= PAL_TEXBLACK's slot, which no real texel is near), so convimg maps
     * them there; turn them into the TEX_KEY 0xFF that the UI/sprite blits
     * skip. Must run BEFORE the black remap below puts real black on 60. */
    for (int t = T_ICO_FIRST; t <= T_ICO_LAST; t++) {
        uint8_t *d = (uint8_t *)tex_data[t];
        for (int i = 0; i < 256; i++)
            if (d[i] == PAL_TEXBLACK)
                d[i] = TEX_KEY;
    }
    /* PAL_BLACK's banks are the sky ramp (palette.c), so a shaded black texel
     * would turn sky-blue: move every tile's black onto PAL_TEXBLACK (convimg
     * arrays live in RAM). */
    for (int t = 0; t < T_COUNT; t++) {
        uint8_t *d = (uint8_t *)tex_data[t];
        for (int i = 0; i < 256; i++)
            if (d[i] == PAL_BLACK)
                d[i] = PAL_TEXBLACK;
    }
    for (int t = 0; t < T_COUNT; t++) {
        /* modal color for flat fills. Black and sky never stand in for a
         * whole face (leaves' gaps outnumber any one green and drew them
         * black); uint16 because a one-color tile counts to 256.
         * UI U1: only colours near the tile's mean RGB (L1 <= 192) compete:
         * the Mojang furnace side/front have their dark outline as the single
         * most common index (35 texels vs 32 of the body grey), which made
         * the whole flat face near-black. Falls back to the plain mode. */
        uint16_t count[64];
        for (int i = 0; i < 64; i++)
            count[i] = 0;
        const uint8_t *d = tex_data[t];
        int32_t sr = 0, sg = 0, sb = 0;
        int n = 0;
        for (int i = 0; i < 256; i++)
            if (d[i] != PAL_TEXBLACK && d[i] != PAL_SKY && d[i] != TEX_KEY) {
                int r, g, b;
                count[d[i] & 63]++;
                tex_rgb(d[i] & 63, &r, &g, &b);
                sr += r; sg += g; sb += b; n++;
            }
        int best = 0, near_best = -1;
        for (int i = 1; i < 64; i++)
            if (count[i] > count[best])
                best = i;
        if (n) {
            int mr = (int)(sr / n), mg = (int)(sg / n), mb = (int)(sb / n);
            for (int i = 0; i < 64; i++) {
                int r, g, b;
                if (!count[i])
                    continue;
                tex_rgb(i, &r, &g, &b);
                int dist = (r > mr ? r - mr : mr - r) + (g > mg ? g - mg : mg - g) +
                           (b > mb ? b - mb : mb - b);
                if (dist <= 192 && (near_best < 0 || count[i] > count[near_best]))
                    near_best = i;
            }
        }
        tex_avg[t] = (uint8_t)(near_best >= 0 ? near_best : best);
    }
}
