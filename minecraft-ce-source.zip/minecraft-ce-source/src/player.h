/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef PLAYER_H
#define PLAYER_H

#include "common.h"
#include "render.h"
#include "items.h"

/* input bits, shared by the calc shell and the playback script */
#define IN_FWD     (1 << 0)
#define IN_LEFT    (1 << 1)
#define IN_BACK    (1 << 2)
#define IN_RIGHT   (1 << 3)
#define IN_JUMP    (1 << 4)
#define IN_LOOK_L  (1 << 5)
#define IN_LOOK_R  (1 << 6)
#define IN_LOOK_U  (1 << 7)
#define IN_LOOK_D  (1 << 8)
#define IN_BREAK   (1 << 9)
#define IN_PLACE   (1 << 10)
#define IN_HOTNEXT (1 << 11)

#define MODE_CREATIVE 0
#define MODE_SURVIVAL 1

/* N1 slot inventory: the single source of truth for what the player carries.
 * Each stack lives in exactly one slot (id + count); a count of 0 = empty
 * (id ignored). The held item is hotbar[hotbar_sel]. Blocks/items stack to
 * STACK_MAX; tools and armour to 1. Replaces the old per-id count array. */
#define HOTBAR_SLOTS 9
#define MAIN_SLOTS   27
#define ARMOR_SLOTS  4
#define STACK_MAX    64

typedef struct {
    uint8_t id;
    uint8_t count;
} slot_t;

typedef struct {
    fix x, y, z;          /* feet center */
    fix vx, vy, vz;
    uint8_t yaw;
    int8_t pitch;
    uint8_t on_ground;
    uint8_t mode;
    uint8_t hotbar_sel;
    uint8_t hotnext_latch;  /* edge-trigger for hotbar cycling */
    uint8_t place_latch;
    /* hold-to-break state */
    int8_t break_x, break_y, break_z;
    uint8_t break_ticks;
    uint8_t break_max;            /* effective ticks to break the current
                                     target (for the HUD progress bar) */
    /* raycast result cache (refreshed every tick) */
    int8_t hit_x, hit_y, hit_z;   /* -1 if none */
    int8_t face;                  /* dir of the hit face (DIR_*) */
    int8_t health;                /* 0..10, survival */
    /* N6 hunger + saturation (survival). hunger is the 0..HUNGER_MAX food bar
     * (drawn as 10 drumsticks); saturation is the count of "free" drain events
     * a cooked meal grants (each free event skips one hunger tick). exhaustion
     * accumulates from block breaks / jumps / passive time and drains hunger a
     * point at a time; the three timers pace passive drain / regen / starve. */
    uint8_t hunger;
    uint8_t saturation;
    uint8_t exhaustion;
    uint16_t hunger_timer;        /* passive-drain cadence */
    uint16_t regen_timer;         /* health regen cadence (hunger high) */
    uint16_t starve_timer;        /* starvation cadence (hunger 0) */
    fix fall_top;                 /* highest y since airborne */
    slot_t hotbar[HOTBAR_SLOTS];  /* survival held row; creative ignores it and
                                     uses the fixed hotbar_blocks[] palette */
    slot_t main_inv[MAIN_SLOTS];  /* 27-slot backpack (survival) */
    slot_t armor[ARMOR_SLOTS];    /* helmet/chest/legs/boots (N6 wires effect) */
    uint8_t name_ticks;           /* block-name popup countdown */
    uint8_t name_block;           /* block id the popup names */
    uint8_t attack_cd;            /* ticks until the next punch */
    uint8_t fwd_latch;            /* FWD edge state for double-tap sprint */
    uint8_t dtap_timer;           /* open double-tap window (ticks) */
    uint8_t sprint;               /* 1 while sprinting (FWD held after dtap) */
} player_t;

extern player_t plr;
extern uint8_t g_autojump;
extern uint8_t tnt_flash;
extern uint8_t hurt_flash;
extern uint8_t g_died;
extern uint8_t g_hunger_drain;  /* 0 = food bar never drains (default) */
extern const uint8_t hotbar_blocks[HOTBAR_SLOTS];

#define HUNGER_MAX 20             /* 20 food points = 10 drumstick icons */

void player_init(void);
void player_tick(unsigned int in);
void player_camera(camera_t *cam);
void player_damage(int d);        /* raw damage (fall/starve): no armor */
bool player_eat_porkchop(void);   /* legacy +3-heart heal (host --spawn test) */
/* N6: armored damage — mob melee + TNT route through here so the equipped set
 * reduces the hit (helmet 15 / boots 15 / legs 25 / chest 30, capped 85%). */
void player_hurt(int d);
/* N6: summed equipped-armor damage-reduction percent (0..85). */
int  armor_pct(void);
/* N6: eat the HELD porkchop (raw +6 / cooked +16 hunger; cooked also grants
 * saturation). Returns true if one was consumed. Survival, not-full only. */
bool player_eat_held(void);
void player_respawn(void);
void do_explosion(int ex, int ey, int ez);

/* N3 leaf decay: reset the decay cursor/rng (per session, in player_init) and
 * advance the budgeted per-tick scan (called from player_tick; also driven
 * directly by the host leaf-decay test). */
void leaves_reset(void);
void leaves_decay_tick(void);

/* the effective id in held hotbar slot `sel`: the fixed palette in creative,
 * the stack's id (0 when empty) in survival */
uint8_t hotbar_id(int sel);

/* ---- slot-inventory data model (single source of truth per stack) ---- */
/* max stack for id: 1 for tools/armour, STACK_MAX otherwise */
int inv_stack_cap(uint8_t id);
/* total count of id across the hotbar + main backpack (armour excluded) */
int inv_count(uint8_t id);
/* add n of id, merging into matching stacks then empty slots, hotbar-first;
 * respects stack caps. Returns the leftover that did not fit (0 = all stored). */
int inv_add(uint8_t id, int n);
/* remove up to n of id across the backpack then hotbar; returns amount removed */
int inv_remove(uint8_t id, int n);
/* pick up n of id (drops/crafting output): inv_add wrapper that also announces
 * the first unit. Returns leftover that did not fit. */
int inv_gain(uint8_t id, int n);

#endif
