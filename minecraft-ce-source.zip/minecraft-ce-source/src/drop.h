/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef DROP_H
#define DROP_H

#include "common.h"
#include "render.h"

#define DROP_MAX 8

typedef struct {
    fix x, y, z, vy;
    uint16_t age;         /* ticks alive; despawn at DROP_TTL */
    uint8_t block;
    uint8_t alive;
    int16_t bb[4];        /* last drawn screen bbox (render coords);
                             bb[0] > bb[2] = nothing drawn */
} drop_t;

extern drop_t drops[DROP_MAX];

void drops_reset(void);
void drop_spawn(int bx, int by, int bz, uint8_t block);
void drops_tick(void);                      /* gravity + pickup, 30Hz */
void drops_draw(uint8_t *fb, const camera_t *cam);

#endif
