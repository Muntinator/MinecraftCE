; Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
; fpmath.asm — 12.12 fixed-point kernels for the eZ80.
;
; The C `long` path costs thousands of cycles per op in stack traffic, so
; the hot renderer math uses native 24-bit ints plus these two kernels.
; MLT-decomposition technique after TICraft's asmmath.asm (MIT,
; TheMiningTeamYT / Runer112), reimplemented with exact floor/truncation
; semantics so the host harness mirrors results with plain int64 C:
;
;   fp_mul(a, b) == (int24)( ((int64)a * (int64)b) >> 12 )   [floor]
;   fp_div(a, b) == (int24)( ((int64)a << 12) / b )          [trunc, b != 0]
;
; Caller guarantees |a*b| < 2^39, |fp_div result| < 2^23, b != 0.
; Not reentrant (static scratch); fine for a single-threaded game.

assume adl=1

section .bss
private prod
prod: rb 4              ; product bytes 1..4 (bits 8..39)
private outb
outb: rb 3              ; assembled 24-bit result
private dsign
dsign: rb 1

section .text
public _fp_mul
; int fp_mul(int x, int y);  x at sp+3, y at sp+6, result in HL
; X bytes: (iy+0..2) little endian; Y bytes: (iy+3..5)
; column sums of the 8x8 partials P(i,j) = Xi*Yj:
;   col1 (bits  8..15): P00.h P01.l P10.l
;   col2 (bits 16..23): P01.h P10.h P02.l P11.l P20.l
;   col3 (bits 24..31): P02.h P11.h P20.h P12.l P21.l
;   col4 (bits 32..39): P12.h P21.h P22.l
; then subtract (x<0 ? y<<24 : 0) + (y<0 ? x<<24 : 0) from bits 24..39,
; result = bits 12..35.
_fp_mul:
    ld iy, 3
    add iy, sp
    ld de, 0                ; UDE stays 0 for every 24-bit add below

    ; ---- column 1: HL = P00.h + P01.l + P10.l
    ld hl, 0
    ld d, (iy + 0)
    ld e, (iy + 3)
    mlt de                  ; P00
    ld e, d
    ld d, 0
    add hl, de              ; += P00.h
    ld d, (iy + 0)
    ld e, (iy + 4)
    mlt de                  ; P01
    ld d, 0
    add hl, de              ; += P01.l
    ld d, (iy + 1)
    ld e, (iy + 3)
    mlt de                  ; P10
    ld d, 0
    add hl, de              ; += P10.l
    ld a, l
    ld (prod + 0), a
    ld l, h                 ; carry into column 2
    ld h, 0

    ; ---- column 2: += P01.h P10.h P02.l P11.l P20.l
    ld d, (iy + 0)
    ld e, (iy + 4)
    mlt de                  ; P01
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 3)
    mlt de                  ; P10
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 0)
    ld e, (iy + 5)
    mlt de                  ; P02
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 4)
    mlt de                  ; P11
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 3)
    mlt de                  ; P20
    ld d, 0
    add hl, de
    ld a, l
    ld (prod + 1), a
    ld l, h
    ld h, 0

    ; ---- column 3: += P02.h P11.h P20.h P12.l P21.l
    ld d, (iy + 0)
    ld e, (iy + 5)
    mlt de                  ; P02
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 4)
    mlt de                  ; P11
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 3)
    mlt de                  ; P20
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 1)
    ld e, (iy + 5)
    mlt de                  ; P12
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 4)
    mlt de                  ; P21
    ld d, 0
    add hl, de
    ld a, l
    ld (prod + 2), a
    ld l, h
    ld h, 0

    ; ---- column 4: += P12.h P21.h P22.l
    ld d, (iy + 1)
    ld e, (iy + 5)
    mlt de                  ; P12
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 4)
    mlt de                  ; P21
    ld e, d
    ld d, 0
    add hl, de
    ld d, (iy + 2)
    ld e, (iy + 5)
    mlt de                  ; P22
    ld d, 0
    add hl, de
    ld a, l
    ld (prod + 3), a        ; bits 32..39 (col4 carry would be bits >= 40)

    ; ---- signed correction: bits 24..39 -= (x<0 ? Y : 0) + (y<0 ? X : 0)
    bit 7, (iy + 2)
    jr z, .x_pos
    ld a, (prod + 2)
    sub a, (iy + 3)
    ld (prod + 2), a
    ld a, (prod + 3)
    sbc a, (iy + 4)
    ld (prod + 3), a
.x_pos:
    bit 7, (iy + 5)
    jr z, .y_pos
    ld a, (prod + 2)
    sub a, (iy + 0)
    ld (prod + 2), a
    ld a, (prod + 3)
    sbc a, (iy + 1)
    ld (prod + 3), a
.y_pos:

    ; ---- extract bits 12..35: out[k] = (prod[k] >> 4) | (prod[k+1] << 4)
    ld a, (prod + 0)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld b, a
    ld a, (prod + 1)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, b
    ld (outb + 0), a

    ld a, (prod + 1)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld b, a
    ld a, (prod + 2)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, b
    ld (outb + 1), a

    ld a, (prod + 2)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld b, a
    ld a, (prod + 3)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, b
    ld (outb + 2), a

    ld hl, (outb)
    ret

section .text
public _fp_div
; int fp_div(int a, int b);  result = trunc((a << 12) / b), b != 0.
; Magnitude restoring division: R = |a| >> 12 (top 12 bits; quotient bits
; there are all 0 because |result| < 2^23), stream S = (|a| & 0xFFF) << 12,
; 24 iterations produce the 24 quotient bits, collected in S's vacated
; low end (rolling window), then sign is applied.
_fp_div:
    ld iy, 3
    add iy, sp

    ; dsign = sign(a) ^ sign(b)
    ld a, (iy + 2)
    xor a, (iy + 5)
    ld (dsign), a

    ; HL = |a|
    ld hl, (iy + 0)
    bit 7, (iy + 2)
    jr z, .a_pos
    ex de, hl
    or a, a
    sbc hl, hl
    sbc hl, de
.a_pos:
    ; stash |a| bytes for nibble craft
    ld (outb), hl           ; reuse outb as |a| scratch
    ; BC = |b|
    ld bc, (iy + 3)
    bit 7, (iy + 5)
    jr z, .b_pos
    or a, a
    sbc hl, hl
    sbc hl, bc
    push hl
    pop bc
.b_pos:

    ; R (HL) = |a| >> 12 = (a2 << 4) | (a1 >> 4)
    ld hl, 0
    ld a, (outb + 1)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld d, a                 ; keep low nibble of a1>>4 contribution
    ld a, (outb + 2)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, d
    ld l, a                 ; bits 0..7 of R
    ld a, (outb + 2)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld h, a                 ; bits 8..11 of R  (UHL = 0 from ld hl,0)

    ; S (DE) = (|a| & 0xFFF) << 12: e = 0? bytes:
    ;   S byte0 = 0? No: S = value << 12: bit12 = a bit0:
    ;   s0 = 0, s1 = (a0 << 4), s2 = (a1 & 0x0F) << 4 | (a0 >> 4)
    ld de, 0
    ld a, (outb + 0)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    ld d, a                 ; s1 = a0 << 4  -> D is byte1
    ld a, (outb + 0)
    rrca
    rrca
    rrca
    rrca
    and a, 0Fh
    ld e, a                 ; temp: a0 >> 4
    ld a, (outb + 1)
    rlca
    rlca
    rlca
    rlca
    and a, 0F0h
    or a, e                 ; s2 = (a1 & 0xF) << 4 | (a0 >> 4)
    ; assemble S in DE: byte0 = 0, byte1 = D(s1), byte2 = A(s2)
    ld (outb + 0), a        ; stash s2
    ld a, d
    ld (prod + 0), a        ; stash s1
    ld de, 0
    ld a, (prod + 0)
    ld d, a                 ; DE = s1 << 8  (byte1 = s1)
    ; set top byte via hl-free path: rotate: DE currently 00:s1:00
    ; we need s2:s1:00 -> load through scratch 24-bit:
    ld a, (outb + 0)
    ld (prod + 1), a
    xor a, a
    ld (prod + 2), a        ; unused high pad
    ; prod-1 trick is fragile; assemble directly instead:
    ; write bytes [0]=0 [1]=s1 [2]=s2 into outb, then ld de,(outb)
    xor a, a
    ld (outb + 0), a
    ld a, (prod + 0)
    ld (outb + 1), a
    ld a, (prod + 1)
    ld (outb + 2), a
    ld de, (outb)           ; S ready

    ; 24 restoring iterations; carry = previous quotient bit (starts 0)
    ld iyl, 24
    or a, a                 ; clear carry
.loop:
    ex de, hl
    adc hl, hl              ; S = S<<1 | qprev; carry out = stream bit
    ex de, hl
    adc hl, hl              ; R = R<<1 | streambit (never overflows 24)
    or a, a
    sbc hl, bc              ; R -= |b|
    jr nc, .q1
    add hl, bc              ; restore; carry := 0 for next iteration
    or a, a
    jr .next
.q1:
    scf                     ; quotient bit 1
.next:
    dec iyl
    jr nz, .loop
    ; inject the final quotient bit
    ex de, hl
    adc hl, hl              ; S <<= 1 | last qbit; S = quotient
    ; HL now holds the quotient (was S)
    ld a, (dsign)
    or a, a
    jp p, .done
    ex de, hl
    or a, a
    sbc hl, hl
    sbc hl, de
.done:
    ret
