/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * compose.c — dirty-rect frame compositor (see compose.h). Shared by
 * the calc shell and the host harness so the host can prove composed
 * frames byte-identical to full renders.
 *
 * Dirty path per frame, camera unchanged:
 *   1. collect restore rects: every entity's last drawn bbox, the last
 *      target outline, edited chunks' screen rects, caller overlays
 *   2. re-render the world inside each rect (scissored)
 *   3. redraw all entities + outline (recording their new bboxes)
 *   4. present old rects + new bboxes (scaled modes upscale to fb)
 * Anything that breaks the "fb holds last frame" premise (menus, mode
 * or radius changes, world load) must call compose_invalidate().
 */

#include <string.h>

#include "compose.h"
#include "mesh.h"
#include "mob.h"
#include "drop.h"
#include "light.h"
#include "player.h"

#define CR_MAX 24

typedef struct { int16_t x0, y0, x1, y1; } crect_t;

static crect_t rects[CR_MAX];
static uint8_t rect_n;
static uint8_t rect_ovf;

static crect_t extra[4];         /* caller overlay rects, full-res */
static uint8_t extra_n;

/* world-edit cells this frame (from player.c). Small edits redraw a
 * tight 3x3x3 rect; overflow (explosions) falls back to the edited
 * chunks' rects via mesh_events. */
#define CB_MAX 6
static int8_t cells[CB_MAX][3];
static uint8_t cell_n;
static uint8_t cell_ovf;

uint16_t compose_stat_full, compose_stat_dirty;   /* frame counters */

static camera_t pcam;
static uint8_t frame_ok;         /* fb + entity bboxes describe a frame */
static int16_t out_bb[4];        /* last outline bbox, render coords */
static uint8_t out_ok;

static void rect_push(int x0, int y0, int x1, int y1)
{
    if (x0 >= x1 || y0 >= y1)
        return;
    if (rect_n >= CR_MAX) {
        rect_ovf = 1;
        return;
    }
    rects[rect_n].x0 = (int16_t)x0;
    rects[rect_n].y0 = (int16_t)y0;
    rects[rect_n].x1 = (int16_t)x1;
    rects[rect_n].y1 = (int16_t)y1;
    rect_n++;
}

void compose_invalidate(void)
{
    frame_ok = 0;
}

void compose_add_block(int x, int y, int z)
{
    if (cell_n < CB_MAX) {
        cells[cell_n][0] = (int8_t)x;
        cells[cell_n][1] = (int8_t)y;
        cells[cell_n][2] = (int8_t)z;
        cell_n++;
    } else {
        cell_ovf = 1;
    }
}

void compose_add_rect(int x0, int y0, int x1, int y1)
{
    if (extra_n < 4) {
        extra[extra_n].x0 = (int16_t)x0;
        extra[extra_n].y0 = (int16_t)y0;
        extra[extra_n].x1 = (int16_t)x1;
        extra[extra_n].y1 = (int16_t)y1;
        extra_n++;
    } else {
        frame_ok = 0;            /* too many overlays: just full-render */
    }
}

/* draw entities + outline; their new bboxes land in mob/drop bb and
 * out_bb via the render bbox accumulator */
static void draw_dynamic(uint8_t *fb, const camera_t *cam)
{
    torches_draw(fb, cam);      /* N5: static light-boxes, over the world like
                                   drops/mobs (no bb restore — they never move;
                                   a place/break repaints via its block rect) */
    mobs_draw(fb, cam);
    drops_draw(fb, cam);
    out_ok = 0;
    if (plr.hit_x >= 0) {
        render_bbox_reset();
        render_face_outline(fb, plr.hit_x, plr.hit_y, plr.hit_z,
                            plr.face);
        if (rbb_x0 <= rbb_x1) {
            out_bb[0] = (int16_t)rbb_x0;
            out_bb[1] = (int16_t)rbb_y0;
            out_bb[2] = (int16_t)rbb_x1;
            out_bb[3] = (int16_t)rbb_y1;
            out_ok = 1;
        }
    }
}

void compose_frame(uint8_t *fb, const camera_t *cam)
{
    int wox, woy, sc;
    render_window_info(&wox, &woy, &sc);
    uint8_t full = !frame_ok ||
                   pcam.x != cam->x || pcam.y != cam->y ||
                   pcam.z != cam->z || pcam.yaw != cam->yaw ||
                   pcam.pitch != cam->pitch;

    rect_n = 0;
    rect_ovf = 0;

    if (!full) {
        /* restore rects: previous entity/outline positions */
        for (int i = 0; i < MOB_MAX; i++)
            if (mobs[i].bb[0] <= mobs[i].bb[2])
                rect_push(mobs[i].bb[0], mobs[i].bb[1],
                          mobs[i].bb[2], mobs[i].bb[3]);
        for (int i = 0; i < DROP_MAX; i++)
            if (drops[i].bb[0] <= drops[i].bb[2])
                rect_push(drops[i].bb[0], drops[i].bb[1],
                          drops[i].bb[2], drops[i].bb[3]);
        if (out_ok)
            rect_push(out_bb[0], out_bb[1], out_bb[2], out_bb[3]);
        /* caller overlays (full-res -> render coords, rounded out) */
        for (int i = 0; i < extra_n; i++)
            rect_push((extra[i].x0 - wox) / sc, (extra[i].y0 - woy) / sc,
                      (extra[i].x1 - wox + sc - 1) / sc,
                      (extra[i].y1 - woy + sc - 1) / sc);
        /* block edits: tight per-cell rects when we know the cells,
         * otherwise (overflow / untracked edits) whole-chunk rects */
        if (!cell_ovf && cell_n) {
            for (int i = 0; i < cell_n; i++) {
                int x0, y0, x1, y1;
                if (!render_block_rect(cam, cells[i][0], cells[i][1],
                                       cells[i][2], &x0, &y0, &x1, &y1)) {
                    full = 1;
                    break;
                }
                rect_push(x0, y0, x1, y1);
            }
        } else if (mesh_events) {
            uint16_t ev = mesh_events;
            for (int ci = 0; ev && ci < NCHUNKS; ci++, ev >>= 1) {
                if (!(ev & 1))
                    continue;
                int x0, y0, x1, y1;
                if (!render_chunk_rect(cam, ci, &x0, &y0, &x1, &y1)) {
                    full = 1;    /* chunk crosses the frustum */
                    break;
                }
                rect_push(x0, y0, x1, y1);
            }
        }
        if (rect_ovf)
            full = 1;
    }
    mesh_events = 0;
    extra_n = 0;
    cell_n = 0;
    cell_ovf = 0;

    if (full) {
        compose_stat_full++;
        render_frame(fb, cam);
        draw_dynamic(fb, cam);
        render_present(fb);
    } else {
        compose_stat_dirty++;
        /* one union rect: the per-quad geometry (the measured wall) is
         * paid once, not once per rect */
        int ux0 = 32767, uy0 = 32767, ux1 = -32767, uy1 = -32767;
        for (int i = 0; i < rect_n; i++) {
            if (rects[i].x0 < ux0) ux0 = rects[i].x0;
            if (rects[i].y0 < uy0) uy0 = rects[i].y0;
            if (rects[i].x1 > ux1) ux1 = rects[i].x1;
            if (rects[i].y1 > uy1) uy1 = rects[i].y1;
        }
        if (rect_n)
            render_frame_rect(fb, cam, ux0, uy0, ux1, uy1);
        render_frame_rect(fb, cam, 0, 0, 0, 0);   /* open scissor state:
            zero-size render just sets target + camera globals */
        draw_dynamic(fb, cam);
        /* present: everything restored or newly drawn */
        if (rect_n)
            render_present_rect(fb, ux0, uy0, ux1, uy1);
        for (int i = 0; i < MOB_MAX; i++)
            if (mobs[i].bb[0] <= mobs[i].bb[2])
                render_present_rect(fb, mobs[i].bb[0], mobs[i].bb[1],
                                    mobs[i].bb[2], mobs[i].bb[3]);
        for (int i = 0; i < DROP_MAX; i++)
            if (drops[i].bb[0] <= drops[i].bb[2])
                render_present_rect(fb, drops[i].bb[0], drops[i].bb[1],
                                    drops[i].bb[2], drops[i].bb[3]);
        if (out_ok)
            render_present_rect(fb, out_bb[0], out_bb[1],
                                out_bb[2], out_bb[3]);
    }

    pcam = *cam;
    frame_ok = 1;
}
