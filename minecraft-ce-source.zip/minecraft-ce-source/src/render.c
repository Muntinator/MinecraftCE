/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * render.c — M2 grid-aware renderer over chunk meshes.
 *
 * Draw order is an exact painter realized as a fixed-hierarchy BSP
 * traversal (chunkX -> chunkZ -> y -> z -> x); see notes/plan.md for the
 * proof and for why the spec's bucket-sequential order was wrong. At every
 * level the split-axis order is "far half ascending, then near half
 * descending", and each element is [content, then its camera-side plane].
 * Mesh quads never straddle a split of an earlier axis (mesh.c enforces
 * the merge constraints), so zero per-frame sorting is needed.
 *
 * Per-frame vertex work is cut by a 256-entry direct-mapped cache of
 * world->view transforms keyed by lattice point.
 */

#include <string.h>

#include "render.h"
#include "world.h"
#include "mesh.h"
#include "palette.h"
#include "textures.h"
#include "lut.h"

uint16_t rstat_faces;

#ifndef __ez80__
uint32_t hstat_edge_px, hstat_span_px, hstat_edge_calls;
#define EDGE_PX() (hstat_edge_px++)
#define SPAN_PX(n) (hstat_span_px += (uint32_t)(n))
#define EDGE_CALL() (hstat_edge_calls++)

/* vertex-cache instrumentation (Stage B, host only). Reset per frame by
 * the harness (render_vcstat_reset) before render_frame; read after. */
uint32_t hvc_look, hvc_hit;             /* xform_cached lookups / hits */
uint32_t hpc_look, hpc_php, hpc_pvc;    /* project_corner: proj-hit /
                                         * xform-hit-needs-project */
uint32_t hvc_unique;                    /* distinct lattice corners hit */
#define VC_SEEN_N 65536                 /* VC_KEY max ~51232 < this: exact */
static uint8_t hvc_seen[VC_SEEN_N];
static void vc_touch(uint32_t key)
{
    if (!hvc_seen[key & (VC_SEEN_N - 1)]) {
        hvc_seen[key & (VC_SEEN_N - 1)] = 1;
        hvc_unique++;
    }
}
void render_vcstat_reset(void)
{
    hvc_look = hvc_hit = hpc_look = hpc_php = hpc_pvc = hvc_unique = 0;
    memset(hvc_seen, 0, sizeof hvc_seen);
}
#define VC_LOOK()   (hvc_look++)
#define VC_HIT()    (hvc_hit++)
#define VC_TOUCH(k) vc_touch((uint32_t)(k))
#define PC_LOOK()   (hpc_look++)
#define PC_PHIT()   (hpc_php++)
#define PC_VHIT()   (hpc_pvc++)
#else
#define EDGE_PX()
#define SPAN_PX(n)
#define EDGE_CALL()
#define VC_LOOK()
#define VC_HIT()
#define VC_TOUCH(k)
#define PC_LOOK()
#define PC_PHIT()
#define PC_VHIT()
#endif

#define NEAR_Z 1024              /* 0.25 block */
#define FOCAL  160               /* px; ~90 deg horizontal FOV */

/* 3D viewport: rows 0..view_h-1; rows below are the HUD (drawn by the
 * shell, never touched here). 168 in game, 240 for the title vista. */
uint8_t view_h = 240;   /* full-screen; HUD overlays */
#ifndef TEXTURES_DEFAULT
#define TEXTURES_DEFAULT 1
#endif
#ifndef GFXMODE_DEFAULT
#define GFXMODE_DEFAULT 0
#endif
uint8_t g_textures = TEXTURES_DEFAULT;
uint8_t g_gfxmode = GFXMODE_DEFAULT;
#ifndef VIEWPORT_DEFAULT
#define VIEWPORT_DEFAULT 0
#endif
uint8_t g_viewport = VIEWPORT_DEFAULT;  /* 0 full, 1 160x120, 2 80x60 */
uint8_t g_night_sky;                    /* set by the shell at night: sprinkle
                                           stars over the (darkened) gradient */

/* M25 vertical sky ramp: row 0 (zenith) = deepest, row rh (horizon) =
 * PAL_SKY. Four shades (255/191/127/63) with a 1-row dither near each seam
 * so the bands blend; still one solid color per row (a memset, ~free). The
 * result is a pure function of the render-target row -> scissor-independent,
 * so the compositor's scissored sky fill is byte-identical (compose proves it). */
static uint8_t sky_row_idx(int y, int rh)
{
    static const uint8_t shade[7] = {   /* zenith(deep) .. horizon(light) */
        SHADE_IDX(PAL_BLACK, 3), SHADE_IDX(PAL_BLACK, 2), SHADE_IDX(PAL_BLACK, 1),
        SHADE_IDX(PAL_SKY, 3),   SHADE_IDX(PAL_SKY, 2),   SHADE_IDX(PAL_SKY, 1),
        PAL_SKY,
    };
    int d = y * 7 / rh;                 /* 0..6, top -> bottom (y < rh) */
    return shade[d > 6 ? 6 : d];
}

/* called during rendering (per chunk) so the shell can poll the keypad
 * mid-frame; taps shorter than a frame would otherwise be lost */
void (*render_poll)(void);

/* Scaled rendering: Quality draws straight into the framebuffer;
 * Fast/Ultra draw a 160x120 / 80x60 frame into scaled_buf with the SAME
 * field of view (focal length and center scale together), and
 * render_present() expands it 2x2 / 4x4 to the screen. World-space
 * drawing (chunks, mobs, drops, target outline) all lands in rt; the
 * HUD is drawn full-res after present so text stays crisp. */
uint8_t render_scratch[(SCREEN_W / 2) * (SCREEN_H / 2)];
#define scaled_buf render_scratch
static uint8_t *rt;             /* current render target */
static uint8_t rscale = 1;      /* 1, 2, 4 */
static int rw, rh;              /* render target dims */
int rcx, rcy;                   /* projection center (exposed for project.asm) */
int rfocal;                     /* scaled focal length (exposed for project.asm) */
static int winw = SCREEN_W, winh = SCREEN_H;  /* viewport window */
static int wox, woy;            /* window origin on screen */

/* scissor rect in render coords, [scx0,scx1) x [scy0,scy1); world
 * rasterization never writes outside it. Full frame per render_frame. */
static int scx0, scy0, scx1, scy1;

/* drawn-bbox accumulator (render coords): entity draws (render_box,
 * render_face_outline) grow it so the compositor learns their rects */
int rbb_x0, rbb_y0, rbb_x1, rbb_y1;

void render_bbox_reset(void)
{
    rbb_x0 = rbb_y0 = 32767;
    rbb_x1 = rbb_y1 = -32767;
}

static void rbb_add(int x0, int y0, int x1, int y1)
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > rw) x1 = rw;
    if (y1 > rh) y1 = rh;
    if (x0 >= x1 || y0 >= y1)
        return;
    if (x0 < rbb_x0) rbb_x0 = x0;
    if (y0 < rbb_y0) rbb_y0 = y0;
    if (x1 > rbb_x1) rbb_x1 = x1;
    if (y1 > rbb_y1) rbb_y1 = y1;
}

/* view distance: chunks whose center is farther than this many blocks
 * (Chebyshev, xz) from the camera are skipped entirely. Runtime-adjustable
 * (+/- keys in-game); VIEW_RADIUS_DEFAULT overridable for perf sweeps. */
#ifndef VIEW_RADIUS_DEFAULT
#define VIEW_RADIUS_DEFAULT 10
#endif
uint8_t view_radius = VIEW_RADIUS_DEFAULT;

/* quads whose screen bbox is at most this wide/tall skip the T-junction
 * edge pass (seams that small are invisible) */
#define EDGE_SKIP_BBOX 10

/* per-frame camera basis + position, exported as one struct (see render.h)
 * so the eZ80 asm transform reads the fields at fixed offsets. */
rcam_t rcam;
static uint8_t g_noclip;   /* current chunk fully inside all planes */

/* cave culling (Stage A): g_cull_caves is set once per frame when the
 * camera is at/above the gen-time terrain line; g_skip_cave is set per
 * chunk (cull enabled AND chunk > 6 blocks away) and read by draw_quad to
 * drop faces flagged cave (bit 7 of q->block). g_cave_cull_off is a test
 * hook that force-disables the whole thing (harness --cavecull). */
static uint8_t g_cull_caves;
static uint8_t g_skip_cave;
uint8_t g_cave_cull_off;

typedef struct { fix x, y, z; } v3;

#ifdef __ez80__
/* Hand-written eZ80 vertex transform (src/xform.asm): computes EXACTLY the
 * same 12.12 exact-floor math as the C transform() below, reading the camera
 * basis from _rcam at fixed byte offsets. The asm assumes rcam_t / v3 are
 * byte-packed 24-bit fields — assert it so a toolchain layout change can
 * never silently corrupt the offsets. */
_Static_assert(sizeof(rcam_t) == 21, "rcam_t must be 7 packed 24-bit fix");
_Static_assert(sizeof(v3) == 9, "v3 must be 3 packed 24-bit fix");
void xform_asm(int wx, int wy, int wz, v3 *out);

static void transform(int wx, int wy, int wz, v3 *out)
{
    xform_asm(wx, wy, wz, out);
}
#else
static void transform(int wx, int wy, int wz, v3 *out)
{
    fix dx = INT_TO_FIX(wx) - rcam.cx;
    fix dy = INT_TO_FIX(wy) - rcam.cyy;
    fix dz = INT_TO_FIX(wz) - rcam.cz;
    fix t;
    out->x = FMUL(dx, rcam.cy) - FMUL(dz, rcam.sy);
    t      = FMUL(dx, rcam.sy) + FMUL(dz, rcam.cy);
    out->z = FMUL(t, rcam.cp) + FMUL(dy, rcam.sp);
    out->y = FMUL(dy, rcam.cp) - FMUL(t, rcam.sp);
}
#endif

/* ---- projected-vertex (transform) cache ---- */

#ifndef VC_N
#define VC_N    256              /* Stage B: 128->256 (bss +2.4KB, fits) —
                                  * holds a chunk's live corner working set,
                                  * cutting collision evictions */
#endif
#define VC_MASK (VC_N - 1)
static fix vckey[VC_N];                  /* transform-valid tag */
static fix vcx[VC_N], vcy[VC_N], vcz[VC_N];
static fix vpkey[VC_N];                  /* projection-valid tag */
static int16_t vppx[VC_N], vppy[VC_N];

#define VC_KEY(wx, wy, wz) ((fix)(wx) | ((fix)(wz) << 6) | ((fix)(wy) << 12))

/* index hash (Stage B sweep). VC_HASH selects a variant; all are pure
 * shift/xor so the eZ80 path stays libcall-free. Corners cluster in 8x8
 * chunk runs, so the hash must spread nearby (wx,wz) and separate y-layers.
 * VC_HASH 0 = original. */
#ifndef VC_HASH
#define VC_HASH 3                /* Stage B sweep winner (see notes) */
#endif
#if VC_HASH == 0
#define VC_IDX(wx, wy, wz) \
    (((wx) ^ ((wz) << 3) ^ ((wy) << 1) ^ ((wy) << 6)) & VC_MASK)
#elif VC_HASH == 1
/* wx low, wz mid, wy high — pack the three fields into disjoint bit runs
 * (fits 256: 3+3+ y spread), spread wy across the top bits */
#define VC_IDX(wx, wy, wz) \
    (((wx) ^ ((wz) << 3) ^ ((wy) << 6) ^ ((wy) << 3)) & VC_MASK)
#elif VC_HASH == 2
/* give wz its own high run so an 8x8 patch never aliases across the mask,
 * y broken up into two runs to decorrelate layers */
#define VC_IDX(wx, wy, wz) \
    (((wx) ^ ((wz) << 4) ^ ((wy) << 1) ^ ((wy) << 5) ^ ((wz) << 1)) & VC_MASK)
#elif VC_HASH == 3
/* additive fold with small odd multipliers (still shift/add on eZ80) */
#define VC_IDX(wx, wy, wz) \
    (((wx) + ((wz) << 3) + ((wz) << 1) + ((wy) << 6) + ((wy) << 2)) & VC_MASK)
#elif VC_HASH == 4
/* 256-tuned: wx bits0-2, wz bits3-5, wy folded into bits6-7 + xor low */
#define VC_IDX(wx, wy, wz) \
    (((wx) ^ ((wz) << 3) ^ ((wy) << 6) ^ ((wy) << 1) ^ ((wz) << 6)) & VC_MASK)
#endif

static void xform_cached(int wx, int wy, int wz, v3 *out)
{
    fix key = VC_KEY(wx, wy, wz);
    int idx = VC_IDX(wx, wy, wz);
    VC_LOOK();
    VC_TOUCH(key);
    if (vckey[idx] == key) {
        VC_HIT();
        out->x = vcx[idx];
        out->y = vcy[idx];
        out->z = vcz[idx];
        return;
    }
    transform(wx, wy, wz, out);
    vckey[idx] = key;
    vpkey[idx] = -1;
    vcx[idx] = out->x;
    vcy[idx] = out->y;
    vcz[idx] = out->z;
}

/* Fused perspective-divide + project of one view-space vertex. The eZ80
 * uses the hand-written asm kernel (src/project.asm); the host keeps the C,
 * which is the bit-identical reference the goldens/FPTEST pin. Both compute:
 *   recip = FDIV(rfocal<<6, v->z); *sx = rcx + (FMUL(v->x,recip)>>6);
 *                                  *sy = rcy - (FMUL(v->y,recip)>>6); */
#ifdef __ez80__
void project_asm(const v3 *v, int *sx, int *sy);
#define PROJECT_PT(vp, sxp, syp) project_asm((vp), (sxp), (syp))
#else
static inline void project_pt_c(const v3 *v, int *sx, int *sy)
{
    fix recip = FDIV(rfocal << 6, v->z);
    *sx = rcx + (FMUL(v->x, recip) >> 6);
    *sy = rcy - (FMUL(v->y, recip) >> 6);
}
#define PROJECT_PT(vp, sxp, syp) project_pt_c((vp), (sxp), (syp))
#endif

/* transform + project one lattice corner with full caching; only valid on
 * the no-clip path (vz is guaranteed comfortably inside the near plane) */
static void project_corner(int wx, int wy, int wz, int *sx, int *sy)
{
    fix key = VC_KEY(wx, wy, wz);
    int idx = VC_IDX(wx, wy, wz);
    PC_LOOK();
    VC_TOUCH(key);
    if (vpkey[idx] == key) {
        PC_PHIT();
        *sx = vppx[idx];
        *sy = vppy[idx];
        return;
    }
    v3 v;
    if (vckey[idx] == key) {
        PC_VHIT();
        v.x = vcx[idx];
        v.y = vcy[idx];
        v.z = vcz[idx];
    } else {
        transform(wx, wy, wz, &v);
        vckey[idx] = key;
        vcx[idx] = v.x;
        vcy[idx] = v.y;
        vcz[idx] = v.z;
    }
    int px, py;
    PROJECT_PT(&v, &px, &py);
    vpkey[idx] = key;
    vppx[idx] = (int16_t)px;
    vppy[idx] = (int16_t)py;
    *sx = px;
    *sy = py;
}

/* ---- clip + project + fill (unchanged from M1) ---- */

static fix plane_eval(int plane, const v3 *v)
{
    fix w;
    switch (plane) {
    case 0:  return v->z - NEAR_Z;
    case 1:  w = v->z + (v->z >> 4); return w - v->x;   /* 1.0625 z */
    case 2:  w = v->z + (v->z >> 4); return w + v->x;
    case 3:  w = (v->z >> 1) + (v->z >> 2) + (v->z >> 4);
             return w - v->y;                    /* 0.8125 z, 240 rows */
    default: w = (v->z >> 1) + (v->z >> 2) + (v->z >> 4);
             return w + v->y;
    }
}

/* all five plane tests in straight-line code (plane_eval is kept for the
 * rare clip path; calling it 20x per quad dominated the geometry stage).
 * Calc: hand-written asm (src/xform.asm), identical exact-shift math,
 * validated bit-for-bit by the FPTEST vectors; serves every call site
 * including cache-hit vectors and mob faces. */
#ifdef __ez80__
uint8_t outcode5_asm(const v3 *v);
#define outcode5 outcode5_asm
#else
static uint8_t outcode5(const v3 *v)
{
    uint8_t c = 0;
    fix z = v->z;
    fix wside = z + (z >> 4);
    fix wvert = (z >> 1) + (z >> 2) + (z >> 4);
    if (z - NEAR_Z < 0)      c |= 1;
    if (wside - v->x < 0)    c |= 2;
    if (wside + v->x < 0)    c |= 4;
    if (wvert - v->y < 0)    c |= 8;
    if (wvert + v->y < 0)    c |= 16;
    return c;
}
#endif

static int clip_plane(const v3 *in, const fix *iu, const fix *iv, int n,
                      v3 *out, fix *ou, fix *ov, int plane)
{
    int m = 0;
    fix fa = plane_eval(plane, &in[n - 1]);
    int a = n - 1;
    for (int b = 0; b < n; b++) {
        fix fb = plane_eval(plane, &in[b]);
        if ((fa < 0) != (fb < 0)) {
            fix afa = fa < 0 ? -fa : fa;
            fix afb = fb < 0 ? -fb : fb;
            fix t = FDIV(afa, afa + afb);        /* 0..4096 */
            out[m].x = in[a].x + FMUL(in[b].x - in[a].x, t);
            out[m].y = in[a].y + FMUL(in[b].y - in[a].y, t);
            out[m].z = in[a].z + FMUL(in[b].z - in[a].z, t);
            ou[m] = iu[a] + FMUL(iu[b] - iu[a], t);
            ov[m] = iv[a] + FMUL(iv[b] - iv[a], t);
            m++;
        }
        if (fb >= 0) {
            ou[m] = iu[b];
            ov[m] = iv[b];
            out[m++] = in[b];
        }
        fa = fb;
        a = b;
    }
    return m;
}

/* uv units: 1 texel = 1<<7; one block edge = 16 texels = 2048 units.
 * Affine map u(x,y) = uo + ua*x + ub*y (same for v) is solved per quad
 * from three projected corners; spans just step ua/va per pixel. */
typedef struct {
    fix32 uo, vo;               /* origin terms can exceed 24 bits */
    fix ua, ub, va, vb;
    const uint8_t *tex;
    uint8_t bank;
} texmap_t;

#ifdef __ez80__
/* asm inner loop (src/raster.asm) sampling a 256-aligned texture page */
void span_tex_asm(uint8_t *dst, int count, fix u, fix v,
                  fix du, fix dv, int bank);
static uint8_t tpage_raw[512];
uint8_t *tpage_ptr;                       /* read by raster.asm */
static const uint8_t *tpage_from;

/* load tex into the 256-aligned page at tpage_ptr (cached; push3 HAND's
 * hand.asm samples the held cube's top tile from it too) */
void render_tpage(const uint8_t *tex)
{
    if (tpage_from != tex) {
        if (!tpage_ptr)
            tpage_ptr = (uint8_t *)(((unsigned int)tpage_raw + 255)
                                    & ~255u);
        memcpy(tpage_ptr, tex, 256);
        tpage_from = tex;
    }
}

static void span_tex(uint8_t *row, int xl, int xr, fix u, fix v,
                     fix du, fix dv, const uint8_t *tex, uint8_t bank)
{
    render_tpage(tex);
    uint8_t *p = row + xl;
    int n = xr - xl;
    while (n > 0) {
        int c = n > 255 ? 255 : n;
        span_tex_asm(p, c, u, v, du, dv, bank);
        p += c;
        u += du * c;
        v += dv * c;
        n -= c;
    }
}
#else
static void span_tex(uint8_t *row, int xl, int xr, fix u, fix v,
                     fix du, fix dv, const uint8_t *tex, uint8_t bank)
{
    uint8_t *p = row + xl;
    for (int i = xr - xl; i > 0; i--) {
        *p++ = (uint8_t)(tex[(((v >> 8) & 15) << 4) | ((u >> 8) & 15)]
                         | bank);
        u += du;
        v += dv;
    }
}
#endif

/* solve the affine coefficients from 3 screen points with known uv;
 * returns 0 on a degenerate (collinear) projection */
static int texmap_solve(texmap_t *m, const int *px, const int *py,
                        const fix *au, const fix *av)
{
    fix32 x0 = px[0], y0 = py[0];
    fix32 e1x = px[1] - x0, e1y = py[1] - y0;
    fix32 e2x = px[2] - x0, e2y = py[2] - y0;
    fix32 det = e1x * e2y - e2x * e1y;
    if (det == 0)
        return 0;
    fix32 du1 = au[1] - au[0], du2 = au[2] - au[0];
    fix32 dv1 = av[1] - av[0], dv2 = av[2] - av[0];
    /* clamp in int32 BEFORE narrowing to fix (24-bit on the calc):
     * wrapping first made host/calc disagree on the reject */
    fix32 ua = (du1 * e2y - du2 * e1y) / det;
    fix32 ub = (du2 * e1x - du1 * e2x) / det;
    fix32 va = (dv1 * e2y - dv2 * e1y) / det;
    fix32 vb = (dv2 * e1x - dv1 * e2x) / det;
    if (ua > 30000 || ua < -30000 || ub > 30000 || ub < -30000 ||
        va > 30000 || va < -30000 || vb > 30000 || vb < -30000)
        return 0;                       /* degenerate: flat fill instead */
    m->ua = (fix)ua;
    m->ub = (fix)ub;
    m->va = (fix)va;
    m->vb = (fix)vb;
    m->uo = au[0] - (fix32)m->ua * x0 - (fix32)m->ub * y0;
    m->vo = av[0] - (fix32)m->va * x0 - (fix32)m->vb * y0;
    return 1;
}

/* span with 1px outward rounding: floor(left)..ceil(right). Adjacent quads
 * whose shared world edge rounds differently then overlap instead of
 * cracking; painter order makes the overdraw invisible. */
static void span(uint8_t *row, fix ax, fix bx, uint8_t color)
{
    fix lo = ax, hi = bx;
    if (lo > hi) { fix t = lo; lo = hi; hi = t; }
    int xl = (int)(lo >> 8);
    int xr = (int)((hi + 255) >> 8);
    if (xl < scx0) xl = scx0;
    if (xr > scx1) xr = scx1;
    if (xl < xr) {
        SPAN_PX(xr - xl);
        memset(row + xl, color, (size_t)(xr - xl));
    }
}

static void fill_poly(uint8_t *fb, const int *px, const int *py, int n,
                      uint8_t color, const texmap_t *tm)
{
    int ymin = py[0], ymax = py[0], itop = 0;
    for (int i = 1; i < n; i++) {
        if (py[i] < ymin) { ymin = py[i]; itop = i; }
        if (py[i] > ymax) ymax = py[i];
    }
    if (ymin == ymax || ymax < scy0 || ymin >= scy1)
        return;

    fix ax = 0, adx = 0, bx = 0, bdx = 0;
    int aend = ymin, bend = ymin;
    int ai = itop, bi = itop;

    int ystop = ymax < scy1 ? ymax : scy1;
    uint8_t *row = fb + (ymin > scy0 ? ymin : scy0) * rw;

    /* the per-scanline walker advance (identical in both fill variants);
     * the RETURN on a downward edge bails the whole void fill */
#define FILL_ADVANCE                                                     \
        while (aend <= y) {                                             \
            int j = ai + 1 == n ? 0 : ai + 1;                          \
            while (py[j] == py[ai]) { ai = j; j = ai + 1 == n ? 0 : ai + 1; } \
            if (py[j] < py[ai]) return;                                \
            ax = (fix)px[ai] << 8;                                     \
            adx = (((fix)(px[j] - px[ai])) << 8) / (py[j] - py[ai]);   \
            aend = py[j]; ai = j;                                      \
        }                                                              \
        while (bend <= y) {                                            \
            int j = bi == 0 ? n - 1 : bi - 1;                         \
            while (py[j] == py[bi]) { bi = j; j = bi == 0 ? n - 1 : bi - 1; } \
            if (py[j] < py[bi]) return;                                \
            bx = (fix)px[bi] << 8;                                     \
            bdx = (((fix)(px[j] - px[bi])) << 8) / (py[j] - py[bi]);   \
            bend = py[j]; bi = j;                                      \
        }

    if (tm) {
        /* textured: hoist the loop-invariant map fields into locals so the
         * per-scanline span_tex setup reads registers, not tm-> memory */
        const fix32 ua = tm->ua, va = tm->va, ub = tm->ub, vb = tm->vb;
        const uint8_t *tex = tm->tex;
        const uint8_t bank = tm->bank;
        int y0r = ymin > scy0 ? ymin : scy0;
        fix32 urow = tm->uo + ub * y0r;
        fix32 vrow = tm->vo + vb * y0r;
        for (int y = ymin; y < ystop; y++) {
            FILL_ADVANCE
            if (y >= scy0) {
                fix lo = ax, hi = bx;
                if (lo > hi) { fix t = lo; lo = hi; hi = t; }
                int xl = (int)(lo >> 8);
                int xr = (int)((hi + 255) >> 8);
                if (xl < scx0) xl = scx0;
                if (xr > scx1) xr = scx1;
                if (xl < xr)
                    span_tex(row, xl, xr, (fix)(urow + ua * xl),
                             (fix)(vrow + va * xl), ua, va, tex, bank);
                urow += ub;
                vrow += vb;
                row += rw;
            }
            ax += adx;
            bx += bdx;
        }
    } else {
        for (int y = ymin; y < ystop; y++) {
            FILL_ADVANCE
            if (y >= scy0) {
                span(row, ax, bx, color);
                row += rw;
            }
            ax += adx;
            bx += bdx;
        }
    }
    /* inclusive bottom scanline (vertical outward rounding): ax/bx now
     * hold the walker positions at y == ymax */
    if (ymax >= scy0 && ymax < scy1) {
        if (tm) {
            fix lo = ax, hi = bx;
            if (lo > hi) { fix t = lo; lo = hi; hi = t; }
            int xl = (int)(lo >> 8);
            int xr = (int)((hi + 255) >> 8);
            if (xl < scx0) xl = scx0;
            if (xr > scx1) xr = scx1;
            if (xl < xr)
                span_tex(fb + ymax * rw, xl, xr,
                         (fix)(tm->uo + (fix32)tm->ub * ymax
                               + (fix32)tm->ua * xl),
                         (fix)(tm->vo + (fix32)tm->vb * ymax
                               + (fix32)tm->va * xl),
                         tm->ua, tm->va, tm->tex, tm->bank);
        } else {
            span(fb + ymax * rw, ax, bx, color);
        }
    }
}

/* Bresenham edge line, per-pixel clipped. Drawing every polygon edge on
 * top of the interior closes T-junction seams between merged quads: both
 * sharers paint the shared world edge's pixels, so no sky pinholes remain
 * (painter order keeps overdraw correct). */
static void edge_line(uint8_t *fb, int x0, int y0, int x1, int y1,
                      uint8_t color)
{
    int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    int sx = x0 < x1 ? 1 : -1;
    int sy = y0 < y1 ? 1 : -1;
    int syw = y0 < y1 ? rw : -rw;
    int err = dx - dy;
    uint8_t *p = fb + y0 * rw + x0;
    EDGE_CALL();
    for (;;) {
        EDGE_PX();
        if (x0 >= scx0 && x0 < scx1 && y0 >= scy0 && y0 < scy1)
            *p = color;
        if (x0 == x1 && y0 == y1)
            break;
        int e2 = err << 1;
        if (e2 > -dy) { err -= dy; x0 += sx; p += sx; }
        if (e2 < dx)  { err += dx; y0 += sy; p += syw; }
    }
}

#define UVB(c) ((fix)(c) << 12)     /* block coord -> uv units (texel<<8) */

/* M24 draw-time subdivision: split a big near TOP face wider/taller than
 * this many render-target px, recursing up to SUBDIV_MAX, so each half
 * re-solves its own affine map and the perspective-affine warp shrinks
 * quadratically. Render-target px (not screen px) so it naturally fires
 * often at scale 1 (warp visible) and rarely at scale 4 (warp invisible). */
#ifndef SUBDIV_T
#define SUBDIV_T   64
#endif
#define SUBDIV_MAX 2

/* Stage G — Quality-mode (g_gfxmode==0, unscaled) anti-warp subdivision.
 * The M24 split above only fires for world TOP faces and can't split below a
 * whole block, so near side/±x/single-block faces still warp badly at scale 1.
 * The camera transform is affine, so a camera-space corner midpoint (a+b)/2 is
 * exact and uv midpoints likewise: we recursively 4-way split any big textured
 * face in camera space (all directions) so the affine-map error goes invisible.
 * Fast/Ultra never take this path -> their goldens are byte-identical. */
#ifndef QSUBDIV_T
#define QSUBDIV_T   48   /* split if est. screen extent exceeds this many px */
#endif
#ifndef QSUBDIV_MAX
#define QSUBDIV_MAX 3    /* camera-space recursion cap (4-way per level) */
#endif

/* Shared clip/vertex scratch (~550 B), kept OFF the stack.
 *
 * The CE OS gives an Asm program only ~4 KB of stack. Each of the three quad
 * rasterizers below carried these arrays as locals; under the deep interactive
 * call chain (game_session -> compose_frame -> draw_dynamic -> mob/entity draw,
 * or the world render + its M24 top-split recursion) that overflowed the stack
 * and NMI-reset the calculator on world entry.
 *
 * One shared instance is correct because at most ONE rasterizer is ever mid-
 * clip at a time: the world render (draw_quad_pts, incl. its own M24 self-
 * recursion) fully unwinds before entities are drawn, and the Quality leaf
 * (draw_quad_leaf) and entity faces (draw_box_face) likewise never nest inside
 * one another or inside draw_quad_pts. Within any single call the arrays are
 * written then read straight-line before any recursive/child call, and are
 * never read again afterwards, and the renderer is never re-entered from an
 * interrupt (render_poll runs once at frame start, before any quad). So the
 * output is byte-identical to the old stack locals — host/calc parity holds. */
static v3  rs_a[12], rs_b[12];
static fix rs_au[12], rs_av[12], rs_bu[12], rs_bv[12];
static int rs_px[12], rs_py[12];

static void draw_quad_leaf(uint8_t *fb, const v3 *ain, const fix *auin,
                           const fix *avin, const uint8_t *tex, uint8_t avg,
                           uint8_t bank)
{
    v3 *a = rs_a, *b = rs_b;                       /* shared static scratch */
    fix *au = rs_au, *av = rs_av, *bu = rs_bu, *bv = rs_bv;
    int n = 4;
    uint8_t flat = (uint8_t)(avg | bank);
    int *px = rs_px, *py = rs_py;
    int minx, maxx, miny, maxy;
    v3 *cur = a;
    fix *cu = au, *cv = av;

    for (int i = 0; i < 4; i++) {
        a[i] = ain[i];
        au[i] = auin[i];
        av[i] = avin[i];
    }

    uint8_t orc = 0, andc = 0x1F;
    for (int i = 0; i < 4; i++) {
        uint8_t c = outcode5(&a[i]);
        orc |= c;
        andc &= c;
    }
    if (andc)
        return;                     /* fully outside one plane */
    if (orc) {
        v3 *nxt = b;
        fix *nu = bu, *nv = bv;
        for (int plane = 0; plane < 5; plane++) {
            if (!(orc & (1 << plane)))
                continue;
            n = clip_plane(cur, cu, cv, n, nxt, nu, nv, plane);
            if (n < 3)
                return;
            v3 *t = cur; cur = nxt; nxt = t;
            fix *tf = cu; cu = nu; nu = tf;
            tf = cv; cv = nv; nv = tf;
        }
    }
    for (int i = 0; i < n; i++)
        PROJECT_PT(&cur[i], &px[i], &py[i]);

    minx = maxx = px[0];
    miny = maxy = py[0];
    for (int i = 1; i < n; i++) {
        if (px[i] < minx) minx = px[i];
        if (px[i] > maxx) maxx = px[i];
        if (py[i] < miny) miny = py[i];
        if (py[i] > maxy) maxy = py[i];
    }
    if (maxx + 1 < scx0 || minx - 1 >= scx1 ||
        maxy + 2 < scy0 || miny - 1 >= scy1)
        return;

#ifndef PROF_NOFILL
    if (maxx - minx <= 1 && maxy - miny <= 1) {
        if (minx >= scx0 && minx < scx1 && miny >= scy0 && miny < scy1)
            fb[miny * rw + minx] = flat;
        return;
    }
#endif
#ifndef PROF_NOEDGE
    if (rscale == 1 &&
        (maxx - minx > EDGE_SKIP_BBOX || maxy - miny > EDGE_SKIP_BBOX))
        for (int i = 0, j = n - 1; i < n; j = i++)
            edge_line(fb, px[j], py[j], px[i], py[i], flat);
#endif
#ifndef PROF_NOFILL
    if (maxx - minx <= 3 && maxy - miny <= 3) {
        fill_poly(fb, px, py, n, flat, NULL);
        return;
    }
    texmap_t tm;
    if (g_textures && texmap_solve(&tm, px, py, cu, cv)) {
        tm.tex = tex;
        tm.bank = bank;
        fill_poly(fb, px, py, n, flat, &tm);
    } else {
        fill_poly(fb, px, py, n, flat, NULL);
    }
#endif
}

/* recursive camera-space 4-way subdivider (Quality only). The split decision
 * depends ONLY on this quad's own camera-space corners (never the scissor), so
 * a scissored re-render subdivides identically -> compose byte-identity holds
 * exactly like the M24 rule at draw_quad_pts. */
static void draw_quad_cs(uint8_t *fb, const v3 *cs, const fix *qu,
                         const fix *qv, const uint8_t *tex, uint8_t avg,
                         uint8_t bank, int depth)
{
    uint8_t andc = 0x1F;
    fix minx = cs[0].x, maxx = cs[0].x, miny = cs[0].y, maxy = cs[0].y;
    fix zmin = cs[0].z;
    for (int i = 0; i < 4; i++) {
        andc &= outcode5(&cs[i]);
        if (cs[i].x < minx) minx = cs[i].x;
        if (cs[i].x > maxx) maxx = cs[i].x;
        if (cs[i].y < miny) miny = cs[i].y;
        if (cs[i].y > maxy) maxy = cs[i].y;
        if (cs[i].z < zmin) zmin = cs[i].z;
    }
    if (andc)
        return;                     /* fully outside one plane */

    if (depth > 0 && g_textures) {
        /* est. screen extent ~= rfocal * cam_extent / z; clamp z to the near
         * plane so near/clipped faces read big and always split. Compare via
         * cross-multiply (no divide): rfocal*extent > QSUBDIV_T*z. */
        fix zc = zmin < NEAR_Z ? NEAR_Z : zmin;
        fix32 thresh = (fix32)QSUBDIV_T * zc;
        if ((fix32)rfocal * (maxx - minx) > thresh ||
            (fix32)rfocal * (maxy - miny) > thresh) {
            v3 m01, m12, m23, m30, mc;
            fix u01, u12, u23, u30, uc, v01, v12, v23, v30, vc;
#define MIDV(o, p, q) do { o.x = (cs[p].x + cs[q].x) / 2;                 \
                           o.y = (cs[p].y + cs[q].y) / 2;                 \
                           o.z = (cs[p].z + cs[q].z) / 2; } while (0)
            MIDV(m01, 0, 1); MIDV(m12, 1, 2); MIDV(m23, 2, 3); MIDV(m30, 3, 0);
#undef MIDV
            mc.x = (cs[0].x + cs[1].x + cs[2].x + cs[3].x) / 4;
            mc.y = (cs[0].y + cs[1].y + cs[2].y + cs[3].y) / 4;
            mc.z = (cs[0].z + cs[1].z + cs[2].z + cs[3].z) / 4;
            u01 = (qu[0] + qu[1]) / 2; u12 = (qu[1] + qu[2]) / 2;
            u23 = (qu[2] + qu[3]) / 2; u30 = (qu[3] + qu[0]) / 2;
            uc  = (qu[0] + qu[1] + qu[2] + qu[3]) / 4;
            v01 = (qv[0] + qv[1]) / 2; v12 = (qv[1] + qv[2]) / 2;
            v23 = (qv[2] + qv[3]) / 2; v30 = (qv[3] + qv[0]) / 2;
            vc  = (qv[0] + qv[1] + qv[2] + qv[3]) / 4;
            v3 s[4]; fix su[4], sv[4];
            /* shared edge/center vertices -> no internal cracks. winding kept */
            s[0]=cs[0]; s[1]=m01; s[2]=mc;  s[3]=m30;
            su[0]=qu[0]; su[1]=u01; su[2]=uc; su[3]=u30;
            sv[0]=qv[0]; sv[1]=v01; sv[2]=vc; sv[3]=v30;
            draw_quad_cs(fb, s, su, sv, tex, avg, bank, depth - 1);
            s[0]=m01; s[1]=cs[1]; s[2]=m12; s[3]=mc;
            su[0]=u01; su[1]=qu[1]; su[2]=u12; su[3]=uc;
            sv[0]=v01; sv[1]=qv[1]; sv[2]=v12; sv[3]=vc;
            draw_quad_cs(fb, s, su, sv, tex, avg, bank, depth - 1);
            s[0]=mc;  s[1]=m12; s[2]=cs[2]; s[3]=m23;
            su[0]=uc; su[1]=u12; su[2]=qu[2]; su[3]=u23;
            sv[0]=vc; sv[1]=v12; sv[2]=qv[2]; sv[3]=v23;
            draw_quad_cs(fb, s, su, sv, tex, avg, bank, depth - 1);
            s[0]=m30; s[1]=mc;  s[2]=m23; s[3]=cs[3];
            su[0]=u30; su[1]=uc; su[2]=u23; su[3]=qu[3];
            sv[0]=v30; sv[1]=vc; sv[2]=v23; sv[3]=qv[3];
            draw_quad_cs(fb, s, su, sv, tex, avg, bank, depth - 1);
            return;
        }
    }
    draw_quad_leaf(fb, cs, qu, qv, tex, avg, bank);
}

/* transform 4 world-lattice corners, clip, project, and rasterize with
 * the block texture. Crack-patch edge lines (in the texture's dominant
 * color) go UNDER the fill: only the pixels that would otherwise be
 * T-junction seams survive. LOD: tiny quads collapse to a pixel / flat
 * fill. Outcode fast paths as in M2. `top` marks a PY/NY face (uv from
 * cx/cz) eligible for subdivision; `depth` is the remaining split budget. */
static void draw_quad_pts(uint8_t *fb, const int *cx, const int *cy,
                          const int *cz, const fix *qu, const fix *qv,
                          const uint8_t *tex, uint8_t avg, uint8_t bank,
                          int top, int depth)
{
    v3 *a = rs_a, *b = rs_b;                       /* shared static scratch */
    fix *au = rs_au, *av = rs_av, *bu = rs_bu, *bv = rs_bv;
    int n = 4;
    uint8_t flat = (uint8_t)(avg | bank);
    rstat_faces++;
#ifdef PROF_NODRAW
    return;
#endif

    /* Stage G: in Quality (unscaled) with textures, ALL face directions get
     * camera-space anti-warp subdivision — side and single-block faces the
     * M24 world-lattice TOP split below can't reach. Fast/Ultra fall through
     * to the untouched original path, so their goldens stay byte-identical. */
    if (g_gfxmode == 0 && g_textures) {
        /* xform all 4 corners to camera space (the projected-corner cache
         * fast path is traded for anti-warp here — Quality spends cycles). */
        v3 cs[4];
        xform_cached(cx[0], cy[0], cz[0], &cs[0]);
        xform_cached(cx[1], cy[1], cz[1], &cs[1]);
        xform_cached(cx[2], cy[2], cz[2], &cs[2]);
        xform_cached(cx[3], cy[3], cz[3], &cs[3]);
        draw_quad_cs(fb, cs, qu, qv, tex, avg, bank, QSUBDIV_MAX);
        return;
    }

    int *px = rs_px, *py = rs_py;                  /* shared static scratch */
    int minx, maxx, miny, maxy;
    v3 *cur = a;
    fix *cu = au, *cv = av;

    if (g_noclip) {
        project_corner(cx[0], cy[0], cz[0], &px[0], &py[0]);
        project_corner(cx[1], cy[1], cz[1], &px[1], &py[1]);
        project_corner(cx[2], cy[2], cz[2], &px[2], &py[2]);
        project_corner(cx[3], cy[3], cz[3], &px[3], &py[3]);
#if defined(PROF_XFORMONLY) || defined(PROF_NOPROJECT)
        return;
#endif
        au[0] = qu[0]; au[1] = qu[1]; au[2] = qu[2]; au[3] = qu[3];
        av[0] = qv[0]; av[1] = qv[1]; av[2] = qv[2]; av[3] = qv[3];
    } else {
        xform_cached(cx[0], cy[0], cz[0], &a[0]);
        xform_cached(cx[1], cy[1], cz[1], &a[1]);
        xform_cached(cx[2], cy[2], cz[2], &a[2]);
        xform_cached(cx[3], cy[3], cz[3], &a[3]);
#ifdef PROF_XFORMONLY
        return;
#endif
        uint8_t orc = 0, andc = 0x1F;
        for (int i = 0; i < 4; i++) {
            uint8_t c = outcode5(&a[i]);
            orc |= c;
            andc &= c;
        }
        if (andc)
            return;                 /* fully outside one plane */

        au[0] = qu[0]; au[1] = qu[1]; au[2] = qu[2]; au[3] = qu[3];
        av[0] = qv[0]; av[1] = qv[1]; av[2] = qv[2]; av[3] = qv[3];
        if (orc) {
            v3 *nxt = b;
            fix *nu = bu, *nv = bv;
            for (int plane = 0; plane < 5; plane++) {
                if (!(orc & (1 << plane)))
                    continue;
                n = clip_plane(cur, cu, cv, n, nxt, nu, nv, plane);
                if (n < 3)
                    return;
                v3 *t = cur; cur = nxt; nxt = t;
                fix *tf = cu; cu = nu; nu = tf;
                tf = cv; cv = nv; nv = tf;
            }
        }
#ifdef PROF_NOPROJECT
        return;
#endif
        for (int i = 0; i < n; i++)
            PROJECT_PT(&cur[i], &px[i], &py[i]);
    }

    minx = maxx = px[0];
    miny = maxy = py[0];
    for (int i = 1; i < n; i++) {
        if (px[i] < minx) minx = px[i];
        if (px[i] > maxx) maxx = px[i];
        if (py[i] < miny) miny = py[i];
        if (py[i] > maxy) maxy = py[i];
    }
    /* scissored (compositor) passes: skip quads that can't touch the
     * rect (margins cover the outward span/edge rounding) */
    if (maxx + 1 < scx0 || minx - 1 >= scx1 ||
        maxy + 2 < scy0 || miny - 1 >= scy1)
        return;

#ifndef PROF_NOFILL
    /* M24: a big near TOP face is split at its world midpoint and each half
     * re-solves its own affine map (shrinking the warp). The decision uses
     * ONLY this quad's projected bbox (never the scissor), so a scissored
     * re-render subdivides identically -> compose byte-identity holds. */
    if (top && depth > 0 && g_textures &&
        (maxx - minx > SUBDIV_T || maxy - miny > SUBDIV_T)) {
        int x0 = cx[0], z0 = cz[0], x1 = cx[2], z1 = cz[2];
        int w = x1 - x0, h = z1 - z0;
        if (w > 1 || h > 1) {
            int splitx = (w > 1 && h > 1) ? (w >= h) : (w > 1);
            int mid = splitx ? x0 + w / 2 : z0 + h / 2;
            for (int s = 0; s < 2; s++) {
                int rx0 = x0, rz0 = z0, rx1 = x1, rz1 = z1;
                if (splitx) { if (s == 0) rx1 = mid; else rx0 = mid; }
                else        { if (s == 0) rz1 = mid; else rz0 = mid; }
                int scx[4] = { rx0, rx1, rx1, rx0 };
                int scz[4] = { rz0, rz0, rz1, rz1 };
                int scy[4] = { cy[0], cy[0], cy[0], cy[0] };
                fix squ[4], sqv[4];
                for (int i = 0; i < 4; i++) {
                    squ[i] = UVB(scx[i]);
                    sqv[i] = UVB(scz[i]);
                }
                draw_quad_pts(fb, scx, scy, scz, squ, sqv, tex, avg, bank,
                              top, depth - 1);
            }
            return;
        }
    }
    if (maxx - minx <= 1 && maxy - miny <= 1) {
        if (minx >= scx0 && minx < scx1 && miny >= scy0 && miny < scy1)
            fb[miny * rw + minx] = flat;
        return;
    }
#endif
#ifndef PROF_NOEDGE
    /* crack patch under the fill (skipped in scaled modes: the outward
     * span rounding covers a whole 2x2/4x4 screen block there) */
    if (rscale == 1 &&
        (maxx - minx > EDGE_SKIP_BBOX || maxy - miny > EDGE_SKIP_BBOX))
        for (int i = 0, j = n - 1; i < n; j = i++)
            edge_line(fb, px[j], py[j], px[i], py[i], flat);
#endif
#ifndef PROF_NOFILL
    if (maxx - minx <= 3 && maxy - miny <= 3) {
        fill_poly(fb, px, py, n, flat, NULL);   /* LOD: flat */
        return;
    }
    texmap_t tm;
    if (g_textures &&
        (g_noclip ? texmap_solve(&tm, px, py, qu, qv)
                  : texmap_solve(&tm, px, py, cu, cv))) {
        tm.tex = tex;
        tm.bank = bank;
        fill_poly(fb, px, py, n, flat, &tm);
    } else {
        fill_poly(fb, px, py, n, flat, NULL);
    }
#endif
}

/* draw one mesh quad; dir gives the field meaning (see mesh.h) */
static void draw_quad(uint8_t *fb, const quad_t *q, int dir)
{
    if (g_skip_cave && (q->block & 0x80))
        return;                     /* cave face, camera above ground, far */
    int L = q->layer;
    int cx[4], cy[4], cz[4];
    fix qu[4], qv[4];
    uint8_t texid, bank;
    uint8_t blk = q->block & 0x1F;  /* id: bits 0-4 (banks 5-6, cave 7 stripped) */
    int ob;                         /* orientation bank 0..3 (pre-light) */
    int lv = (q->block >> 5) & 3;   /* N5 baked face light 0..3 */

    switch (dir) {
    case DIR_PY: case DIR_NY: {
        int p = (dir == DIR_PY) ? L + 1 : L;
        int x = q->a, z = q->b, w = q->w, h = q->h;
        cx[0] = x;     cy[0] = p; cz[0] = z;
        cx[1] = x + w; cy[1] = p; cz[1] = z;
        cx[2] = x + w; cy[2] = p; cz[2] = z + h;
        cx[3] = x;     cy[3] = p; cz[3] = z + h;
        for (int i = 0; i < 4; i++) {
            qu[i] = UVB(cx[i]);
            qv[i] = UVB(cz[i]);
        }
        texid = block_tex[blk][dir == DIR_PY ? 0 : 2];
        ob = (dir == DIR_PY) ? SHADE_TOP : SHADE_BOTTOM;
        break;
    }
    case DIR_PZ: case DIR_NZ: {
        int p = (dir == DIR_PZ) ? q->a + 1 : q->a;
        int x = q->b, w = q->w;
        cx[0] = x;     cy[0] = L;     cz[0] = p;
        cx[1] = x + w; cy[1] = L;     cz[1] = p;
        cx[2] = x + w; cy[2] = L + 1; cz[2] = p;
        cx[3] = x;     cy[3] = L + 1; cz[3] = p;
        for (int i = 0; i < 4; i++) {
            qu[i] = UVB(cx[i]);
            qv[i] = -UVB(cy[i]);
        }
        texid = block_tex[blk][1];
        ob = SHADE_Z;
        break;
    }
    default: {  /* DIR_PX / DIR_NX */
        int p = (dir == DIR_PX) ? q->b + 1 : q->b;
        int z = q->a;
        cx[0] = p; cy[0] = L;     cz[0] = z;
        cx[1] = p; cy[1] = L;     cz[1] = z + 1;
        cx[2] = p; cy[2] = L + 1; cz[2] = z + 1;
        cx[3] = p; cy[3] = L + 1; cz[3] = z;
        for (int i = 0; i < 4; i++) {
            qu[i] = UVB(cz[i]);
            qv[i] = -UVB(cy[i]);
        }
        texid = block_tex[blk][1];
        ob = SHADE_X;
        break;
    }
    }
    /* N5: face brightness = combine orientation bank with baked light,
     * bank = min(orientation_bank, 3 - light). A brighter (lower) bank near a
     * torch; light 0 leaves the orientation bank untouched, so daytime/
     * torchless frames are byte-identical. */
    {
        int cap = 3 - lv;
        if (ob > cap) ob = cap;
        bank = (uint8_t)(ob << 6);
    }
    int top = (dir == DIR_PY || dir == DIR_NY);
    draw_quad_pts(fb, cx, cy, cz, qu, qv,
                  tex_data[texid], tex_avg[texid], bank,
                  top, top ? SUBDIV_MAX : 0);
}

/* split-axis order: far half ascending, near half descending */
static void order_axis(int8_t *out, int n, int camblk)
{
    int m = 0;
    int hi = camblk > n - 1 ? n - 1 : camblk;
    int lo = camblk + 1 < 0 ? 0 : camblk + 1;
    for (int i = 0; i <= hi; i++) out[m++] = (int8_t)i;
    for (int i = n - 1; i >= lo; i--) out[m++] = (int8_t)i;
}

static int8_t cxorder[CHUNKS_X], czorder[CHUNKS_Z], yorder[WORLD_SY];

/*
 * Draw the sides of one layer within one chunk: z-slabs in split-axis
 * order; per slab, x singles (content) then the slab's camera-side z-plane
 * quads. Slices are sorted by slab (z buckets: field a) / by (z, x)
 * (x buckets), so ascending z walks a forward cursor and descending z a
 * backward cursor.
 */
static void draw_layer_sides(uint8_t *fb, const bucket_t *B, int L,
                             int bz, int camz_blk)
{
    const quad_t *qpz = &quad_pool[B[DIR_PZ].off];
    const quad_t *qnz = &quad_pool[B[DIR_NZ].off];
    const quad_t *qpx = &quad_pool[B[DIR_PX].off];
    const quad_t *qnx = &quad_pool[B[DIR_NX].off];
    int pz_lo = B[DIR_PZ].layer_start[L], pz_hi = B[DIR_PZ].layer_start[L + 1];
    int nz_lo = B[DIR_NZ].layer_start[L], nz_hi = B[DIR_NZ].layer_start[L + 1];
    int px_lo = B[DIR_PX].layer_start[L], px_hi = B[DIR_PX].layer_start[L + 1];
    int nx_lo = B[DIR_NX].layer_start[L], nx_hi = B[DIR_NX].layer_start[L + 1];

    if (((pz_hi - pz_lo) | (nz_hi - nz_lo) |
         (px_hi - px_lo) | (nx_hi - nx_lo)) == 0)
        return;                     /* no side quads on this layer */

    /* z split point within this chunk */
    int zhi = camz_blk - bz;            /* last ascending local slab */
    if (zhi > CHUNK_SIZE - 1) zhi = CHUNK_SIZE - 1;
    int zlo = zhi + 1;
    if (zlo < 0) zlo = 0;

    /* ascending segment: local z = 0..zhi (far -> near, camera above) */
    int cpz = pz_lo, cpx = px_lo, cnx = nx_lo;
    for (int lz = 0; lz <= zhi; lz++) {
        int Zs = bz + lz;
        /* x singles at this slab: +x slice ascending, -x slice needs
         * descending x — collect its range first, then reverse-walk */
        while (cpx < px_hi && qpx[cpx].a < Zs) cpx++;
        int sx0 = cpx;
        while (cpx < px_hi && qpx[cpx].a == Zs) cpx++;
        while (cnx < nx_hi && qnx[cnx].a < Zs) cnx++;
        int nx0 = cnx;
        while (cnx < nx_hi && qnx[cnx].a == Zs) cnx++;
        for (int i = sx0; i < cpx; i++)
            if (rcam.cx > INT_TO_FIX(qpx[i].b + 1))
                draw_quad(fb, &qpx[i], DIR_PX);
        for (int i = cnx - 1; i >= nx0; i--)
            if (rcam.cx < INT_TO_FIX(qnx[i].b))
                draw_quad(fb, &qnx[i], DIR_NX);
        /* camera-side z plane of this slab: +z quads (plane Zs+1) */
        while (cpz < pz_hi && qpz[cpz].a < Zs) cpz++;
        for (; cpz < pz_hi && qpz[cpz].a == Zs; cpz++)
            if (rcam.cz > INT_TO_FIX(Zs + 1))
                draw_quad(fb, &qpz[cpz], DIR_PZ);
    }

    /* descending segment: local z = 7..zlo (far -> near, camera below) */
    int dpz = nz_hi - 1, dpx = px_hi - 1, dnx = nx_hi - 1;
    for (int lz = CHUNK_SIZE - 1; lz >= zlo; lz--) {
        int Zs = bz + lz;
        while (dpx >= px_lo && qpx[dpx].a > Zs) dpx--;
        int sx1 = dpx;
        while (dpx >= px_lo && qpx[dpx].a == Zs) dpx--;
        while (dnx >= nx_lo && qnx[dnx].a > Zs) dnx--;
        int nx1 = dnx;
        while (dnx >= nx_lo && qnx[dnx].a == Zs) dnx--;
        /* +x slice at (L,Zs) is [dpx+1, sx1]; ascending x = far->near */
        for (int i = dpx + 1; i <= sx1; i++)
            if (rcam.cx > INT_TO_FIX(qpx[i].b + 1))
                draw_quad(fb, &qpx[i], DIR_PX);
        for (int i = nx1; i > dnx; i--)
            if (rcam.cx < INT_TO_FIX(qnx[i].b))
                draw_quad(fb, &qnx[i], DIR_NX);
        /* camera-side z plane: -z quads (plane Zs) */
        while (dpz >= nz_lo && qnz[dpz].a > Zs) dpz--;
        for (; dpz >= nz_lo && qnz[dpz].a == Zs; dpz--)
            if (rcam.cz < INT_TO_FIX(Zs))
                draw_quad(fb, &qnz[dpz], DIR_NZ);
    }
}

static void draw_chunk(uint8_t *fb, int ci, int camy_blk, int camz_blk)
{
    if (render_poll)
        render_poll();
    const bucket_t *B = chunk_buckets[ci];
    int bz = (ci % CHUNKS_Z) << CHUNK_SHIFT;
    int bx = (ci / CHUNKS_Z) << CHUNK_SHIFT;

    /* view radius (Chebyshev, chunk center vs camera) */
    {
        int dx = bx + CHUNK_SIZE / 2 - FIX_TO_INT(rcam.cx);
        int dz = bz + CHUNK_SIZE / 2 - FIX_TO_INT(rcam.cz);
        if (dx < 0) dx = -dx;
        if (dz < 0) dz = -dz;
        if ((dx > dz ? dx : dz) > (int)view_radius)
            return;
    }

    /* cave faces (bit 7) are dropped only when the camera is above ground
     * AND the whole chunk is more than 6 blocks away — measured to the
     * NEAREST chunk cell, not the center: a chunk whose center is 7 away
     * can hold cells ~3 blocks from the camera, and skipping a cave that
     * close would punch sky through it. Cull near shafts stay visible (the
     * accepted "sky at the bottom of distant pits" artifact only kicks in
     * once every cell of the chunk is out of reach). */
    {
        int cxi = FIX_TO_INT(rcam.cx), czi = FIX_TO_INT(rcam.cz);
        int nx = cxi < bx ? bx - cxi
               : cxi > bx + CHUNK_SIZE - 1 ? cxi - (bx + CHUNK_SIZE - 1) : 0;
        int nz = czi < bz ? bz - czi
               : czi > bz + CHUNK_SIZE - 1 ? czi - (bz + CHUNK_SIZE - 1) : 0;
        int near = nx > nz ? nx : nz;
        g_skip_cave = !g_cave_cull_off && g_cull_caves && near > 6;
    }

    /* chunk-level outcode over the 8 bounding corners: exact conservative
     * frustum cull (handles pitch, unlike a 2D wedge) + no-clip flag */
    {
        uint8_t orc = 0, andc = 0x1F;
        v3 cv[8];
        for (int k = 0; k < 8; k++) {
            xform_cached(bx + ((k & 1) << CHUNK_SHIFT),
                         (k & 2) ? WORLD_SY : 0,
                         bz + ((k & 4) ? CHUNK_SIZE : 0), &cv[k]);
            uint8_t c = outcode5(&cv[k]);
            orc |= c;
            andc &= c;
        }
        if (andc)
            return;             /* whole chunk outside one plane */
        g_noclip = (orc == 0);
        /* partial scissor: skip chunks whose projected bbox misses it
         * (bbox only trustworthy when no corner needs clipping) */
        if (g_noclip &&
            (scx0 > 0 || scy0 > 0 || scx1 < rw || scy1 < rh)) {
            int mnx = 32767, mny = 32767, mxx = -32767, mxy = -32767;
            for (int k = 0; k < 8; k++) {
                int px, py;
                PROJECT_PT(&cv[k], &px, &py);
                if (px < mnx) mnx = px;
                if (px > mxx) mxx = px;
                if (py < mny) mny = py;
                if (py > mxy) mxy = py;
            }
            if (mxx + 1 < scx0 || mnx - 1 >= scx1 ||
                mxy + 2 < scy0 || mny - 1 >= scy1)
                return;
        }
    }

    for (int yi = 0; yi < WORLD_SY; yi++) {
        int L = yorder[yi];
        draw_layer_sides(fb, B, L, bz, camz_blk);
        if (L <= camy_blk) {
            /* camera-side plane is L+1: +y quads of this layer */
            const bucket_t *by = &B[DIR_PY];
            const quad_t *q = &quad_pool[by->off];
            int hi = by->layer_start[L + 1];
            if (rcam.cyy > INT_TO_FIX(L + 1))
                for (int i = by->layer_start[L]; i < hi; i++)
                    draw_quad(fb, &q[i], DIR_PY);
        } else {
            const bucket_t *by = &B[DIR_NY];
            const quad_t *q = &quad_pool[by->off];
            int hi = by->layer_start[L + 1];
            if (rcam.cyy < INT_TO_FIX(L))
                for (int i = by->layer_start[L]; i < hi; i++)
                    draw_quad(fb, &q[i], DIR_NY);
        }
    }
}

/* transform an arbitrary (non-lattice) fix-coordinate point */
static void transform_fix(fix wx, fix wy, fix wz, v3 *out)
{
    fix dx = wx - rcam.cx;
    fix dy = wy - rcam.cyy;
    fix dz = wz - rcam.cz;
    fix t;
    out->x = FMUL(dx, rcam.cy) - FMUL(dz, rcam.sy);
    t      = FMUL(dx, rcam.sy) + FMUL(dz, rcam.cy);
    out->z = FMUL(t, rcam.cp) + FMUL(dy, rcam.sp);
    out->y = FMUL(dy, rcam.cp) - FMUL(t, rcam.sp);
}

/* draw one quad given 4 world-space fix corners (mob faces); textured
 * when a tile is given (full tile stretched across the face). */
static void draw_box_face(uint8_t *fb, const fix *wx, const fix *wy,
                          const fix *wz, uint8_t color, const uint8_t *tex,
                          uint8_t bank)
{
    v3 *a = rs_a, *b = rs_b;                       /* shared static scratch */
    fix *au = rs_au, *av = rs_av, *bu = rs_bu, *bv = rs_bv;
    static const fix uvc[4][2] = {
        {0, 4095}, {4095, 4095}, {4095, 0}, {0, 0},
    };
    int n = 4;
    for (int i = 0; i < 4; i++) {
        transform_fix(wx[i], wy[i], wz[i], &a[i]);
        au[i] = uvc[i][0];
        av[i] = uvc[i][1];
    }
    uint8_t orc = 0, andc = 0x1F;
    for (int i = 0; i < 4; i++) {
        uint8_t c = outcode5(&a[i]);
        orc |= c;
        andc &= c;
    }
    if (andc)
        return;
    v3 *cur = a;
    fix *cu = au, *cv = av;
    if (orc) {
        v3 *nxt = b;
        fix *nu = bu, *nv = bv;
        for (int plane = 0; plane < 5; plane++) {
            if (!(orc & (1 << plane)))
                continue;
            n = clip_plane(cur, cu, cv, n, nxt, nu, nv, plane);
            if (n < 3)
                return;
            v3 *t = cur; cur = nxt; nxt = t;
            fix *tf = cu; cu = nu; nu = tf;
            tf = cv; cv = nv; nv = tf;
        }
    }
    int *px = rs_px, *py = rs_py;                  /* shared static scratch */
    int bx0 = 32767, by0 = 32767, bx1 = -32767, by1 = -32767;
    for (int i = 0; i < n; i++) {
        PROJECT_PT(&cur[i], &px[i], &py[i]);
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    rbb_add(bx0, by0, bx1 + 1, by1 + 2);   /* +2: inclusive bottom row */
    texmap_t tm;
    if (tex && g_textures && n >= 3 &&
        texmap_solve(&tm, px, py, cu, cv)) {
        tm.tex = tex;
        tm.bank = bank;
        fill_poly(fb, px, py, n, color, &tm);
    } else {
        fill_poly(fb, px, py, n, color, NULL);
    }
}

/* axis-aligned box (mob body/head): top + at most one camera-facing x side
 * and one z side. The x and z sides carry INDEPENDENT textures (either NULL
 * -> flat), so a mob can show a different tile per visible face; the top is
 * always a flat fill (heads are never seen from above in normal play). */
static void box_emit(uint8_t *fb, fix bx, fix by, fix bz, fix half,
                     fix height, uint8_t base,
                     const uint8_t *xtex, const uint8_t *ztex)
{
    fb = rt;              /* world-space content always lands pre-upscale */
    fix x0 = bx - half, x1 = bx + half;
    fix y0 = by, y1 = by + height;
    fix z0 = bz - half, z1 = bz + half;
    fix wx[4], wy[4], wz[4];

    if (rcam.cyy > y1) {                       /* top */
        wx[0]=x0; wx[1]=x1; wx[2]=x1; wx[3]=x0;
        wy[0]=wy[1]=wy[2]=wy[3]=y1;
        wz[0]=z0; wz[1]=z0; wz[2]=z1; wz[3]=z1;
        draw_box_face(fb, wx, wy, wz, base, NULL, 0);
    }
    if (rcam.cx > x1 || rcam.cx < x0) {           /* one x side */
        fix p = rcam.cx > x1 ? x1 : x0;
        wx[0]=wx[1]=wx[2]=wx[3]=p;
        wy[0]=y0; wy[1]=y0; wy[2]=y1; wy[3]=y1;
        wz[0]=z0; wz[1]=z1; wz[2]=z1; wz[3]=z0;
        draw_box_face(fb, wx, wy, wz, (uint8_t)(base | (SHADE_X << 6)),
                      xtex, SHADE_X << 6);
    }
    if (rcam.cz > z1 || rcam.cz < z0) {           /* one z side */
        fix p = rcam.cz > z1 ? z1 : z0;
        wz[0]=wz[1]=wz[2]=wz[3]=p;
        wy[0]=y0; wy[1]=y0; wy[2]=y1; wy[3]=y1;
        wx[0]=x0; wx[1]=x1; wx[2]=x1; wx[3]=x0;
        draw_box_face(fb, wx, wy, wz, (uint8_t)(base | (SHADE_Z << 6)),
                      ztex, SHADE_Z << 6);
    }
}

/* flat / single-texture box (drops, TNT, back-compat): same tile on both
 * visible sides — byte-identical to the pre-M21 render_box. */
void render_box(uint8_t *fb, fix bx, fix by, fix bz, fix half, fix height,
                uint8_t base, const uint8_t *tex)
{
    box_emit(fb, bx, by, bz, half, height, base, tex, tex);
}

/* per-face box (mobs): distinct tiles on the visible x side and z side */
void render_box_faces(uint8_t *fb, fix bx, fix by, fix bz, fix half,
                      fix height, uint8_t base,
                      const uint8_t *xtex, const uint8_t *ztex)
{
    box_emit(fb, bx, by, bz, half, height, base, xtex, ztex);
}

int render_project(fix x, fix y, fix z, int *sx, int *sy, fix *depth)
{
    v3 v;
    transform_fix(x, y, z, &v);
    if (v.z < NEAR_Z)
        return 0;
    PROJECT_PT(&v, sx, sy);
    *depth = v.z;
    return 1;
}

void render_sprite16(int sx, int sy, int size, const uint8_t *tile,
                     uint8_t key)
{
    uint8_t ut[SPRITE_MAX];
    if (size > SPRITE_MAX)
        size = SPRITE_MAX;
    if (size < 1)
        return;
    int x0 = sx - size / 2, y0 = sy - size / 2;
    int x1 = x0 + size, y1 = y0 + size;
    int cx0 = x0 < scx0 ? scx0 : x0, cy0 = y0 < scy0 ? scy0 : y0;
    int cx1 = x1 > scx1 ? scx1 : x1, cy1 = y1 > scy1 ? scy1 : y1;
    if (cx0 >= cx1 || cy0 >= cy1)
        return;
    for (int k = 0; k < size; k++)          /* nearest texel per column/row */
        ut[k] = (uint8_t)((k * 16) / size);
    for (int y = cy0; y < cy1; y++) {
        const uint8_t *src = tile + ut[y - y0] * 16;
        uint8_t *row = rt + y * rw;
        for (int x = cx0; x < cx1; x++) {
            uint8_t c = src[ut[x - x0]];
            if (c != key)
                row[x] = c;
        }
    }
    rbb_add(x0, y0, x1, y1);
}

/* outline one block face (the mining target) in white */
void render_face_outline(uint8_t *fb, int x, int y, int z, int dir)
{
    static const uint8_t off[6][4][3] = {
        { {0,1,0}, {1,1,0}, {1,1,1}, {0,1,1} },
        { {0,0,0}, {1,0,0}, {1,0,1}, {0,0,1} },
        { {1,0,0}, {1,1,0}, {1,1,1}, {1,0,1} },
        { {0,0,0}, {0,1,0}, {0,1,1}, {0,0,1} },
        { {0,0,1}, {1,0,1}, {1,1,1}, {0,1,1} },
        { {0,0,0}, {1,0,0}, {1,1,0}, {0,1,0} },
    };
    v3 a[4];
    int px[4], py[4];
    fb = rt;
    for (int i = 0; i < 4; i++) {
        xform_cached(x + off[dir][i][0], y + off[dir][i][1],
                     z + off[dir][i][2], &a[i]);
        if (outcode5(&a[i]))
            return;              /* partially clipped: skip the outline */
        PROJECT_PT(&a[i], &px[i], &py[i]);
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; i++) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    rbb_add(bx0, by0, bx1 + 1, by1 + 1);
    for (int i = 0, j = 3; i < 4; j = i++)
        edge_line(fb, px[j], py[j], px[i], py[i], PAL_WHITE);
}

int render_scale(void)
{
    return g_gfxmode == 2 ? 4 : g_gfxmode == 1 ? 2 : 1;
}

void render_window_info(int *ox, int *oy, int *scale)
{
    int vw = g_viewport == 2 ? 80 : g_viewport == 1 ? 160 : SCREEN_W;
    int vh = g_viewport == 2 ? 60 : g_viewport == 1 ? 120 : SCREEN_H;
    *ox = (SCREEN_W - vw) / 2;
    *oy = (SCREEN_H - vh) / 2;
    *scale = render_scale();
}

/* re-render the world inside one render-coord rect (compositor restore
 * path). Full-frame renders are just the full-size rect. */
void render_frame_rect(uint8_t *fb, const camera_t *cam,
                       int x0, int y0, int x1, int y1)
{
    rstat_faces = 0;
    mesh_update();

    rscale = (uint8_t)render_scale();
    winw = g_viewport == 2 ? 80 : g_viewport == 1 ? 160 : SCREEN_W;
    winh = g_viewport == 2 ? 60 : g_viewport == 1 ? 120 :
           (view_h < SCREEN_H ? view_h : SCREEN_H);
    wox = (SCREEN_W - winw) / 2;
    woy = (SCREEN_H - winh) / 2;
    rw = winw / rscale;
    rh = winh / rscale;
    rcx = rw / 2;
    rcy = rh / 2;
    /* focal scales with BOTH window and pixel scale: FOV never changes */
    rfocal = FOCAL * winw / (SCREEN_W * rscale);
    rt = (rscale == 1 && winw == SCREEN_W) ? fb : scaled_buf;

    rcam.sy = SIN(cam->yaw);  rcam.cy = COS(cam->yaw);
    rcam.sp = SIN(cam->pitch); rcam.cp = COS(cam->pitch);
    rcam.cx = cam->x; rcam.cyy = cam->y; rcam.cz = cam->z;

    /* cave cull enable: camera at/above the gen-time terrain line at its
     * column. Out-of-world horizontally => above ground => cull. */
    {
        int ccx = FIX_TO_INT(rcam.cx), ccz = FIX_TO_INT(rcam.cz);
        if (ccx < 0 || ccx >= WORLD_SX || ccz < 0 || ccz >= WORLD_SZ)
            g_cull_caves = 1;
        else
            g_cull_caves = FIX_TO_INT(rcam.cyy) >=
                           world_height[ccx * WORLD_SZ + ccz];
        /* push3 S1: a floating island's underside sits below its terrain
         * line, so it is cave-flagged; never cull in Skyblock (the void
         * camera would lose the island's bottom faces) */
        if (g_worldtype == 2)
            g_cull_caves = 0;
    }

    scx0 = x0 < 0 ? 0 : x0;
    scy0 = y0 < 0 ? 0 : y0;
    scx1 = x1 > rw ? rw : x1;
    scy1 = y1 > rh ? rh : y1;
    if (scx0 >= scx1 || scy0 >= scy1) {
        /* setup-only call (compositor): target + camera are loaded and
         * the scissor opens for the entity draws that follow */
        scx0 = 0; scy0 = 0;
        scx1 = rw; scy1 = rh;
        return;
    }

    for (int y = scy0; y < scy1; y++) {
        uint8_t *srow = rt + y * rw;
        memset(srow + scx0, sky_row_idx(y, rh), (size_t)(scx1 - scx0));
        /* night stars: a sparse deterministic hash (small int24-safe math,
         * pattern is a pure function of (x,y) so full and scissored renders
         * agree). Only the upper 3/5 of the sky carries stars. */
        if (g_night_sky && y < (rh * 3) / 5)
            for (int x = scx0; x < scx1; x++) {
                /* nonlinear (x*y) hash breaks the a*x+b*y lattice that made
                 * stars line up; all terms stay < 2^22 for int24 parity */
                int h = x * 131 + y * 57 + x * y;
                h = (h ^ (h >> 4)) + (x ^ (y * 3));
                if ((h & 255) < 3)
                    srow[x] = PAL_WHITE;
            }
    }

    for (int i = 0; i < VC_N; i++) {
        vckey[i] = -1;
        vpkey[i] = -1;
    }

    int cbx = FIX_TO_INT(cam->x);
    int cby = FIX_TO_INT(cam->y);
    int cbz = FIX_TO_INT(cam->z);
    order_axis(cxorder, CHUNKS_X, cbx >> CHUNK_SHIFT);
    order_axis(czorder, CHUNKS_Z, cbz >> CHUNK_SHIFT);
    order_axis(yorder, WORLD_SY, cby);

    for (int cxi = 0; cxi < CHUNKS_X; cxi++) {
        for (int czi = 0; czi < CHUNKS_Z; czi++) {
            int ci = cxorder[cxi] * CHUNKS_Z + czorder[czi];
            draw_chunk(rt, ci, cby, cbz);
        }
    }
}

void render_frame(uint8_t *fb, const camera_t *cam)
{
    render_frame_rect(fb, cam, 0, 0, SCREEN_W, SCREEN_H);
}

/* screen rect of the 3x3x3 block neighborhood around an edited cell
 * (an edit also exposes neighbor faces). 0 = crosses the frustum. */
int render_block_rect(const camera_t *cam, int bx, int by, int bz,
                      int *x0, int *y0, int *x1, int *y1)
{
    rscale = (uint8_t)render_scale();
    rw = SCREEN_W / rscale;
    rh = view_h / rscale;
    rcx = rw / 2;
    rcy = rh / 2;
    rfocal = FOCAL / rscale;
    rcam.sy = SIN(cam->yaw);  rcam.cy = COS(cam->yaw);
    rcam.sp = SIN(cam->pitch); rcam.cp = COS(cam->pitch);
    rcam.cx = cam->x; rcam.cyy = cam->y; rcam.cz = cam->z;

    int mnx = 32767, mny = 32767, mxx = -32767, mxy = -32767;
    for (int k = 0; k < 8; k++) {
        v3 v;
        transform(bx + ((k & 1) ? 2 : -1),
                  by + ((k & 2) ? 2 : -1),
                  bz + ((k & 4) ? 2 : -1), &v);
        if (outcode5(&v))
            return 0;
        int px, py;
        PROJECT_PT(&v, &px, &py);
        if (px < mnx) mnx = px;
        if (px > mxx) mxx = px;
        if (py < mny) mny = py;
        if (py > mxy) mxy = py;
    }
    *x0 = mnx - 1; *y0 = mny - 1;
    *x1 = mxx + 2; *y1 = mxy + 3;
    return 1;
}

/* project chunk ci's bounds to a render-coord screen rect. Returns 0
 * (caller should treat the whole frame as dirty) when the chunk crosses
 * a frustum plane, where a projected bbox is unreliable. Requires the
 * camera globals from a render this frame OR sets them itself. */
int render_chunk_rect(const camera_t *cam, int ci,
                      int *x0, int *y0, int *x1, int *y1)
{
    rscale = (uint8_t)render_scale();
    rw = SCREEN_W / rscale;
    rh = view_h / rscale;
    rcx = rw / 2;
    rcy = rh / 2;
    rfocal = FOCAL / rscale;
    rcam.sy = SIN(cam->yaw);  rcam.cy = COS(cam->yaw);
    rcam.sp = SIN(cam->pitch); rcam.cp = COS(cam->pitch);
    rcam.cx = cam->x; rcam.cyy = cam->y; rcam.cz = cam->z;

    int bz = (ci % CHUNKS_Z) << CHUNK_SHIFT;
    int bx = (ci / CHUNKS_Z) << CHUNK_SHIFT;
    int mnx = 32767, mny = 32767, mxx = -32767, mxy = -32767;
    for (int k = 0; k < 8; k++) {
        v3 v;
        transform(bx + ((k & 1) << CHUNK_SHIFT),
                  (k & 2) ? WORLD_SY : 0,
                  bz + ((k & 4) ? CHUNK_SIZE : 0), &v);
        if (outcode5(&v))
            return 0;
        int px, py;
        PROJECT_PT(&v, &px, &py);
        if (px < mnx) mnx = px;
        if (px > mxx) mxx = px;
        if (py < mny) mny = py;
        if (py > mxy) mxy = py;
    }
    *x0 = mnx - 1; *y0 = mny - 1;
    *x1 = mxx + 2; *y1 = mxy + 3;
    return 1;
}

#ifdef __ez80__
/* Hand-written eZ80 per-row pixel expanders (src/present.asm): each is
 * EXACTLY the inner for-x duplication loop of the C present below. Wired
 * only on the calc; the host keeps the C loops as the byte-identity
 * reference (compose matrix). */
void present_row2_asm(uint8_t *dst, const uint8_t *src, unsigned n);
void present_row4_asm(uint8_t *dst, const uint8_t *src, unsigned n);
#define PRESENT_ROW2(d, s, n) present_row2_asm((d), (s), (unsigned)(n))
#define PRESENT_ROW4(d, s, n) present_row4_asm((d), (s), (unsigned)(n))
#else
#define PRESENT_ROW2(d, s, n) do {                     \
        uint8_t *d_ = (d); const uint8_t *s_ = (s);    \
        for (int x_ = 0; x_ < (n); x_++) {             \
            uint8_t c_ = s_[x_];                       \
            *d_++ = c_; *d_++ = c_;                    \
        }                                              \
    } while (0)
#define PRESENT_ROW4(d, s, n) do {                     \
        uint8_t *d_ = (d); const uint8_t *s_ = (s);    \
        for (int x_ = 0; x_ < (n); x_++) {             \
            uint8_t c_ = s_[x_];                       \
            *d_++ = c_; *d_++ = c_; *d_++ = c_; *d_++ = c_; \
        }                                              \
    } while (0)
#endif

/* expand one render-coord rect of the scaled frame into the (possibly
 * windowed) screen; no-op when rt == fb (Quality, full viewport) */
void render_present_rect(uint8_t *fb, int x0, int y0, int x1, int y1)
{
    if (rt == fb)
        return;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > rw) x1 = rw;
    if (y1 > rh) y1 = rh;
    if (x0 >= x1 || y0 >= y1)
        return;
    int n = x1 - x0;
    for (int y = y1 - 1; y >= y0; y--) {
        const uint8_t *s = rt + y * rw + x0;
        uint8_t *d0 = fb + (woy + y * rscale) * SCREEN_W
                      + wox + x0 * rscale;
        uint8_t *d = d0;
        if (rscale == 1) {
            memcpy(d0, s, (size_t)n);
        } else if (rscale == 2) {
            PRESENT_ROW2(d, s, n);
            memcpy(d0 + SCREEN_W, d0, (size_t)(n * 2));
        } else {
            PRESENT_ROW4(d, s, n);
            memcpy(d0 + SCREEN_W, d0, (size_t)(n * 4));
            memcpy(d0 + 2 * SCREEN_W, d0, (size_t)(n * 4));
            memcpy(d0 + 3 * SCREEN_W, d0, (size_t)(n * 4));
        }
    }
}

/* expand the scaled frame to the screen (plus the black letterbox when
 * a window viewport is active); no-op when rt == fb. Call after all
 * world-space drawing and before the HUD. */
void render_present(uint8_t *fb)
{
    if (rt == fb)
        return;
    if (winw < SCREEN_W) {
        /* letterbox border */
        for (int y = 0; y < woy; y++)
            memset(fb + y * SCREEN_W, PAL_BLACK, SCREEN_W);
        for (int y = woy + winh; y < SCREEN_H; y++)
            memset(fb + y * SCREEN_W, PAL_BLACK, SCREEN_W);
        for (int y = woy; y < woy + winh; y++) {
            memset(fb + y * SCREEN_W, PAL_BLACK, (size_t)wox);
            memset(fb + y * SCREEN_W + wox + winw, PAL_BLACK,
                   (size_t)(SCREEN_W - wox - winw));
        }
        render_present_rect(fb, 0, 0, rw, rh);
        return;
    }

    /* Full-frame fast path (no window offset): a full-width scaled row is
     * exactly SCREEN_W bytes, so the row-duplication memcpy has a COMPILE-
     * TIME-CONSTANT size the compiler inlines. Routing the full present
     * through render_present_rect (M17) used a runtime memcpy size (n*2)
     * + per-row window-offset math, which nearly DOUBLED present cost on
     * the scaled ladder (Fast r10 0.749->0.811 s regression). Byte output
     * is identical to render_present_rect for this case (wox=woy=x0=0). */
    for (int y = rh - 1; y >= 0; y--) {
        const uint8_t *s = rt + y * rw;
        uint8_t *d0 = fb + y * rscale * SCREEN_W;
        uint8_t *d = d0;
        if (rscale == 2) {
            PRESENT_ROW2(d, s, rw);
            memcpy(d0 + SCREEN_W, d0, SCREEN_W);
        } else {
            PRESENT_ROW4(d, s, rw);
            memcpy(d0 + SCREEN_W, d0, SCREEN_W);
            memcpy(d0 + 2 * SCREEN_W, d0, SCREEN_W);
            memcpy(d0 + 3 * SCREEN_W, d0, SCREEN_W);
        }
    }
}
