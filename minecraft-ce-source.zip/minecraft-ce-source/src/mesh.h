/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef MESH_H
#define MESH_H

#include "common.h"
#include "world.h"

/*
 * Chunk meshes. A chunk is an 8x8-column mesh unit (6x6 chunks); storage
 * stays the flat world array. Quads per direction obey the BSP hierarchy
 * y -> z -> x (see notes/plan.md): +y/-y merge into (x,z) rectangles,
 * +z/-z into single-layer x-runs, +x/-x stay single cells. That makes the
 * painter traversal exact with zero per-frame sorting.
 */

#define CHUNK_SHIFT 3
#define CHUNK_SIZE  8
#define CHUNKS_X    (WORLD_SX >> CHUNK_SHIFT)   /* 6 */
#define CHUNKS_Z    (WORLD_SZ >> CHUNK_SHIFT)   /* 6 */
#define NCHUNKS     (CHUNKS_X * CHUNKS_Z)

/* directions */
#define DIR_PY 0
#define DIR_NY 1
#define DIR_PX 2
#define DIR_NX 3
#define DIR_PZ 4
#define DIR_NZ 5

/* one mesh quad, 6 bytes; field meaning depends on direction:
 *  ±y: layer, a=x0, b=z0, w=x extent, h=z extent
 *  ±z: layer, a=z slab, b=x0, w=x extent, h=1
 *  ±x: layer, a=z, b=x, w=1, h=1
 * coordinates are world-absolute (fit u8). */
typedef struct {
    uint8_t layer, a, b, w, h, block;
} quad_t;

/* N5 note: measured worst full-world mesh is 2304 quads over 60 seeds; the
 * light-gradient merge split adds a few quads only in the small radius around
 * a torch. 2500 keeps headroom while freeing 3 KB of .bss for the packed light
 * field; on overflow the mesher already evicts + lazily remeshes (no crash). */
#define QUAD_POOL_MAX 2500

typedef struct {
    uint16_t off;               /* segment start in quad pool */
    uint8_t count;
    uint8_t layer_start[WORLD_SY + 1];   /* per-layer slice index, relative */
} bucket_t;

extern quad_t quad_pool[QUAD_POOL_MAX];
extern bucket_t chunk_buckets[NCHUNKS][6];
/* chunk bits set by mesh_dirty_block since last cleared; the frame
 * compositor reads these to know which screen rects need re-rendering */
extern uint16_t mesh_events;
extern uint16_t mesh_pool_used;
extern uint16_t mstat_quads;    /* total live quads, for the perf notes */

void mesh_init(void);                 /* all chunks dirty, pool empty */
void mesh_dirty_block(int x, int z);  /* block edit at x,z (any y) */
void mesh_update(void);               /* remesh dirty chunks */
void mesh_update_chunk(int ci);       /* remesh one chunk now */

#endif
