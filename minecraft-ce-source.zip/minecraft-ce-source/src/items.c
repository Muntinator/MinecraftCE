/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * items.c — the item id table (ids >= ITEM_BASE). Items are inventory-only:
 * not placeable, never meshed or rendered as world blocks. Drops and the
 * inventory ITEMS page draw them with a representative 16x16 tile.
 */

#include "items.h"
#include "textures.h"

/* Representative 16x16 icon per item id (UI U3: every icon is a
 * transparent tile in the T_ICO_FIRST..T_ICO_LAST run, sliced from the
 * official gui/items.png by tools/gen_lce_assets.py; hud.c blits them with
 * the TEX_KEY skipped and drop.c draws them as camera-facing sprites),
 * indexed by (id - ITEM_BASE). */
const uint8_t items_tile[ITEM_COUNT] = {
    T_ICO_STICK,        /* I_STICK           */
    T_ICO_GUNPOWDER,    /* I_GUNPOWDER       */
    T_ICO_PORK,         /* I_PORKCHOP        */
    T_ICO_PICK_W,       /* I_PICK_WOOD       */
    T_ICO_PICK_S,       /* I_PICK_STONE      */
    T_ICO_PICK_I,       /* I_PICK_IRON       */
    T_ICO_AXE_W,        /* I_AXE_WOOD        */
    T_ICO_AXE_S,        /* I_AXE_STONE       */
    T_ICO_AXE_I,        /* I_AXE_IRON        */
    T_ICO_SWORD_W,      /* I_SWORD_WOOD      */
    T_ICO_SWORD_S,      /* I_SWORD_STONE     */
    T_ICO_SWORD_I,      /* I_SWORD_IRON      */
    T_ICO_COAL,         /* I_COAL            */
    T_ICO_INGOT,        /* I_IRON_INGOT      */
    T_ICO_PORK_COOKED,  /* I_PORKCHOP_COOKED */
    T_ICO_HELMET,       /* I_HELMET_IRON     */
    T_ICO_CHEST,        /* I_CHEST_IRON      */
    T_ICO_LEGS,         /* I_LEGS_IRON       */
    T_ICO_BOOTS,        /* I_BOOTS_IRON      */
    T_ICO_BUCKET,       /* I_BUCKET          */
    T_ICO_BUCKET_WATER, /* I_BUCKET_WATER    */
    T_ICO_BUCKET_LAVA,  /* I_BUCKET_LAVA     */
};

uint8_t id_side_tile(uint8_t id)
{
    if (id < B_COUNT)
        return block_tex[id][1];              /* block: side tile */
    if (id >= ITEM_BASE && id < ID_COUNT)
        return items_tile[id - ITEM_BASE];
    return T_STONE;                           /* unreachable fallback */
}

/* ---- N3 tool-tier gating (pure) ---- */

int held_pick_tier(uint8_t held)
{
    switch (held) {
        case I_PICK_WOOD:  return 1;
        case I_PICK_STONE: return 2;
        case I_PICK_IRON:  return 3;
        default:           return 0;
    }
}

int held_axe_tier(uint8_t held)
{
    switch (held) {
        case I_AXE_WOOD:  return 1;
        case I_AXE_STONE: return 2;
        case I_AXE_IRON:  return 3;
        default:          return 0;
    }
}

int block_req_pick(uint8_t b)
{
    switch (b) {
        /* stone family + furnace + coal ore need a wooden pick or better.
         * (Coal ore isn't named in the spec's lists; ores need a pick in MC,
         * so it is gated at wood pick+ — recorded in notes/push2-log.md.) */
        case B_STONE:
        case B_COBBLE:
        case B_COAL_ORE:
        case B_FURNACE:
        case B_FURNACE_LIT:
            return 1;
        case B_IRON_ORE:
            return 2;               /* stone pick or better */
        case B_OBSIDIAN:
            return 3;               /* push3: iron pick only (no diamond tier) */
        default:
            return 0;               /* hand-harvestable */
    }
}

bool block_harvestable(uint8_t b, uint8_t held)
{
    int req = block_req_pick(b);
    if (req == 0)
        return true;
    return held_pick_tier(held) >= req;
}

/* tier -> break-time divisor: 0 none=1, wood=2, stone=3, iron=5 */
static int tier_div(int tier)
{
    static const uint8_t d[4] = { 1, 2, 3, 5 };
    return d[tier & 3];
}

int mine_divisor(uint8_t b, uint8_t held)
{
    int req = block_req_pick(b);
    if (req > 0) {
        /* pick-class block: a pick speeds it ONLY when it meets the required
         * tier; the wrong/no tool falls through to a slow (divisor 1) break. */
        int t = held_pick_tier(held);
        return (t >= req) ? tier_div(t) : 1;
    }
    if (b == B_LOG || b == B_PLANKS || b == B_CRAFTING_TABLE || b == B_CHEST) {
        /* axe-class block: any axe speeds it; it still hand-drops ungated. */
        return tier_div(held_axe_tier(held));
    }
    return 1;
}
