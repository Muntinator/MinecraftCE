convimg output (make gfx) goes here.
