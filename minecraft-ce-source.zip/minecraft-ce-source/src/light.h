/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef LIGHT_H
#define LIGHT_H

#include "common.h"
#include "world.h"
#include "render.h"      /* camera_t (torches_draw) */

/*
 * N5 block-light field. A 2-bit level (0..3) per world cell, stored ONE
 * BYTE per cell (WORLD_SX*WORLD_SZ*WORLD_SY = 12288 B).
 *
 * Layout justification (spec delegated "nibble-packed or byte array if RAM
 * allows — justify"): a byte array would be the cheapest to read on the eZ80
 * bus, BUT the default bss region has no room for a 12 KB companion to
 * world[] (measured: a byte field overflows .bss by ~12 KB). The value is
 * exactly 2 bits (levels 0..3), so it is packed 4 cells/byte into 3072 B —
 * exact, not lossy. The pack/unpack is a shift+mask; the field is only READ
 * hot (mesher face sample + the relaxation), never on the per-pixel path, so
 * the mask cost is negligible next to fitting RAM. No save-format bump:
 * torches and lit furnaces are ordinary world blocks already in the RLE, so
 * the light field is DERIVED and rebuilt from world[] on load (light_reset).
 */

#define LIGHT_MAX      3     /* torch emission; also the 2-bit ceiling */
#define FURNACE_LIGHT  2     /* lit-furnace emission */

#define WORLD_N (WORLD_SX * WORLD_SZ * WORLD_SY)
extern uint8_t light_packed[(WORLD_N + 3) / 4];   /* 4 cells (2 bits) / byte */

static inline uint8_t light_get(int x, int y, int z)
{
    if (x < 0 || x >= WORLD_SX || y < 0 || y >= WORLD_SY ||
        z < 0 || z >= WORLD_SZ)
        return 0;
    int idx = WORLD_IDX(x, y, z);
    return (light_packed[idx >> 2] >> ((idx & 3) << 1)) & 3;
}

static inline void light_set_idx(int idx, uint8_t v)
{
    int sh = (idx & 3) << 1;
    uint8_t *p = &light_packed[idx >> 2];
    *p = (uint8_t)((*p & ~(3 << sh)) | ((v & 3) << sh));
}

/* opaque = blocks light propagation. Air/torch/glass/leaves/water pass. */
bool block_opaque(uint8_t b);
/* emission level of a source block (0 = not a source) */
uint8_t light_emit(uint8_t b);

/* full rebuild from world[] (clear + seed all sources + relax) and rebuild
 * the torch render list. Called by mesh_init(), so it runs after every
 * world_gen / load, before the first mesh. */
void light_reset(void);

/* incremental, LOCAL light edits — each re-floods only a radius-LIGHT_MAX box
 * and marks exactly the touched columns mesh-dirty (chunk-local remesh):
 *  - add: monotonic box relaxation from a new source
 *  - del: clear the source's box, re-seed survivors, box relax */
void light_add_source(int x, int y, int z, uint8_t emit);
void light_del_source(int x, int y, int z);

/* torch entities, for the small-box render pass (bss-budget capped) */
#define TORCH_MAX 64
extern uint8_t torch_n;
extern uint8_t torch_pos[TORCH_MAX][3];
void torch_list_add(int x, int y, int z);
void torch_list_del(int x, int y, int z);

/* draw all torches as small centered boxes (called alongside mobs/drops) */
void torches_draw(uint8_t *fb, const camera_t *cam);

#endif
