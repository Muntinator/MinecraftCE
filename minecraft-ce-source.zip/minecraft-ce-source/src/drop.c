/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * drop.c — item drop entities: a broken block becomes a small floating
 * cube that falls, bobs, and is collected on touch. Ticked from
 * player_tick so host playback and calc stay in parity.
 * UI U3: drops of ITEM ids (>= ITEM_BASE) are camera-facing sprites of
 * their icon (as in Minecraft); block drops keep the mini cube.
 */

#include <stddef.h>

#include "drop.h"
#include "world.h"
#include "player.h"
#include "palette.h"
#include "textures.h"
#include "items.h"
#include "lut.h"

drop_t drops[DROP_MAX];
static uint8_t drop_next;

#define D_HALF   512               /* 0.25-block cube */
#define D_HEIGHT 1024
/* item sprite width in blocks (12.12): 0.4 block = 16 px at 4 blocks with
 * the 160 px focal length; size = rfocal * D_SPRITE_W / depth, so it
 * follows the pixel scale and the viewport window automatically */
#define D_SPRITE_W  1638
#define D_SPRITE_MIN 4
#define D_SPRITE_MAX 32
#define D_GRAV   60
#define DROP_TTL 1800               /* 60 s at 30 Hz */

static bool dsolid(uint8_t b)
{
    return b != B_AIR && !block_liquid(b);
}

void drops_reset(void)
{
    for (int i = 0; i < DROP_MAX; i++)
        drops[i].alive = 0;
    drop_next = 0;
}

void drop_spawn(int bx, int by, int bz, uint8_t block)
{
    drop_t *d = &drops[drop_next];
    drop_next = (uint8_t)((drop_next + 1) % DROP_MAX);
    d->x = INT_TO_FIX(bx) + FIX_ONE / 2;
    d->z = INT_TO_FIX(bz) + FIX_ONE / 2;
    d->y = INT_TO_FIX(by) + FIX_ONE / 4;
    d->vy = 240;                    /* little pop upward */
    d->age = 0;
    d->block = block;
    d->alive = 1;
}

void drops_tick(void)
{
    for (int i = 0; i < DROP_MAX; i++) {
        drop_t *d = &drops[i];
        if (!d->alive)
            continue;
        if (++d->age >= DROP_TTL) {
            d->alive = 0;
            continue;
        }
        d->vy -= D_GRAV;
        if (d->vy < -1200)
            d->vy = -1200;
        fix ny = d->y + d->vy;
        if (dsolid(world_get(FIX_TO_INT(d->x), FIX_TO_INT(ny),
                             FIX_TO_INT(d->z)))) {
            if (d->vy < 0)
                d->y = INT_TO_FIX(FIX_TO_INT(ny)) + FIX_ONE;
            d->vy = 0;
        } else {
            d->y = ny;
        }
        /* fell out of the world. push3 S1: only the Skyblock void gets
         * here (elsewhere world_get(y < 0) is a bedrock floor), so the
         * "below y = -2" despawn needs no world-type test */
        /* push3 S3: a drop that touches lava burns up */
        uint8_t in = world_get(FIX_TO_INT(d->x), FIX_TO_INT(d->y),
                               FIX_TO_INT(d->z));
        if (d->y < -2 * FIX_ONE || in == B_LAVA || in == B_LAVA_FLOW) {
            d->alive = 0;
            continue;
        }
        /* pickup: player center within 0.75 block, roughly same height */
        fix dx = plr.x - d->x, dz = plr.z - d->z;
        if (dx < 0) dx = -dx;
        if (dz < 0) dz = -dz;
        fix cheb = dx > dz ? dx : dz;
        fix dy = plr.y - d->y;
        if (dy < 0) dy = -dy;
        if (cheb < 3072 && dy < 2 * FIX_ONE) {
            if (inv_gain(d->block, 1) == 0) {   /* stored (0 leftover) */
                plr.name_ticks = 75;            /* show what was picked up */
                plr.name_block = d->block;
                d->alive = 0;
            }                                   /* else inventory full: linger */
        }
    }
}

/* coarse line-of-sight: sample eye->drop; hidden behind walls = skip.
 * This is the ONLY occlusion test for drops (cubes and sprites alike): no
 * per-pixel depth exists, so a drop whose centre is visible draws whole,
 * even where a nearer block edge overlaps its rect (same as mob boxes). */
static bool drop_visible(const camera_t *cam, const drop_t *d)
{
    fix dx = d->x - cam->x, dy = (d->y + D_HEIGHT / 2) - cam->y,
        dz = d->z - cam->z;
    for (int s = 1; s < 12; s++) {
        fix t = (fix)(s * 341);
        int x = FIX_TO_INT(cam->x + FMUL(dx, t));
        int y = FIX_TO_INT(cam->y + FMUL(dy, t));
        int z = FIX_TO_INT(cam->z + FMUL(dz, t));
        if (x == FIX_TO_INT(d->x) && z == FIX_TO_INT(d->z) &&
            y <= FIX_TO_INT(d->y + D_HEIGHT))
            return true;
        if (dsolid(world_get(x, y, z)))
            return false;
    }
    return true;
}

void drops_draw(uint8_t *fb, const camera_t *cam)
{
    for (int i = 0; i < DROP_MAX; i++) {
        drop_t *d = &drops[i];
        d->bb[0] = 1;
        d->bb[2] = 0;                        /* default: nothing drawn */
        if (!d->alive)
            continue;
        fix dx = d->x - cam->x, dz = d->z - cam->z;
        if (dx < 0) dx = -dx;
        if (dz < 0) dz = -dz;
        if ((dx > dz ? dx : dz) > INT_TO_FIX(16))
            continue;
        if (!drop_visible(cam, d))
            continue;
        /* hover + bob (deterministic from age) */
        fix bob = SIN((d->age * 3) & 255) >> 4;
        fix by = d->y + 512 + bob;
        render_bbox_reset();
        if (d->block < B_COUNT) {
            /* block: mini cube with its exact top(avg)/side(tex) tiles; a
             * slightly larger black box behind it gives a silhouette so
             * natural blocks read against same-coloured terrain */
            render_box(fb, d->x, by - 96, d->z, D_HALF + 96, D_HEIGHT + 192,
                       PAL_BLACK, NULL);
            render_box(fb, d->x, by, d->z, D_HALF, D_HEIGHT,
                       tex_avg[block_tex[d->block][0]],
                       tex_data[block_tex[d->block][1]]);
        } else {
            /* item (UI U3): the icon as a flat sprite facing the camera,
             * centred on the cube's centre, unlit (MC item sprites are
             * unshaded), no silhouette (MC has none), sized 1/depth and
             * clamped to D_SPRITE_MIN..MAX render px */
            int sx, sy;
            fix depth;
            if (!render_project(d->x, by + D_HEIGHT / 2, d->z,
                                &sx, &sy, &depth))
                continue;
            int size = (rfocal * D_SPRITE_W + depth / 2) / depth;
            if (size < D_SPRITE_MIN) size = D_SPRITE_MIN;
            if (size > D_SPRITE_MAX) size = D_SPRITE_MAX;
            render_sprite16(sx, sy, size,
                            tex_data[items_tile[d->block - ITEM_BASE]],
                            TEX_KEY);
        }
        if (rbb_x0 <= rbb_x1) {
            d->bb[0] = (int16_t)rbb_x0;
            d->bb[1] = (int16_t)rbb_y0;
            d->bb[2] = (int16_t)rbb_x1;
            d->bb[3] = (int16_t)rbb_y1;
        }
    }
}
