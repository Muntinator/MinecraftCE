/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * ui.c — menu / page drawing shared by the calc shell (main.c) and the host
 * harness. Pure framebuffer writes; state comes in as arguments or the
 * settings globals. Layout unchanged from the graphx/TI-font era except the
 * text, which is now the Minecraft font (mcfont.c) in MC capitalisation.
 */

#include <string.h>

#include "ui.h"
#include "mcfont.h"
#include "palette.h"
#include "textures.h"
#include "render.h"
#include "player.h"
#include "save.h"
#include "mob.h"
#include "mclogo.h"
#ifdef __ez80__
#include <compression.h>
#endif

/* push3 DIET: the logo is stored ZX0-compressed (3.7 KB instead of 15.4 KB
 * of program image = RAM in game) and decoded into render_scratch here.
 * render_scratch (19200 B) is free whenever the logo is drawn: only the
 * title screens call this, after render_present has consumed the backdrop
 * frame, and game_session compose_invalidate()s before its first frame. */
_Static_assert(MCLOGO_W * MCLOGO_ROWS <= (SCREEN_W / 2) * (SCREEN_H / 2),
               "logo must fit render_scratch");
void ui_logo(uint8_t *fb, int y)
{
    const unsigned char *p = render_scratch;
    zx0_Decompress(render_scratch, mclogo_zx0);
    int x0 = (SCREEN_W - MCLOGO_W) / 2;
    for (int r = 0; r < MCLOGO_ROWS; r++) {
        uint8_t *row = fb + (y + r) * SCREEN_W + x0;
        for (int c = 0; c < MCLOGO_W; c++, p++)
            if (*p != 255)
                row[c] = *p;
    }
}

void ui_tile_dirt(uint8_t *fb, int y0, int y1)
{
    const uint8_t *d = tex_data[T_DIRT];
    for (int y = y0; y < y1; y++) {
        uint8_t *row = fb + y * SCREEN_W;
        if (y - 16 >= y0) {          /* the pattern repeats every 16 rows: */
            memcpy(row, row - 16 * SCREEN_W, SCREEN_W);   /* copy (15x less */
            continue;                                     /* per-pixel work) */
        }
        const uint8_t *tr = d + (y & 15) * 16;
        for (int x = 0; x < SCREEN_W; x++)
            row[x] = (uint8_t)(tr[x & 15] | 128);
    }
}

/* grey bevelled button; label black (flat) with > < markers when selected */
void ui_button(uint8_t *fb, int y, const char *label, bool sel)
{
    int x = (SCREEN_W - BTN_W) / 2;
    uint8_t fill = sel ? (PAL_WHITE | 64) : (PAL_WHITE | 128);
    for (int r = 1; r < BTN_H - 1; r++)
        memset(fb + (y + r) * SCREEN_W + x + 1, fill, BTN_W - 2);
    memset(fb + y * SCREEN_W + x, PAL_BLACK, BTN_W);
    memset(fb + (y + BTN_H - 1) * SCREEN_W + x, PAL_BLACK, BTN_W);
    for (int r = 0; r < BTN_H; r++) {
        fb[(y + r) * SCREEN_W + x] = PAL_BLACK;
        fb[(y + r) * SCREEN_W + x + BTN_W - 1] = PAL_BLACK;
    }
    memset(fb + (y + 1) * SCREEN_W + x + 1, PAL_WHITE, BTN_W - 2);
    memset(fb + (y + BTN_H - 2) * SCREEN_W + x + 1, PAL_WHITE | 192,
           BTN_W - 2);
    int w = mc_text_width(label, 1);
    int tx = SCREEN_W / 2 - w / 2;
    mc_text(fb, tx, y + 5, label, PAL_BLACK, 1);
    if (sel) {
        mc_text(fb, tx - 12, y + 5, ">", PAL_BLACK, 1);
        mc_text(fb, tx + w + 7, y + 5, "<", PAL_BLACK, 1);
    }
}

void ui_buttons(uint8_t *fb, const char *const *items, int n, int y0, int sel)
{
    for (int i = 0; i < n; i++)
        ui_button(fb, y0 + i * BTN_PITCH, items[i], i == sel);
}

/* MC title corners: version bottom-left, credit bottom-right (y = H - 10) */
void ui_title_text(uint8_t *fb)
{
    static const char cred[] = "Everyday Code";
#ifndef BUILD_ID
#define BUILD_ID "host"          /* the makefile stamps the calc build */
#endif
    mc_text(fb, 2, SCREEN_H - 10, "Alpha 2.2 " BUILD_ID, PAL_WHITE, 1);
    mc_text(fb, SCREEN_W - 2 - mc_text_width(cred, 1), SCREEN_H - 10, cred,
            PAL_WHITE, 1);
}

void ui_banner(uint8_t *fb, int y, const char *s, int scale)
{
    mc_text_center(fb, y, s, PAL_WHITE, scale);
}

/* boot/loading: white page, dark caption, red bar (U6 restyles it) */
void ui_load_screen(uint8_t *fb, const char *stage, int pct)
{
    memset(fb, PAL_WHITE, (size_t)SCREEN_W * SCREEN_H);
    mc_text_center(fb, 100, stage, PAL_BLACK, 1);   /* flat: white page */
    int bx = 60, by = 128, bw = 200, bh = 8;
    memset(fb + (by - 1) * SCREEN_W + bx - 1, PAL_WHITE | 192, bw + 2);
    memset(fb + (by + bh) * SCREEN_W + bx - 1, PAL_WHITE | 192, bw + 2);
    for (int y = by; y < by + bh; y++) {
        fb[y * SCREEN_W + bx - 1] = PAL_WHITE | 192;
        fb[y * SCREEN_W + bx + bw] = PAL_WHITE | 192;
        memset(fb + y * SCREEN_W + bx, pal_red_idx, (size_t)(pct * bw / 100));
    }
}

/* grey panel with a black frame and a white top bevel */
static void ui_panel(uint8_t *fb, int x0, int y0, int x1, int y1)
{
    int w = x1 - x0;
    for (int y = y0; y < y1; y++) {
        memset(fb + y * SCREEN_W + x0, PAL_WHITE | 128, (size_t)w);
        fb[y * SCREEN_W + x0] = PAL_BLACK;
        fb[y * SCREEN_W + x1 - 1] = PAL_BLACK;
    }
    memset(fb + y0 * SCREEN_W + x0, PAL_BLACK, (size_t)w);
    memset(fb + (y1 - 1) * SCREEN_W + x0, PAL_BLACK, (size_t)w);
    memset(fb + (y0 + 1) * SCREEN_W + x0 + 1, PAL_WHITE, (size_t)(w - 2));
}

/* Two aligned columns (key, action), grouped. A NULL key marks a group
 * header (the action string is the header label). */
void ui_controls_page(uint8_t *fb)
{
    struct row { const char *key, *act; };
    static const struct row rows[] = {
        { NULL,        "Movement" },
        { "Arrows",    "Walk (2x-tap Up = sprint)" },
        { "Y= Win Zoom Trace", "Look around" },
        { "2nd",       "Jump / swim up" },
        { NULL,        "Actions" },
        { "Del",       "Break block / attack" },
        { "Mode",      "Place block" },
        { "Graph",     "Next hotbar block" },
        { "1 - 9",     "Select hotbar slot" },
        { "Alpha",     "Inventory" },
        { "Vars",      "Crafting" },
        { NULL,        "System" },
        { "Stat",      "Settings" },
        { "X,T,0,n",   "Debug HUD" },
        { "+ / -",     "Render distance" },
        { "Clear",     "Pause" },
    };
    ui_panel(fb, 24, 16, 296, 224);
    mc_text_center(fb, 22, "Controls", PAL_BLACK, 1);
    /* 16 rows at a 10 px pitch (MC glyphs are 8 px + shadow) leave the
     * footer clear; the action column starts at 142 so the longest action
     * ends inside the panel */
    int y = 36;
    for (unsigned i = 0; i < sizeof rows / sizeof rows[0]; i++) {
        if (!rows[i].key) {
            mc_text(fb, 34, y, rows[i].act, PAL_WHITE, 1);
        } else {
            mc_text(fb, 42, y, rows[i].key, PAL_BLACK, 1);
            mc_text(fb, 142, y, rows[i].act, PAL_BLACK, 1);
        }
        y += 10;
    }
    mc_text_center(fb, 208, "2nd / Clear: Back", PAL_WHITE, 1);
}

static const char *const opt_names[] = {
    "Render Distance", "Day/Night Cycle", "Mobs", "Game Mode", "Textures",
    "Graphics", "Viewport", "Auto-Jump", "Controls...", "Done" };
static const char *const dn_names[3] = { "Off", "On", "Fast" };
static const char *const gm_names[3] = { "Quality", "Fast", "Ultra" };
static const char *const vp_names[3] = { "Full", "160x120", "80x60" };
static const char *const onoff[2] = { "Off", "On" };

void ui_settings_page(uint8_t *fb, const uint8_t *items, int n, int sel)
{
    /* panel sized to the row count (no footer hint -> no collision) */
    int last_ry = 40 + (n - 1) * 19;
    ui_panel(fb, 34, 14, 286, last_ry + 15);
    mc_text_center(fb, 22, "Settings", PAL_BLACK, 1);

    char num[4];
    for (int i = 0; i < n; i++) {
        int opt = items[i];
        int ry = 40 + i * 19;
        if (i == sel)
            for (int y = ry - 4; y < ry + 12; y++)
                memset(fb + y * SCREEN_W + 40, PAL_WHITE | 64, 240);
        mc_text(fb, 48, ry, opt_names[opt], PAL_BLACK, 1);
        const char *val = NULL;
        switch (opt) {
        case OPT_RENDER:
            num[0] = (char)('0' + view_radius / 10);
            num[1] = (char)('0' + view_radius % 10);
            num[2] = 0;
            val = num;
            break;
        case OPT_DAYNIGHT: val = dn_names[g_daynight]; break;
        case OPT_MOBS:     val = onoff[g_mobs_on & 1]; break;
        case OPT_GAMEMODE: val = plr.mode == MODE_CREATIVE ? "Creative"
                                                           : "Survival"; break;
        case OPT_TEXTURES: val = onoff[g_textures & 1]; break;
        case OPT_GRAPHICS: val = gm_names[g_gfxmode]; break;
        case OPT_VIEWPORT: val = vp_names[g_viewport]; break;
        case OPT_AUTOJUMP: val = onoff[g_autojump & 1]; break;
        }
        if (val) {
            mc_text(fb, 212, ry, val, PAL_BLACK, 1);
            if (i == sel) {
                mc_text(fb, 203, ry, "<", PAL_BLACK, 1);
                mc_text(fb, 212 + mc_text_width(val, 1) + 3, ry, ">",
                        PAL_BLACK, 1);
            }
        }
    }
}

/* combined create-world screen: 0 type, 1 mode, 2 the Create button */
void ui_create_page(uint8_t *fb, int sel, uint8_t wtype, uint8_t wmode)
{
    ui_tile_dirt(fb, 0, SCREEN_H);
    mc_text_center(fb, 36, "Create New World", PAL_WHITE, 2);

    const char *lbl[2] = { "World Type", "Game Mode" };
    const char *val[2] = { wtype == 2 ? "Skyblock"
                           : wtype ? "Superflat" : "Normal",
                           wmode ? "Survival" : "Creative" };
    for (int i = 0; i < 2; i++) {
        int y = 84 + i * 22;
        uint8_t c = sel == i ? PAL_WHITE : (PAL_WHITE | 64);
        mc_text(fb, 84, y, lbl[i], c, 1);
        mc_text(fb, 184, y, val[i], c, 1);
        if (sel == i) {
            mc_text(fb, 174, y, "<", c, 1);
            mc_text(fb, 184 + mc_text_width(val[i], 1) + 4, y, ">", c, 1);
        }
    }
    ui_button(fb, 140, "Create World", sel == 2);
    if (wtype == 2)          /* push3 S1: Skyblock turns mobs on */
        mc_text_center(fb, 180, "Floating island, mobs on", PAL_WHITE | 64, 1);
    mc_text_center(fb, 216, "Clear: Back", PAL_WHITE | 64, 1);
}

/* world-slot select page (its own dirt screen) */
void ui_select_page(uint8_t *fb, const char *const *items, int n, int sel)
{
    ui_tile_dirt(fb, 0, SCREEN_H);
    mc_text_center(fb, 34, "Select World", PAL_WHITE, 2);
    ui_buttons(fb, items, n, 72, sel);
    mc_text_center(fb, 220, "Clear: Back", PAL_WHITE | 64, 1);
}
