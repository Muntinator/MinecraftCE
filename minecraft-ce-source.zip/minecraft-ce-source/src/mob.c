/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
/*
 * mob.c — mobs: hostile creepers/zombies (chase, attack) and passive pigs
 * (wander, flee). Two boot mobs plus a deterministic spawning system: night
 * hostiles in survival, pigs any time. All math is fix/int24 and every RNG
 * draw is deterministic, so host playback and the calculator stay in parity.
 */

#include <stddef.h>

#include "mob.h"
#include "world.h"
#include "palette.h"
#include "textures.h"
#include "player.h"
#include "drop.h"
#include "items.h"
#include "save.h"        /* g_daynight — drives the night spawn window */
#include "lut.h"
#include "light.h"       /* push3 S1: dark-cell hostile rule */

mob_t mobs[MOB_MAX];
uint8_t g_mobs_on = 1;

/* wander/behaviour RNG (the boot mobs draw this in a fixed order the m4
 * play golden depends on); the spawn system uses its OWN stream so spawn
 * rolls never perturb existing mobs' motion */
static uint32_t mob_lcg;
static uint32_t spawn_lcg;
static uint32_t g_worldtick;    /* sim tick counter; spawn cadence */
/* push3 MOB: THE day clock (was main.c's local gtime). The mob night used
 * its own g_worldtick phase starting at midnight while the sky started at
 * noon (gtime 8 << 9), so hostiles spawned in the first 68 s of daylight
 * and never in the real night (host --mobcensus: 0 s overlap in 20 min). */
uint16_t g_daytime;

/* push3 MOB: host census hooks (harness --mobcensus defines MOB_STAT before
 * including this file); compiles to nothing on the calculator */
enum { MS_PIG_TRY, MS_HOST_TRY, MS_NEAR, MS_NOGRASS, MS_PICKFAIL, MS_NOSLOT,
       MS_SPAWN, MS_DESPAWN, MS_EXPLODE, MS_VOID };
#ifndef MOB_STAT
#define MOB_STAT(ev, a) ((void)0)
#endif

static uint32_t mrnd(void)
{
    mob_lcg = mob_lcg * 1664525u + 1013904223u;
    return mob_lcg;
}

static uint32_t srnd(void)
{
    spawn_lcg = spawn_lcg * 1664525u + 1013904223u;
    return spawn_lcg;
}

#define M_HALF   1024      /* 0.25 block */
#define M_HEIGHT 7373      /* 1.8 blocks */
#define M_SPEED  240
#define M_GRAV   82
/* hop impulse when a walking mob is blocked and grounded. The old 700 could
 * not clear a 1-block step: continuous peak 700^2/(2*82) ~ 2988 < 4096 (one
 * block in 12.12). 950 gives a peak ~5038 discrete (~1.23 blocks) and reaches
 * +4096 by tick 7, matching the player's own JUMP_V=920 physics so mobs climb
 * 1-block steps. (Proven on the host --mobstep mode.) */
#define M_HOP    950

/* spawn tuning (ticks at 30 Hz). PIG_PERIOD is deliberately > the 155-tick
 * m4 play script so no pig spawns during that deterministic run — the play
 * golden stays byte-identical instead of needing a regen. */
#define PIG_PERIOD     300         /* ~10 s between pig spawn attempts (kept
                                    * >155 so no pig spawns during the m4 run) */
#define HOSTILE_PERIOD 60          /* ~2 s between hostile spawn attempts */
#define HOSTILE_MAX    6
#define PIG_MAX        3

static bool msolid(uint8_t b)
{
    return b != B_AIR && !block_liquid(b);
}

/* push3 MOB: the map edge is a wall for mobs. world_get() is air outside
 * the map (bedrock below y 0), so pigs walked off the edge and roamed the
 * void floor forever, still counting toward PIG_MAX: after the first three
 * wandered off no pig ever spawned again (host --mobcensus). */
static bool mob_out(fix px, fix pz)
{
    return FIX_TO_INT(px - M_HALF) < 0 || FIX_TO_INT(px + M_HALF - 1) >= WORLD_SX ||
           FIX_TO_INT(pz - M_HALF) < 0 || FIX_TO_INT(pz + M_HALF - 1) >= WORLD_SZ;
}

static bool mob_blocked(fix px, fix py, fix pz)
{
    int x0 = FIX_TO_INT(px - M_HALF), x1 = FIX_TO_INT(px + M_HALF - 1);
    int z0 = FIX_TO_INT(pz - M_HALF), z1 = FIX_TO_INT(pz + M_HALF - 1);
    if (mob_out(px, pz))
        return true;
    int y0 = FIX_TO_INT(py), y1 = FIX_TO_INT(py + M_HEIGHT - 1);
    for (int x = x0; x <= x1; x++)
        for (int z = z0; z <= z1; z++)
            for (int y = y0; y <= y1; y++)
                if (msolid(world_get(x, y, z)))
                    return true;
    return false;
}

static int8_t kind_health(uint8_t kind)
{
    return kind == K_ZOMBIE ? 3 : kind == K_PIG ? 3 : 2;
}

void mobs_spawn(uint32_t seed)
{
    mob_lcg = seed ^ 0xBEEFu;
    spawn_lcg = seed ^ 0x5EEDu;
    g_worldtick = 0;
    g_daytime = 8 << 9;              /* noon (the shell's old gtime start) */
    for (int i = 0; i < MOB_MAX; i++)
        mobs[i].alive = 0;
    if (g_worldtype == 2)
        return;             /* push3 S1: Skyblock starts with no mobs */
    /* two boot mobs: a creeper (0) and a zombie (1). The mrnd() draw order
     * here is exactly the pre-M22 order so their spawn cells are unchanged. */
    for (int i = 0; i < 2; i++) {
        int x = 4 + (int)(mrnd() % (WORLD_SX - 8));
        int z = 4 + (int)(mrnd() % (WORLD_SZ - 8));
        int h = world_height[x * WORLD_SZ + z];
        mobs[i].x = INT_TO_FIX(x) + FIX_ONE / 2;
        mobs[i].z = INT_TO_FIX(z) + FIX_ONE / 2;
        mobs[i].y = INT_TO_FIX(h + 1);
        mobs[i].vy = 0;
        mobs[i].yaw = (uint8_t)mrnd();
        mobs[i].alive = 1;
        mobs[i].kind = (i == 1) ? K_ZOMBIE : K_CREEPER;
        mobs[i].hurt_cd = 0;
        mobs[i].fuse = 0;
        mobs[i].flee = 0;
        mobs[i].health = kind_health(mobs[i].kind);
        mobs[i].flash = 0;
    }
}

/* push3 MOB: a real session (main.c game_session) starts with the two boot
 * mobs as pigs. As a creeper + zombie in daylight they were despawned at
 * once, or (within 6 blocks) blew up / attacked at the spawn point
 * (census: seed 1 creeper explodes 2 s in); the demo/test builds keep the
 * pair. */
void mobs_boot_pigs(void)
{
    mobs[0].kind = mobs[1].kind = K_PIG;
    mobs[0].health = mobs[1].health = 3;     /* kind_health(K_PIG) */
}

/* pick a spawn column 8..24 blocks (Chebyshev) from the player, in bounds.
 * push3 MOB: the cell is drawn from the in-bounds map (1..30 on each axis)
 * and cells nearer than 8 / farther than 24 are redrawn. The old code drew a
 * signed 8..24 offset, and with the player anywhere but a corner most draws
 * fell off the 32x32 map (census: up to 70% of draws wasted), so the
 * survivors hugged the far edge.
 * NB: the LCG's low bit alternates deterministically, so fields are taken
 * from HIGH bits of one draw — low bits would correlate the two axes. */
static bool pick_spawn_cell(int *ox, int *oy, int *oz, bool need_grass)
{
    int px = FIX_TO_INT(plr.x), pz = FIX_TO_INT(plr.z);
    for (int tries = 0; tries < 12; tries++) {
        uint32_t r = srnd();
        int x = 1 + (((uint8_t)(r >> 16) * (WORLD_SX - 2)) >> 8); /* 1..30 */
        int z = 1 + (((uint8_t)(r >> 24) * (WORLD_SZ - 2)) >> 8);
        int dx = x - px, dz = z - pz;
        if (dx < 0) dx = -dx;
        if (dz < 0) dz = -dz;
        if (dz > dx) dx = dz;
        if (dx < 8 || dx > 24) {
            MOB_STAT(MS_NEAR, 0);
            continue;
        }
        /* push3 S1: stand on the column's ACTUAL top block (world_height is
         * frozen at gen: it cannot see a platform the player built and is 0
         * in the Skyblock void); no spawning on leaves, torches, liquids or
         * the void. Pigs stand only on grass; in Skyblock a hostile needs a
         * dark cell (block light 0: the mob-platform rule). A rejected cell
         * keeps spending the draw budget on this attempt, so spawns are
         * robust to spawn-RNG cadence (HOSTILE_PERIOD) shifts. */
        int y = WORLD_SY - 1, i = WORLD_IDX(x, 0, z);
        while (y && world[i + y] == B_AIR)
            y--;
        uint8_t t = world[i + y];
        i += y + 1;              /* the cell above: light_get(x, y + 1, z) by
                                  * index (x, z are in bounds; for a top at
                                  * y = 11 this reads the next column's
                                  * y = 0 cell, a harmless approximation) */
        if (t == B_AIR || t == B_LEAVES || t == B_TORCH || t == B_SAPLING ||
            block_liquid(t) ||
            (need_grass ? t != B_GRASS
                        : g_worldtype == 2 &&
                          ((light_packed[i >> 2] >> ((i & 3) << 1)) & 3))) {
            MOB_STAT(MS_NOGRASS, 0);
            continue;
        }
        *ox = x; *oy = y + 1; *oz = z;
        return true;
    }
    MOB_STAT(MS_PICKFAIL, need_grass);
    return false;
}

static void spawn_mob(uint8_t kind)
{
    int slot = -1;
    for (int i = 0; i < MOB_MAX; i++)
        if (!mobs[i].alive) { slot = i; break; }
    if (slot < 0) {
        MOB_STAT(MS_NOSLOT, kind);
        return;
    }
    int x, y, z;
    if (!pick_spawn_cell(&x, &y, &z, kind == K_PIG))
        return;
    mob_t *m = &mobs[slot];
    m->x = INT_TO_FIX(x) + FIX_ONE / 2;
    m->z = INT_TO_FIX(z) + FIX_ONE / 2;
    m->y = INT_TO_FIX(y);
    m->vy = 0;
    m->yaw = (uint8_t)srnd();
    m->alive = 1;
    m->kind = kind;
    m->hurt_cd = 0;
    m->fuse = 0;
    m->flee = 0;
    m->health = kind_health(kind);
    m->flash = 0;
    MOB_STAT(MS_SPAWN, slot);
}

/* is it night for spawn purposes? Mirrors the shell's brightness phase
 * (main.c: phase = (gtime>>9)&31, brightness low = night) so hostiles
 * appear when the world is dark. g_daynight 0 = always day. */
static bool is_night(void)
{
    if (!g_daynight)
        return false;
    uint8_t phase = (uint8_t)((g_daytime >> 9) & 31);
    uint8_t b = phase < 16 ? phase : (uint8_t)(31 - phase);
    return b < 4;
}

static void mobs_spawn_tick(void)
{
    int hostiles = 0, pigs = 0;
    for (int i = 0; i < MOB_MAX; i++) {
        if (!mobs[i].alive)
            continue;
        if (mobs[i].kind == K_PIG) pigs++;
        else hostiles++;
    }
    bool night = is_night();

    /* dawn despawn: hostiles vanish in daylight unless the fight is close */
    if (!night) {
        for (int i = 0; i < MOB_MAX; i++) {
            if (!mobs[i].alive || mobs[i].kind == K_PIG)
                continue;
            fix dx = plr.x - mobs[i].x, dz = plr.z - mobs[i].z;
            fix adx = dx < 0 ? -dx : dx, adz = dz < 0 ? -dz : dz;
            if ((adx > adz ? adx : adz) > INT_TO_FIX(6)) {
                MOB_STAT(MS_DESPAWN, i);
                mobs[i].alive = 0;
                hostiles--;
            }
        }
    }

    /* pigs: any time of day, survival AND creative */
    if (pigs < PIG_MAX && (g_worldtick % PIG_PERIOD) == 0) {
        MOB_STAT(MS_PIG_TRY, pigs);
        spawn_mob(K_PIG);
    }

    /* hostiles: night + survival only */
    if (night && plr.mode == MODE_SURVIVAL && hostiles < HOSTILE_MAX &&
        (g_worldtick % HOSTILE_PERIOD) == 0) {
        MOB_STAT(MS_HOST_TRY, hostiles);
        spawn_mob((srnd() & 0x10000u) ? K_ZOMBIE : K_CREEPER);
    }
}

/* sample the look ray every 1/4 block out to 3.5 blocks; a solid block
 * ends the ray (no punching through walls) */
int mobs_pick(fix ox, fix oy, fix oz, fix dx, fix dy, fix dz)
{
    for (int s = 1; s <= 14; s++) {
        fix t = (fix)(s * 1024);
        fix px = ox + FMUL(dx, t);
        fix py = oy + FMUL(dy, t);
        fix pz = oz + FMUL(dz, t);
        for (int i = 0; i < MOB_MAX; i++) {
            const mob_t *m = &mobs[i];
            if (!m->alive)
                continue;
            fix ax = px - m->x, az = pz - m->z;
            if (ax < 0) ax = -ax;
            if (az < 0) az = -az;
            if (ax < M_HALF + 256 && az < M_HALF + 256 &&
                py >= m->y && py <= m->y + M_HEIGHT)
                return i;
        }
        if (msolid(world_get(FIX_TO_INT(px), FIX_TO_INT(py),
                             FIX_TO_INT(pz))))
            return -1;
    }
    return -1;
}

/* spawn the kind's death drop at the corpse cell (explosion deaths skip
 * this — matches the block-explosion "no drop" rule) */
static void mob_death_drop(const mob_t *m)
{
    int bx = FIX_TO_INT(m->x), by = FIX_TO_INT(m->y), bz = FIX_TO_INT(m->z);
    if (m->kind == K_CREEPER) {
        drop_spawn(bx, by, bz, I_GUNPOWDER);          /* killed, not exploded */
    } else if (m->kind == K_ZOMBIE) {
        int n = (int)(mrnd() % 3);                    /* 0-2 sticks */
        for (int k = 0; k < n; k++)
            drop_spawn(bx, by, bz, I_STICK);
    } else {                                          /* pig */
        drop_spawn(bx, by, bz, I_PORKCHOP);
    }
}

void mob_punch(int i, int dmg)
{
    mob_t *m = &mobs[i];
    if (dmg < 1) dmg = 1;
    m->health = (int8_t)(m->health - dmg);
    if (m->health <= 0) {
        m->alive = 0;               /* mid-fuse creepers still die (no boom) */
        mob_death_drop(m);
        return;
    }
    m->flash = 4;
    if (m->kind == K_PIG)
        m->flee = 60;               /* pigs bolt for ~2 s when hit */
    /* knockback: shove away from the player + hop */
    fix dx = m->x - plr.x, dz = m->z - plr.z;
    fix ax = dx < 0 ? -dx : dx, az = dz < 0 ? -dz : dz;
    fix cheb = ax > az ? ax : az;
    if (cheb > 256) {
        fix kx = FDIV(dx, cheb) >> 1;   /* ~0.5 block along the shove */
        fix kz = FDIV(dz, cheb) >> 1;
        if (!mob_blocked(m->x + kx, m->y, m->z))
            m->x += kx;
        if (!mob_blocked(m->x, m->y, m->z + kz))
            m->z += kz;
    }
    m->vy = 500;
}

void mobs_tick(void)
{
    /* the day clock runs with mobs off too (it drives the sky) */
    g_daytime += g_daynight == 2 ? 8 : g_daynight;
    if (!g_mobs_on)
        return;
    g_worldtick++;
    mobs_spawn_tick();
    for (int i = 0; i < MOB_MAX; i++) {
        mob_t *m = &mobs[i];
        if (!m->alive)
            continue;

        fix dxp = plr.x - m->x, dzp = plr.z - m->z;
        fix adx = dxp < 0 ? -dxp : dxp, adz = dzp < 0 ? -dzp : dzp;
        fix cheb = adx > adz ? adx : adz;
        bool hostile = (m->kind != K_PIG);

        if (m->kind == K_PIG && m->flee) {
            /* flee: steer AWAY from the player */
            m->flee--;
            fix fx = SIN(m->yaw), fz = COS(m->yaw);
            fix cross = FMUL(fx, -dzp) - FMUL(fz, -dxp);
            m->yaw = (uint8_t)(m->yaw + (cross > 0 ? -4 : 4));
        } else if (hostile && plr.mode == MODE_SURVIVAL &&
                   cheb < INT_TO_FIX(8)) {
            /* chase: steer yaw toward the player (coarse) */
            fix fx = SIN(m->yaw), fz = COS(m->yaw);
            fix cross = FMUL(fx, dzp) - FMUL(fz, dxp);
            m->yaw = (uint8_t)(m->yaw + (cross > 0 ? -4 : 4));
        } else if ((mrnd() & 31) == 0) {
            m->yaw = (uint8_t)(m->yaw + (int8_t)(mrnd() & 63) - 32);
        }

        /* walk forward; hop when blocked and grounded */
        fix vx = FMUL(SIN(m->yaw), M_SPEED);
        fix vz = FMUL(COS(m->yaw), M_SPEED);
        if (mob_out(m->x + vx, m->z + vz)) {
            m->yaw ^= 0x80;             /* turn round at the map edge */
            vx = -vx;
            vz = -vz;
        }
        bool grounded = mob_blocked(m->x, m->y - 64, m->z);
        fix nx = m->x + vx;
        if (!mob_blocked(nx, m->y, m->z))
            m->x = nx;
        else if (grounded)
            m->vy = M_HOP;
        fix nz = m->z + vz;
        if (!mob_blocked(m->x, m->y, nz))
            m->z = nz;
        else if (grounded)
            m->vy = M_HOP;

        m->vy -= M_GRAV;
        if (m->vy < -1400)
            m->vy = -1400;
        fix ny = m->y + m->vy;
        if (mob_blocked(m->x, ny, m->z)) {
            if (m->vy < 0)
                ny = INT_TO_FIX(FIX_TO_INT(ny)) + FIX_ONE;
            else
                ny = m->y;
            m->vy = 0;
            m->y = ny;
        } else {
            m->y = ny;
        }
        /* fell out of the world: only the Skyblock void gets here
         * (elsewhere world_get(y < 0) is a bedrock floor that mob_blocked
         * stands on, and the map edge is a wall), so push3 S1 replaced the
         * old unreachable teleport-to-top with the void despawn */
        if (m->y < -2 * FIX_ONE) {
            MOB_STAT(MS_VOID, i);
            m->alive = 0;
            continue;
        }

        if (m->hurt_cd)
            m->hurt_cd--;
        if (m->flash)
            m->flash--;

        if (m->kind == K_CREEPER) {
            /* fuse when close, then explode (drops nothing) */
            if (plr.mode == MODE_SURVIVAL && cheb < (FIX_ONE * 5) / 2) {
                if (++m->fuse >= 30) {
                    MOB_STAT(MS_EXPLODE, i);
                    m->alive = 0;
                    do_explosion(FIX_TO_INT(m->x),
                                 FIX_TO_INT(m->y) + 1,
                                 FIX_TO_INT(m->z));
                }
            } else if (m->fuse) {
                m->fuse--;
            }
        } else if (m->kind == K_ZOMBIE) {
            /* melee contact damage */
            if (plr.mode == MODE_SURVIVAL && !m->hurt_cd &&
                cheb < (FIX_ONE * 3) / 4 &&
                plr.y < m->y + M_HEIGHT && m->y < plr.y + 7373) {
                player_hurt(1);          /* N6: armour reduces mob melee */
                m->hurt_cd = 30;
            }
        }
        /* pig: no attack */
    }
}

/* crude line-of-sight: sample the segment eye->mob every ~0.7 block */
static bool mob_visible(const camera_t *cam, const mob_t *m)
{
    fix dx = m->x - cam->x, dy = (m->y + M_HEIGHT / 2) - cam->y,
        dz = m->z - cam->z;
    for (int s = 1; s < 12; s++) {
        fix t = (fix)(s * 341);              /* s/12 in 12.12 */
        int x = FIX_TO_INT(cam->x + FMUL(dx, t));
        int y = FIX_TO_INT(cam->y + FMUL(dy, t));
        int z = FIX_TO_INT(cam->z + FMUL(dz, t));
        if (x == FIX_TO_INT(m->x) && z == FIX_TO_INT(m->z) &&
            y >= FIX_TO_INT(m->y))
            return true;                     /* reached the mob's cell */
        if (msolid(world_get(x, y, z)))
            return false;
    }
    return true;
}

#define M_BODY_H 4915   /* 1.2 blocks */
#define M_HEAD_H 2458   /* 0.6 blocks; body + head = collision height */

/* pig: a low, broad body with a snout box out the front (NOT the tall
 * humanoid stack the creeper/zombie use) */
#define PIG_HALF   1500     /* ~0.37 block: broad */
#define PIG_BODY_H 3277     /* ~0.8 block: low */
#define PIG_HEAD   900      /* ~0.22 block half */
#define PIG_HEAD_H 2200     /* ~0.54 block */

static void draw_pig(uint8_t *fb, mob_t *m, bool flash)
{
    /* facing quadrant: q 0=+z 1=+x 2=-z 3=-x (matches mobs_tick's yaw 0 = +z) */
    int q = ((m->yaw + 32) >> 6) & 3;
    int sx = (rcam.cx > m->x) ? 1 : -1;
    int sz = (rcam.cz > m->z) ? 1 : -1;
    int face_x = (q == 1) ? 1 : (q == 3) ? -1 : 0;
    int face_z = (q == 0) ? 1 : (q == 2) ? -1 : 0;
    bool xfront = face_x && sx == face_x;
    bool zfront = face_z && sz == face_z;

    /* head sits at the front edge of the body */
    fix hx = m->x, hz = m->z;
    if (q == 0) hz += PIG_HALF; else if (q == 1) hx += PIG_HALF;
    else if (q == 2) hz -= PIG_HALF; else hx -= PIG_HALF;

    uint8_t body_base = tex_avg[T_PIG_BODY], head_base = tex_avg[T_PIG_FACE];
    const uint8_t *body = tex_data[T_PIG_BODY];
    const uint8_t *head_x = tex_data[xfront ? T_PIG_FACE : T_PIG_SIDE];
    const uint8_t *head_z = tex_data[zfront ? T_PIG_FACE : T_PIG_SIDE];
    if (flash) {
        body_base = head_base = PAL_WHITE;
        body = head_x = head_z = NULL;
    }
    render_box_faces(fb, m->x, m->y, m->z, PIG_HALF, PIG_BODY_H,
                     body_base, body, body);
    render_box_faces(fb, hx, m->y + PIG_BODY_H / 3, hz, PIG_HEAD, PIG_HEAD_H,
                     head_base, head_x, head_z);
}

void mobs_draw(uint8_t *fb, const camera_t *cam)
{
    for (int i = 0; i < MOB_MAX; i++) {
        mob_t *m = &mobs[i];
        m->bb[0] = 1;
        m->bb[2] = 0;                        /* default: nothing drawn */
        if (!m->alive || !g_mobs_on)         /* mobs off = invisible too */
            continue;
        fix dx = m->x - cam->x, dz = m->z - cam->z;
        fix adx = dx < 0 ? -dx : dx, adz = dz < 0 ? -dz : dz;
        if ((adx > adz ? adx : adz) > INT_TO_FIX(16))
            continue;                        /* out of view range */
        if (!mob_visible(cam, m))
            continue;
        render_bbox_reset();
        /* hissing creepers and freshly punched mobs flash white */
        bool flash = (m->flash & 2) ||
                     (m->kind == K_CREEPER && m->fuse && (m->fuse & 4));

        if (m->kind == K_PIG) {
            draw_pig(fb, m, flash);
        } else {
            /* which side of each axis faces the camera (matches render_box's
             * own +face/-face choice): +1 => +x/+z face drawn, -1 => -x/-z */
            int sx = (rcam.cx > m->x) ? 1 : -1;
            int sz = (rcam.cz > m->z) ? 1 : -1;
            /* facing quadrant from yaw (yaw 0 walks +z): q 0=+z 1=+x 2=-z 3=-x.
             * The mob's FRONT is that face. */
            int q = ((m->yaw + 32) >> 6) & 3;
            int face_x = (q == 1) ? 1 : (q == 3) ? -1 : 0;
            int face_z = (q == 0) ? 1 : (q == 2) ? -1 : 0;
            bool xfront = face_x && sx == face_x;
            bool zfront = face_z && sz == face_z;

            uint8_t body_base, head_base;
            const uint8_t *head_x, *head_z, *body_x, *body_z;
            if (m->kind == K_ZOMBIE) {
                body_base = tex_avg[T_ZOMBIE_BODY];
                head_base = tex_avg[T_ZOMBIE];
                head_x = tex_data[xfront ? T_ZOMBIE : T_ZOMBIE_SIDE];
                head_z = tex_data[zfront ? T_ZOMBIE : T_ZOMBIE_SIDE];
                body_x = tex_data[xfront ? T_ZOMBIE_BODY : T_ZOMBIE_BODY_S];
                body_z = tex_data[zfront ? T_ZOMBIE_BODY : T_ZOMBIE_BODY_S];
            } else {                         /* creeper */
                body_base = tex_avg[T_CREEPER_BODY];
                head_base = tex_avg[T_CREEPER];
                head_x = tex_data[xfront ? T_CREEPER : T_CREEPER_SIDE];
                head_z = tex_data[zfront ? T_CREEPER : T_CREEPER_SIDE];
                body_x = body_z = tex_data[T_CREEPER_BODY];  /* camo all sides */
            }
            if (flash) {
                body_base = head_base = PAL_WHITE;
                head_x = head_z = body_x = body_z = NULL;
            }
            render_box_faces(fb, m->x, m->y, m->z, M_HALF, M_BODY_H,
                             body_base, body_x, body_z);
            render_box_faces(fb, m->x, m->y + M_BODY_H, m->z, M_HALF, M_HEAD_H,
                             head_base, head_x, head_z);
        }
        if (rbb_x0 <= rbb_x1) {
            m->bb[0] = (int16_t)rbb_x0;
            m->bb[1] = (int16_t)rbb_y0;
            m->bb[2] = (int16_t)rbb_x1;
            m->bb[3] = (int16_t)rbb_y1;
        }
    }
}
