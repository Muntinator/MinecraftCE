; Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
; present.asm — hand-written eZ80 per-row pixel expanders for the scaled
; present path (M18d). Wired under __ez80__ only; the host keeps the C
; expanders in render.c (they are the byte-identity reference the compose
; matrix / scaled goldens check against).
;
;   void present_row2_asm(uint8_t *dst, const uint8_t *src, unsigned n);
;   void present_row4_asm(uint8_t *dst, const uint8_t *src, unsigned n);
;
; present_row2 writes dst[2i] = dst[2i+1] = src[i] for i in 0..n-1 (2x
; horizontal expand); present_row4 writes dst[4i..4i+3] = src[i] (4x).
; Each is EXACTLY the inner for-x loop of render_present / render_present_rect:
;     for (x=0;x<n;x++){ c=s[x]; *d++=c; *d++=c; [*d++=c; *d++=c;] }
; The C row loop and the LDIR row-duplication memcpys below each expanded
; row stay in C: a duplicated row is a compile-time-constant SCREEN_W (or
; runtime n*rscale) contiguous copy the toolchain lowers to a single LDIR,
; already near the ~10M-inst-byte/s bus floor — measured, not assumed
; (NODRAW present isolation: the LDIR-heavy 4x present is 1014 ticks vs the
; expand-heavy 2x present 3793, so moving the LDIRs to asm could not help).
;
; LOOP SHAPE (measured on-calc, NODRAW present isolation at r6, ticks are
; 8-frame sums, present cost = NODRAW(gfxN)-NODRAW(gfx0=14295)):
;   tight 1-px body:   present-2x 4783   present-4x 1250
;   unrolled-by-4:     present-2x 3793   present-4x 1014   (-21% / -19%)
; The eZ80 is fetch-bound (~10M inst-bytes/s) but the per-iteration djnz is
; pure overhead paid once per source pixel in the tight loop; unrolling the
; body 4x amortizes that branch fetch/exec over 4 pixels and wins despite
; the larger code — so the shipped routines unroll the group loop by 4 with
; a 1-px tail loop for n not a multiple of 4 (the windowed render_present_rect
; feeds arbitrary n; the full-frame path feeds rw = 80 or 160, both /4).
;
; n is the render-target row width (<= rw = winw/rscale <= 160) so it fits
; the 8-bit group/tail counters; only the low byte is read.
;
; ABI: args on the stack (ez80-clang CE convention, same as xform.asm); IX
; is the callee-saved frame pointer (push/pop). A, BC, DE, HL are caller-
; saved scratch. No shadow registers -> no di/ei window (the M10 "shadow
; before di" landmine cannot apply).

assume adl=1

section .text
public _present_row2_asm
public _present_row4_asm

; ---------------------------------------------------------------------------
; 2x row expander: dst[2i] = dst[2i+1] = src[i]
; ---------------------------------------------------------------------------
_present_row2_asm:
    push ix
    ld ix, 6                ; saved ix (3) + return address (3)
    add ix, sp
    ld de, (ix + 0)         ; dst
    ld hl, (ix + 3)         ; src
    ld a,  (ix + 6)         ; n (low byte; n <= 160)
    ld c, a
    and a, 3
    ld b, a                 ; tail = n & 3
    srl c
    srl c                   ; groups = n >> 2
    jr z, .tail2
    push bc                 ; keep tail in B across the group loop
    ld b, c
.grp2:
    ld a, (hl)              ; px 0
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld a, (hl)              ; px 1
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld a, (hl)              ; px 2
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld a, (hl)              ; px 3
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    djnz .grp2
    pop bc                  ; B = tail
.tail2:
    inc b
    dec b                   ; test tail == 0
    jr z, .done2
.tl2:
    ld a, (hl)
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    djnz .tl2
.done2:
    pop ix
    ret

; ---------------------------------------------------------------------------
; 4x row expander: dst[4i..4i+3] = src[i]
; ---------------------------------------------------------------------------
_present_row4_asm:
    push ix
    ld ix, 6
    add ix, sp
    ld de, (ix + 0)         ; dst
    ld hl, (ix + 3)         ; src
    ld a,  (ix + 6)         ; n (low byte; n <= 80)
    ld c, a
    and a, 3
    ld b, a                 ; tail = n & 3
    srl c
    srl c                   ; groups = n >> 2
    jr z, .tail4
    push bc
    ld b, c
.grp4:
    ld a, (hl)              ; px 0
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld a, (hl)              ; px 1
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld a, (hl)              ; px 2
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld a, (hl)              ; px 3
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    djnz .grp4
    pop bc
.tail4:
    inc b
    dec b
    jr z, .done4
.tl4:
    ld a, (hl)
    inc hl
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    ld (de), a
    inc de
    djnz .tl4
.done4:
    pop ix
    ret
