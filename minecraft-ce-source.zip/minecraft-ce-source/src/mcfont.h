/* Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README). */
#ifndef MCFONT_H
#define MCFONT_H

#include "common.h"

/*
 * mcfont — the Minecraft pixel font (UI U2). Portable C: the host harness
 * and the calc run the same code, so every text pixel is golden-covered.
 *
 * Glyphs are chars 32..126 of the official font/default.png, sliced by
 * tools/gen_lce_assets.py into gfx/lce/mcfont_data.h (gitignored: Mojang
 * art is never committed). Advances are Minecraft's charWidth (rightmost
 * non-empty column + 2, space 4); other chars draw nothing.
 *
 * mc_text draws `s` with its top-left at (x,y), each font texel a
 * scale x scale block, over a drop shadow offset (+scale,+scale) — MC's
 * drawStringWithShadow. Shadow colour (MC: the text colour at 25%):
 *   - white and the PAL_WHITE-bank UI greys -> pal_shadow_idx, the palette
 *     entry nearest (63,63,63) = MC's shadow of white (found in
 *     palette_build, so it follows any requant);
 *   - any other colour -> its bank-3 (50%) shade, the darkest shade of
 *     the same base the palette has;
 *   - PAL_BLACK text is drawn flat (MC's shadow of black is black; LCE
 *     draws dark labels on light panels without one).
 * Pixels outside the screen are clipped. Newlines are not interpreted.
 *
 * mc_text_width = MC getStringWidth * scale: the sum of the advances, which
 * includes the 1 px gap after the last glyph (MC centres with it too).
 */
void mc_text(uint8_t *fb, int x, int y, const char *s, uint8_t colour,
             int scale);
int  mc_text_width(const char *s, int scale);

/* centred on x = 160 (MC drawCenteredString) */
void mc_text_center(uint8_t *fb, int y, const char *s, uint8_t colour,
                    int scale);

#define MC_FONT_H 8     /* glyph cell height (rows 0..7, row 7 = descenders) */

#endif
