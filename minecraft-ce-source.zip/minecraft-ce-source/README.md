# Minecraft CE

by **EverydayCode** — [everydaycode.com](https://everydaycode.com)

Real-time textured 3D Minecraft for the TI-84 Plus CE. Walk, jump, swim,
mine, and build in a 32×32×12 block world with perspective-textured
rendering, terrain generation from a seed, trees, lakes, TNT, day/night,
and world saving — on a 48 MHz eZ80 calculator.

An unofficial fan project for the
[Everyday Code](https://www.youtube.com/@everydaycode) YouTube channel.
Not affiliated with Mojang or Microsoft.

## Features

- Grid-aware 3D renderer: greedy chunk meshing, provably-correct sort-free
  painter (BSP traversal), per-quad affine texture mapping with an eZ80
  assembly scanline core, per-direction face shading via palette banks;
  big near-camera top faces subdivide at draw time so the perspective warp
  stays subtle
- Player physics at a fixed 30 Hz tick: AABB collision, gravity, jumping,
  swimming
- Mine and place blocks (11 gatherable types); hold-to-break with
  per-material times in survival; TNT explodes
- Terrain from a numeric seed: hills, lakes, beaches, trees; a day/night
  cycle with a dithered gradient sky and a scatter of stars at night
- Three world save slots — start several worlds and pick one from the title
  (a legacy single-world save migrates into slot 1 automatically)
- Underground worm caves with surface entrances; coal and gold ore pockets
  to mine (deeper = rarer)
- World + player persist in an archived AppVar (survives RAM clears)
- Three graphics modes — Quality (320x240), Fast (160x120), Ultra (80x60,
  ~4x the frame rate) — same field of view, chunkier pixels; plus a
  windowed viewport option (full / 160x120 / 80x60 letterboxed, crisp),
  adjustable render distance (+/-) and a textures toggle, all live from
  the settings menu (stat key)
- Key taps are polled during rendering, so jumping mid-stride registers
  even at low frame rates; the HUD stays readable at night
- Creepers and zombies with head + body models (survival: they chase you,
  zombies bite, creepers explode) — punch them back: knockback, hit flash,
  and a kill stops a hissing creeper mid-fuse
- A deterministic mob spawner: hostiles come out at night in survival (up
  to four, despawning at dawn), and low-slung passive pigs wander the grass
  any time — punch a pig and it bolts
- Mobs drop loot on death: creepers give gunpowder, zombies sticks, pigs a
  porkchop; eat a porkchop from the inventory ITEMS page to heal three
  hearts (gunpowder also feeds the survival TNT recipe)
- Broken blocks drop floating mini cubes and items drop as flat,
  camera-facing sprites (as in Minecraft); walk over them to collect
- Recipe-book crafting (survival): scroll the recipe list in the inventory
  CRAFT page, the grid previews the selected recipe, `enter` crafts when you
  have the ingredients — planks, sticks, glass, TNT, and pickaxes/axes
- Tools are passive: the best pickaxe (stone/ore) or axe (wood) you own auto-
  applies, breaking those blocks 2x / 3x / 5x faster for wood / stone / gold —
  no durability, no held-item clutter

## Skyblock

A third world type next to Normal and Superflat: on the create screen press
`right` on World Type until it reads Skyblock. You start on the classic
floating island — an L of grass and dirt with one oak tree and a chest,
hanging over the void. The seed doesn't change the island; it only drives
the mob spawner.

- The starter chest holds a water bucket and a lava bucket. Look at it and
  press `2nd` to open it; `2nd` picks up / puts down a stack, `1`–`9` swap
  the cursored slot with that hotbar slot. Chests are also craftable (8
  planks at a crafting table), up to three per world.
- Liquids flow: a source spreads one block sideways and falls without
  limit. Where water and lava meet, the lava turns to cobblestone — dig a
  short trench, pour lava at one end and water at the other and the gap
  fills with cobblestone that comes straight back every time you mine it.
  Water poured onto a lava source makes obsidian instead (only an iron
  pickaxe gets it back).
- Infinite water: a one-block gap between two water sources becomes a third
  source, and scooping it with a bucket just lets it fill again.
- Buckets: `mode` with an empty bucket scoops the source you look at, with a
  full one pours it. Three iron ingots make a bucket at a crafting table.
  Lava lights up the dark and burns you and any dropped item it touches.
- Saplings: leaves drop one now and then; plant it on grass or dirt and it
  grows into an oak after a few minutes, so wood never runs out.
- The void: fall off the edge and you die in survival (you respawn on the
  island) or float back to the spawn in creative. Anything else that falls
  is gone.
- Mobs are on: build a dark platform and hostiles spawn on it at night;
  pigs need grass farther out, so extend the island.
- The whole island sits inside one 8x8 mesh chunk, so a Skyblock frame
  draws about twice as fast as a Normal world from the same spot.

## Controls

| Key | Action |
|---|---|
| arrows | walk / strafe (double-tap forward to sprint) |
| `y=` / `window` / `zoom` / `trace` | look up / left / down / right |
| `2nd` | jump / swim up / menu select; open the chest, crafting table or furnace you look at |
| `del` | break block (hold in survival) / attack mob |
| `mode` | place block |
| `graph` | cycle hotbar |
| `alpha` | inventory (`graph` cycles HOTBAR / ITEMS / CRAFT; on ITEMS, `enter` eats the cursored porkchop for +3 hearts; on CRAFT, `up`/`down` pick a recipe and `enter` crafts; `1`–`9` assign the cursored block to a hotbar slot, `del` clears a slot — survival) |
| `stat` | settings |
| `+` / `-` | render distance |
| `clear` | pause menu |

## Install

1. Send `MCCE.8xp` **and** `clibs.8xg` (the C libraries) to the calculator
   with [TI Connect CE](https://education.ti.com) or
   [tilp](http://lpg.ticalc.org/prj_tilp/).
2. OS 5.4 and earlier: run `Asm(prgmMCCE`.
   OS 5.5+ blocks native programs — install
   [arTIfiCE](https://yvantt.github.io/arTIfiCE/) once, then run MCCE from
   [Cesium](https://github.com/mateoconlechuga/cesium/releases).

## Build from source

Needs the [CE C toolchain](https://ce-programming.github.io/toolchain/)
and Python 3 with Pillow.

The block textures are Mojang's and are not distributed with this repo.
Download them once (the official Minecraft Java 1.4.7 client from Mojang's
own servers, checksum-verified; extracted to `assets/`, gitignored) and
slice them into build tiles (`gfx/lce/`, gitignored):

```sh
sh tools/fetch_mojang_assets.sh     # once: downloads the Mojang textures
python3 tools/gen_lce_assets.py     # slices them into gfx/lce/
make gfx                            # convimg -> src/gfx/
make                                # bin/MCCE.8xp
```

`make` stops with these instructions if the textures are missing.

## Performance, honestly

The eZ80 fetches every instruction byte through wait-stated RAM, so the
budget is ~10M instruction-bytes/second, not "48 MHz" of work. This engine
renders continuous textured 3D at roughly 1.5-5 fps while moving,
depending on graphics mode and render distance (Ultra at short distance
~5 fps even at the worst-case vista; typical ground-level play is
lighter). Hand-written eZ80 assembly drives the vertex transform,
texture spans and pixel upscaling, underground faces are culled unless
you can see them, and when you stand still a dirty-rect compositor
patches only what changed — a walking mob costs a third of a frame, and
a static scene costs essentially nothing.
For comparison, prior CE voxel projects re-render on a keypress. All fps
numbers in the video are measured with a cycle-accurate emulator harness.

## Credits

- Block textures: Mojang (Minecraft Java 1.4.7 art), downloaded from
  Mojang at build time by `tools/fetch_mojang_assets.sh`; not included in
  or distributed with this repository.
- The fixed-point multiply technique follows the asmmath.asm of
  [TICraft](https://github.com/TheMiningTeamYT/TICraft) (MIT) by
  TheMiningTeamYT and [Blocks-TI-84](https://github.com/TheScienceElf/Blocks-TI-84)
  by TheScienceElf (after Runer112). See `licenses/`.
- Renderer, mesher, physics, and everything else: original work for this
  project.

MIT licensed (the code; Mojang's textures are theirs and are fetched, not
shipped). Not affiliated with Mojang/Microsoft.
