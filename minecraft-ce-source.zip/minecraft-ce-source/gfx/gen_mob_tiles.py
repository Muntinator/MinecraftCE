#!/usr/bin/env python3
# Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
"""
gen_mob_tiles.py — reproducible generator for the M21 per-face mob tiles.

Hand-authored 16x16 pixel art (original work, Minecraft-inspired) in the
existing tile palette style. Side faces are auto-darkened by the renderer's
SHADE_X / SHADE_Z palette banks, so the tiles here are painted at full
brightness (front-face tone). Run from the repo root:  python3 gfx/gen_mob_tiles.py
"""
from PIL import Image

# ---- palette (RGB) -------------------------------------------------------
# Creeper greens (match the existing tex_creeper.png tones exactly)
CA = (18, 26, 18)     # near-black face features
C1 = (38, 142, 38)    # mid-dark camo
C2 = (58, 178, 58)    # mid camo
C3 = (88, 206, 88)    # light camo

# Zombie skin greens + shirt (match existing tex_zombie.png tones)
ZA = (40, 62, 38)     # dark: eyes / brow / hair
Z1 = (82, 128, 74)    # skin mid
Z2 = (96, 146, 86)    # skin light
SB = (52, 86, 142)    # shirt blue (already in palette)

# Pig pinks (NEW palette entries this stage)
PB = (232, 150, 164)  # body pink
PS = (224, 138, 152)  # snout pink
PN = (150, 80, 96)    # nostril / dark pink
PE = (30, 22, 24)     # eye dark


def save(name, rows, legend):
    im = Image.new("RGB", (16, 16))
    px = im.load()
    for y, row in enumerate(rows):
        assert len(row) == 16, (name, y, len(row))
        for x, ch in enumerate(row):
            px[x, y] = legend[ch]
    im.save("gfx/%s.png" % name)
    print("wrote gfx/%s.png" % name)


def camo(seed):
    """deterministic green camo field -> list of 16 strings of '1','2','3'."""
    rows = []
    s = seed
    out = []
    for y in range(16):
        line = []
        for x in range(16):
            s = (s * 1103515245 + 12345) & 0x7fffffff
            v = (s >> 16) & 0xff
            # bias toward mid tones, occasional dark/light dapple
            if v < 70:
                line.append('1')
            elif v < 200:
                line.append('2')
            else:
                line.append('3')
        out.append("".join(line))
    return out


# ---- CREEPER BODY: pure camo, no face -----------------------------------
save("tex_creeper_body", camo(0x1234),
     {'1': C1, '2': C2, '3': C3})

# ---- CREEPER SIDE (head side/back): camo + one square eye ----------------
cs = camo(0x77aa)
cs = [list(r) for r in cs]
# single dark eye toward the front edge (cols 9..12, rows 4..7)
for y in range(4, 8):
    for x in range(9, 13):
        cs[y][x] = '0'
cs = ["".join(r) for r in cs]
save("tex_creeper_side", cs, {'0': CA, '1': C1, '2': C2, '3': C3})

# ---- ZOMBIE FRONT (head): green face, two eyes, brow, no shirt -----------
# redesigned: the shirt now lives on the body box tiles.
zf = []
for y in range(16):
    line = []
    for x in range(16):
        line.append('1' if (x + y) & 1 else '2')
    zf.append(line)
# hairline / brow across the top 2 rows
for x in range(16):
    zf[0][x] = 'A'
    zf[1][x] = 'A' if (x % 3) else '1'
# eyes: two dark rectangles
for y in range(6, 9):
    for x in range(3, 6):
        zf[y][x] = 'A'
    for x in range(10, 13):
        zf[y][x] = 'A'
# mouth: a dark line low
for x in range(5, 11):
    zf[12][x] = 'A'
zf = ["".join(r) for r in zf]
save("tex_zombie", zf, {'A': ZA, '1': Z1, '2': Z2})

# ---- ZOMBIE SIDE (head side/back): skin + dark hair wrap + one eye --------
zs = []
for y in range(16):
    line = []
    for x in range(16):
        line.append('1' if (x + y) & 1 else '2')
    zs.append(line)
for x in range(16):           # hair wraps around the top
    zs[0][x] = 'A'
    zs[1][x] = 'A' if (x % 4) else '2'
for x in range(0, 4):         # hair down the back edge
    for y in range(2, 10):
        zs[y][x] = 'A'
for y in range(6, 9):         # one eye toward the front
    for x in range(10, 13):
        zs[y][x] = 'A'
zs = ["".join(r) for r in zs]
save("tex_zombie_side", zs, {'A': ZA, '1': Z1, '2': Z2})

# ---- ZOMBIE BODY FRONT: blue shirt torso + green arms at the sides -------
zb = []
for y in range(16):
    line = []
    for x in range(16):
        if x < 3 or x >= 13:        # arms (skin) on the outer columns
            line.append('1' if (x + y) & 1 else '2')
        else:                        # shirt in the middle
            line.append('S')
    zb.append(line)
zb = ["".join(r) for r in zb]
save("tex_zombie_body", zb, {'S': SB, '1': Z1, '2': Z2})

# ---- ZOMBIE BODY SIDE: shirt with one arm forward ------------------------
zbs = []
for y in range(16):
    line = []
    for x in range(16):
        if x < 4:                    # one arm visible on the side
            line.append('1' if (x + y) & 1 else '2')
        else:
            line.append('S')
    zbs.append(line)
zbs = ["".join(r) for r in zbs]
save("tex_zombie_body_s", zbs, {'S': SB, '1': Z1, '2': Z2})

# ---- PIG FACE (front): pink face, snout with two nostrils, two eyes -------
pf = []
for y in range(16):
    pf.append(['B'] * 16)
# eyes
for y in range(4, 7):
    for x in range(3, 6):
        pf[y][x] = 'E'
    for x in range(10, 13):
        pf[y][x] = 'E'
# snout block (lighter pink) centered low
for y in range(9, 15):
    for x in range(5, 11):
        pf[y][x] = 'S'
# two nostrils
for y in range(11, 13):
    pf[y][6] = 'N'
    pf[y][9] = 'N'
pf = ["".join(r) for r in pf]
save("tex_pig_face", pf, {'B': PB, 'S': PS, 'N': PN, 'E': PE})

# ---- PIG SIDE (head side): pink + one eye + snout hint -------------------
ps = []
for y in range(16):
    ps.append(['B'] * 16)
for y in range(4, 7):            # one eye
    for x in range(9, 12):
        ps[y][x] = 'E'
for y in range(9, 14):           # snout toward the front edge
    for x in range(11, 16):
        ps[y][x] = 'S'
for y in range(10, 13):
    ps[y][14] = 'N'
ps = ["".join(r) for r in ps]
save("tex_pig_side", ps, {'B': PB, 'S': PS, 'N': PN, 'E': PE})

# ---- PIG BODY (side): pink body with subtle dapple -----------------------
pb = []
for y in range(16):
    line = []
    for x in range(16):
        line.append('S' if ((x * 3 + y * 5) % 7 == 0) else 'B')
    pb.append("".join(line))
save("tex_pig_body", pb, {'B': PB, 'S': PS})

print("done")
