#!/usr/bin/env python3
# Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
"""convbin wrapper: run convbin, then give the compressed-8xp launcher a
correct 24-bit free-RAM check.

Why (push3 U0 root cause, proven with an instrumented CEmu trace):
convbin's 8xp-compressed launcher (zx7 and zx0 alike) does

    ld hl, <insert size>        ; decompressed image - compressed size + slack
    push hl
    call _ErrNotEnoughMem       ; meant to throw ERR:MEMORY if RAM is short
    call _PushRealO1
    pop hl
    ...
    call _InsertMem             ; no check of its own

but TI-OS _EnoughMem (behind _ErrNotEnoughMem) clears the upper byte of the
size before comparing, i.e. it only checks the low 16 bits. MCCE's insert
size is > 64 KB (0x010633 = 67123 B on the S0 image, ~73 KB on zx0), so the
OS checks 0x0633 = 1587 B instead. Whenever free RAM is below the real size
the check passes anyway, _InsertMem shoves user memory past the top of RAM
and wipes the VAT, a later ERR:MEMORY appears, and choosing 1:Quit (ENTER)
makes the OS walk the wrecked VAT and memmove garbage until it writes the
stack limit (CEmu: "NMI reset ... stack limit at 0xd19881") = RAM reset.

Fix: the header jump (userMem+1) is pointed at a small check placed in
reserved bytes after the description string (DESCRIPTION in the makefile
ends with filler '_' chars for this; a NUL is written before the code so
shells still show the clean description):

    call _MemChk                ; HL = free bytes (24-bit)
    ld de, <insert size> + MARGIN
    or a
    sbc hl, de
    jp c, _ErrMemory            ; clean ERR:MEMORY, nothing moved yet
    jp <original launcher>

The stub's own 16-bit check then always passes harmlessly. Every expected
byte is verified before patching; any mismatch fails the build.

Usage (makefile): CONVBIN := python3 tools/fix8xp_memcheck.py <convbin>
"""
import os
import subprocess
import sys

USERMEM = 0xD1A881
PLOTSSCREEN = 0xD09466
MEMCHK = 0x0204FC
ERRMEMORY = 0x020768
ERRNOTENOUGHMEM = 0x02072C
PUSHREALO1 = 0x020614
# _PushRealO1 (9 B on the FPS) runs between our check and _InsertMem; the
# rest is headroom.
MARGIN = 32
FILL = ord('_')


def le24(v):
    return bytes((v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF))


def rd24(b, i):
    return b[i] | b[i + 1] << 8 | b[i + 2] << 16


def die(msg):
    sys.stderr.write('fix8xp_memcheck: ERROR: %s\n' % msg)
    sys.exit(1)


def patch(path):
    f = bytearray(open(path, 'rb').read())
    if f[:8] != b'**TI83F*':
        die('%s is not an 8x file' % path)
    # var entry at 0x37: hdr len (2), data len (2), type, name[8], ver, flag,
    # data len (2), then the program's own 2-byte size + bytes.
    if f[0x3B] not in (5, 6):
        die('not a program')
    p0 = 0x4A                                   # p[0] = EF, p[1] = 7B
    if f[p0:p0 + 2] != b'\xEF\x7B' or f[p0 + 2] != 0x00 or f[p0 + 3] != 0xC3:
        die('unexpected program header')
    addr = lambda i: USERMEM + (i - 2)          # program index -> RAM addr
    idx = lambda a: a - USERMEM + 2
    jt = rd24(f, p0 + 4)
    it = p0 + idx(jt)
    # launcher part 1: ld hl,src / ld de,plotSScreen / ld bc,n / ldir / jp plotSScreen
    s = f[it:it + 18]
    if not (s[0] == 0x21 and s[4] == 0x11 and rd24(s, 5) == PLOTSSCREEN and
            s[8] == 0x01 and s[12:14] == b'\xED\xB0' and s[14] == 0xC3 and
            rd24(s, 15) == PLOTSSCREEN):
        die('compressed launcher not found at jp target %06X (split 8xp past '
            'the 65308 B single-file cap, or a convbin change?)' % jt)
    isrc = p0 + idx(rd24(s, 1))
    r = f[isrc:isrc + 14]
    if not (r[0] == 0x21 and r[4] == 0xE5 and r[5] == 0xCD and
            rd24(r, 6) == ERRNOTENOUGHMEM and r[9] == 0xCD and
            rd24(r, 10) == PUSHREALO1 and r[13] == 0xE1):
        die('launcher prologue (ld hl,n / push hl / call ErrNotEnoughMem) not found')
    need = rd24(r, 1)
    code = (b'\xCD' + le24(MEMCHK) +
            b'\x11' + le24(need + MARGIN) +
            b'\xB7' + b'\xED\x52' +
            b'\xDA' + le24(ERRMEMORY) +
            b'\xC3' + le24(jt))
    # description: p[7] = type byte, string from p[8] to NUL, all before jt
    d0 = p0 + 8
    dn = f.index(0, d0)
    if dn >= it:
        die('description overlaps the launcher')
    k = dn
    while k > d0 and f[k - 1] == FILL:
        k -= 1
    if dn - k < 1 + len(code):
        die('need %d filler "_" chars at the end of DESCRIPTION, found %d'
            % (1 + len(code), dn - k))
    f[k] = 0x00
    f[k + 1:k + 1 + len(code)] = code
    f[p0 + 4:p0 + 7] = le24(addr(k + 1 - p0))
    csum = sum(f[0x37:-2]) & 0xFFFF
    f[-2] = csum & 0xFF
    f[-1] = csum >> 8
    open(path, 'wb').write(f)
    print('[memcheck] %s: launcher insert size %d B (0x%06X; OS check sees '
          '0x%04X), 24-bit check at %06X' % (path, need, need, need & 0xFFFF,
                                            addr(k + 1 - p0)))


def main():
    args = sys.argv[1:]
    if not args:
        die('usage: fix8xp_memcheck.py <convbin> <convbin args...>')
    rc = subprocess.call(args)
    if rc:
        sys.exit(rc)
    if '-k' in args and args[args.index('-k') + 1] == '8xp-compressed':
        out = args[args.index('-o') + 1]
        if os.path.exists(out + '.0.8xv'):
            os.remove(out)          # never leave an unpatched/split 8xp behind
            die('convbin split %s into AppVars: the compressed program is '
                'past the 65308 B single-file cap' % out)
        try:
            patch(out)
        except SystemExit:
            os.remove(out)
            raise


if __name__ == '__main__':
    main()
