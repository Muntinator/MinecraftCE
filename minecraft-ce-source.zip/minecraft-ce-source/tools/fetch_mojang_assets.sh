#!/bin/sh
# Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
# Fetch the official Minecraft Java 1.4.7 client from Mojang's own CDN and
# extract its textures into assets/mojang-1.4.7/ (gitignored, never
# committed). 1.4.7 is the last release with the terrain.png / gui/items.png
# atlases and the gui/*.png panels the Legacy Console Edition art matches.
# Run from the repo root: sh tools/fetch_mojang_assets.sh
set -eu
VER=1.4.7
OUT=assets/mojang-$VER
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
curl -sSf https://piston-meta.mojang.com/mc/game/version_manifest_v2.json -o "$TMP/m.json"
VURL=$(python3 -c "import json,sys;print([v['url'] for v in json.load(open('$TMP/m.json'))['versions'] if v['id']=='$VER'][0])")
curl -sSf "$VURL" -o "$TMP/v.json"
set -- $(python3 -c "import json;c=json.load(open('$TMP/v.json'))['downloads']['client'];print(c['url'],c['sha1'])")
curl -sSf "$1" -o "$TMP/client.jar"
GOT=$(shasum "$TMP/client.jar" | cut -d' ' -f1)
[ "$GOT" = "$2" ] || { echo "sha1 mismatch: $GOT != $2" >&2; exit 1; }
mkdir -p "$OUT"
(cd "$OUT" && unzip -q -o "$TMP/client.jar" 'terrain.png' 'gui/*' 'font/*' 'title/*' 'armor/*' 'mob/*' 'misc/*' 'item/*' 'pack.png')
echo "extracted $(find "$OUT" -type f | wc -l | tr -d ' ') files into $OUT (client.jar sha1 $GOT)"
