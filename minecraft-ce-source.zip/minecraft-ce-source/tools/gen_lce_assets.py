#!/usr/bin/env python3
# Minecraft CE for the TI-84 Plus CE - (c) 2026 EverydayCode (everydaycode.com). MIT licensed (see README).
"""
gen_lce_assets.py - slice the official Mojang textures into build inputs.

Reads assets/mojang-1.4.7/ (fetched by `sh tools/fetch_mojang_assets.sh`;
gitignored, never committed) and writes 16x16 RGB tiles into gfx/lce/
(gitignored) for convimg. Deterministic: same inputs -> byte-identical PNGs.
Prints a manifest (output -> source file + rect + ops) and writes it to
gfx/lce/MANIFEST.txt LAST, which the makefile checks for (a partial run leaves
no manifest). Any missing input is a hard error naming the file.

UI overhaul U1 scope: every WORLD BLOCK tile. U2 adds the font: the
printable-ASCII glyphs of font/default.png as a generated C header
(gfx/lce/mcfont_data.h, included by src/mcfont.c; never commit). U3 adds
the item icons: 16x16 cells of gui/items.png, transparent, plus the HUD
hearts / hunger / armour sprites of gui/icons.png (one 9x63 sheet). GUI
panels and mob skins are later milestones (U4+).

Calls (documented in notes/push3-log.md "## U1"):
- Tints: terrain.png stores grass top and leaves GREY (Java tints them per
  biome at runtime). We bake a fixed plains tint by per-channel multiply:
  grass top x (145,189,89) = #91BD59 (grasscolor.png at plains temp 0.8 /
  rain 0.4), leaves x (119,171,47) = #77AB2F (foliagecolor.png, same point).
  Grass SIDE (index 3) is stored pre-coloured in 1.4.7 and is used as is.
- Alpha: the game has no transparent world texels. Leaves and glass map
  alpha 0 -> pure black, which convimg puts on PAL_BLACK and textures_init
  moves to PAL_TEXBLACK (black in every shade bank) - the same black gaps the
  old TICraft leaves/glass had. Torch and sapling map alpha 0 -> the dark
  icon inset (26,24,30), the convention their old tiles and every item icon
  use (they are drawn as thumbnails/boxes, never cut out). Water's static
  frame is ~55% alpha: its RGB is taken as is (alpha dropped).
- Water/lava are animated in Java; terrain.png holds a static frame (205 /
  237) which is used.
- Chest: 1.4.7's terrain.png has no chest tiles (25 is the emerald block,
  26/27 are the unused-slot placeholder); the chest is drawn from the model
  skin item/chest.png, so the faces are cut from that (lid 5 rows + base 10
  rows, 14 px wide) and nearest-scaled to 16x16, with the latch front
  (item/chest.png 1,1 2x4) laid over the front.
- Icons (U3): gui/items.png is a 16x16 grid of 16x16 item sprites on a
  transparent background. Each wanted cell is written as an RGB tile whose
  alpha-0 texels are the pinned placeholder magenta (255,0,255) = convimg
  fixed slot 60 (PAL_TEXBLACK's slot, which no real texel is near), so the
  transparent area costs no palette entry; textures_init turns texel 60 of
  every icon tile into the 0xFF transparent key before its usual 61->60
  black remap (src/textures.c). A texel is opaque iff alpha >= 128 (the
  sheet is 0/255 except two alpha-3 stray texels in the cooked porkchop,
  which Minecraft's alpha test discards too), so no partial-alpha texel can
  quantize to a real colour and show as a fringe.
- Font (U2): font/default.png is a 16x16 grid of 8x8 glyphs indexed by the
  character code. Chars 32..126 are packed 1 bit per texel (8 row bytes,
  bit 7 = leftmost column; a texel is "on" iff its blue channel is > 0,
  exactly FontRenderer.readFontTexture's `& 255 > 0` test in 1.4.7). The
  advance is Minecraft's charWidth: rightmost non-empty column + 2 (glyph
  width = rightmost + 1, plus a 1 px gap), space forced to 4.
"""
import os
import sys

from PIL import Image

SRC = "assets/mojang-1.4.7"
OUT = "gfx/lce"
FETCH_HINT = ("run `sh tools/fetch_mojang_assets.sh && "
              "python3 tools/gen_lce_assets.py` from the repo root")

GRASS_TINT = (145, 189, 89)    # #91BD59 plains grass
FOLIAGE_TINT = (119, 171, 47)  # #77AB2F plains foliage
INSET = (26, 24, 30)           # torch/sapling thumb background (old icon inset)
BLACK = (0, 0, 0)
KEY = (255, 0, 255)            # icon transparency: convimg fixed slot 60

_cache = {}


def load(rel):
    path = os.path.join(SRC, rel)
    if path not in _cache:
        if not os.path.isfile(path):
            sys.exit("gen_lce_assets: missing input %s (%s)" % (path, FETCH_HINT))
        _cache[path] = Image.open(path).convert("RGBA")
    return _cache[path]


def crop(rel, rect):
    x, y, w, h = rect
    im = load(rel)
    if x + w > im.width or y + h > im.height:
        sys.exit("gen_lce_assets: rect %r outside %s %dx%d"
                 % (rect, rel, im.width, im.height))
    return im.crop((x, y, x + w, y + h))


def terrain_rect(idx):
    return ((idx % 16) * 16, (idx // 16) * 16, 16, 16)


def flatten(im, bg):
    """RGBA -> RGB: alpha 0 -> bg, anything else keeps its RGB (the only
    partial-alpha tile used is water, whose RGB is wanted as is)."""
    out = Image.new("RGB", im.size)
    src, dst = im.load(), out.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = src[x, y]
            dst[x, y] = bg if a == 0 else (r, g, b)
    return out


def tint(im, rgb):
    out = im.copy()
    px = out.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            px[x, y] = (r * rgb[0] // 255, g * rgb[1] // 255,
                        b * rgb[2] // 255, a)
    return out


def scale16(im):
    return im.resize((16, 16), Image.NEAREST)


def stack(a, b):
    out = Image.new("RGBA", (a.width, a.height + b.height))
    out.paste(a, (0, 0))
    out.paste(b, (0, a.height))
    return out


manifest = []


def emit(name, im, desc):
    assert im.size == (16, 16) and im.mode == "RGB", (name, im.size, im.mode)
    im.save(os.path.join(OUT, name + ".png"), optimize=False)
    manifest.append("%-24s <- %s" % (name + ".png", desc))


def terrain(name, idx, bg=BLACK, tint_rgb=None):
    t = crop("terrain.png", terrain_rect(idx))
    desc = "terrain.png #%d rect %d,%d 16x16" % ((idx,) + terrain_rect(idx)[:2])
    if tint_rgb:
        t = tint(t, tint_rgb)
        desc += " tint x(%d,%d,%d)" % tint_rgb
    if any(p[3] == 0 for p in t.getdata()):
        desc += " alpha0->(%d,%d,%d)" % bg
    if any(0 < p[3] < 255 for p in t.getdata()):
        desc += " partial-alpha RGB kept"
    emit(name, flatten(t, bg), desc)


# item/chest.png (64x64 ModelChest skin): lid box 14x5x14 at uv (0,0), base
# box 14x10x14 at uv (0,19), latch 2x4x1 at uv (0,0). Box uv layout: top at
# (u+d, v), faces at v+d: left (u), front (u+d), right (u+d+w), back.
CHEST = "item/chest.png"
LID_TOP = (14, 0, 14, 14)
LID_FRONT = (14, 14, 14, 5)
LID_SIDE = (0, 14, 14, 5)
BASE_FRONT = (14, 33, 14, 10)
BASE_SIDE = (0, 33, 14, 10)
LATCH = (1, 1, 2, 4)
LATCH_AT = (7, 3)            # top-left in the 16x16 front (straddles the seam)
TORCH_STICK = (7, 6, 2, 10)  # torch model texels inside terrain #80


def chest():
    emit("tex_chest_top", flatten(scale16(crop(CHEST, LID_TOP)), BLACK),
         "%s rect %d,%d %dx%d -> 16x16 nearest" % ((CHEST,) + LID_TOP))
    side = scale16(stack(crop(CHEST, LID_SIDE), crop(CHEST, BASE_SIDE)))
    emit("tex_chest_side", flatten(side, BLACK),
         "%s rects %d,%d %dx%d + %d,%d %dx%d stacked -> 16x16 nearest"
         % ((CHEST,) + LID_SIDE + BASE_SIDE))
    front = scale16(stack(crop(CHEST, LID_FRONT), crop(CHEST, BASE_FRONT)))
    front.paste(crop(CHEST, LATCH), LATCH_AT)
    emit("tex_chest_front", flatten(front, BLACK),
         "%s rects %d,%d %dx%d + %d,%d %dx%d stacked -> 16x16 nearest, "
         "latch %d,%d %dx%d at %d,%d"
         % ((CHEST,) + LID_FRONT + BASE_FRONT + LATCH + LATCH_AT))


# gui/items.png cells (col, row) of the 16x16 grid. Verified on the sheet:
# armour rows 0..3 = helmet/chest/legs/boots, tool rows 4 sword, 5 shovel,
# 6 pickaxe, 7 axe; columns 0 wood/leather, 1 stone/chain, 2 iron,
# 3 diamond, 4 gold. Order = the T_ICO_* run in src/textures.h.
ITEMS = "gui/items.png"
ICONS = [
    ("tex_ico_stick", (5, 3)),
    ("tex_ico_coal", (7, 0)),
    ("tex_ico_ingot", (7, 1)),
    ("tex_ico_pork", (7, 5)),
    ("tex_ico_pork_cooked", (8, 5)),
    ("tex_ico_pick_w", (0, 6)),
    ("tex_ico_pick_s", (1, 6)),
    ("tex_ico_pick_i", (2, 6)),
    ("tex_ico_axe_w", (0, 7)),
    ("tex_ico_axe_s", (1, 7)),
    ("tex_ico_axe_i", (2, 7)),
    ("tex_ico_sword_w", (0, 4)),
    ("tex_ico_sword_s", (1, 4)),
    ("tex_ico_sword_i", (2, 4)),
    ("tex_ico_helmet", (2, 0)),
    ("tex_ico_chest", (2, 1)),
    ("tex_ico_legs", (2, 2)),
    ("tex_ico_boots", (2, 3)),
    ("tex_ico_bucket", (10, 4)),
    ("tex_ico_bucket_water", (11, 4)),
    ("tex_ico_bucket_lava", (12, 4)),
    ("tex_ico_gunpowder", (8, 2)),
]


def icons():
    for name, (col, row) in ICONS:
        rect = (col * 16, row * 16, 16, 16)
        t = crop(ITEMS, rect)
        out = Image.new("RGB", t.size)
        src, dst = t.load(), out.load()
        opaque = 0
        for y in range(16):
            for x in range(16):
                r, g, b, a = src[x, y]
                dst[x, y] = (r, g, b) if a >= 128 else KEY
                opaque += a >= 128
        if opaque < 32 or opaque > 255:
            sys.exit("gen_lce_assets: %s cell %d,%d has %d opaque texels "
                     "(mis-cropped?)" % (ITEMS, col, row, opaque))
        emit(name, out,
             "%s cell %d,%d rect %d,%d 16x16 alpha<128->key(%d,%d,%d)"
             % ((ITEMS, col, row) + rect[:2] + KEY))


# gui/icons.png HUD sprites (9x9; x/y of the cell's top-left). Each state is
# composited over its container (MC draws the container, then the fill), so
# every state of a kind covers the same pixel set: a value change repaints
# exactly the same pixels and never leaves stale world pixels behind.
ICONS_PNG = "gui/icons.png"
HUD_CONTAINER = {"heart": (16, 0), "food": (16, 27)}
HUD_ICONS = [                 # order = HI_* in src/hud.c
    ("heart_empty", "heart", None),
    ("heart_full", "heart", (52, 0)),
    ("food_empty", "food", None),
    ("food_full", "food", (52, 27)),
    ("food_half", "food", (61, 27)),
    ("armor_empty", None, (16, 9)),
    ("armor_full", None, (34, 9)),
]
HUD_OUT = "hud_icons"


def hud_icons():
    sheet = Image.new("RGB", (9, 9 * len(HUD_ICONS)), KEY)
    desc = []
    for i, (name, cont, cell) in enumerate(HUD_ICONS):
        spr = Image.new("RGBA", (9, 9), (0, 0, 0, 0))
        parts = []
        if cont:
            spr.alpha_composite(crop(ICONS_PNG, HUD_CONTAINER[cont] + (9, 9)))
            parts.append("%d,%d" % HUD_CONTAINER[cont])
        if cell:
            spr.alpha_composite(crop(ICONS_PNG, cell + (9, 9)))
            parts.append("%d,%d" % cell)
        sheet.paste(flatten(spr, KEY), (0, 9 * i))
        desc.append("%s=%s" % (name, "+".join(parts)))
    sheet.save(os.path.join(OUT, HUD_OUT + ".png"), optimize=False)
    manifest.append("%-24s <- %s 9x9 cells %s, alpha0->key(%d,%d,%d)"
                    % (HUD_OUT + ".png", ICONS_PNG, " ".join(desc), *KEY))


FONT = "font/default.png"
FONT_FIRST, FONT_LAST = 32, 126
FONT_HDR = "mcfont_data.h"


def font():
    im = load(FONT)
    if im.size != (128, 128):
        sys.exit("gen_lce_assets: %s is %dx%d, want 128x128"
                 % (FONT, im.width, im.height))
    px = im.load()
    rows, adv = [], []
    for ch in range(FONT_FIRST, FONT_LAST + 1):
        gx, gy = (ch % 16) * 8, (ch // 16) * 8
        on = [[px[gx + x, gy + y][2] > 0 for x in range(8)] for y in range(8)]
        rows.append([sum(0x80 >> x for x in range(8) if on[y][x])
                     for y in range(8)])
        right = -1                    # 1.4.7: scan columns 7..0, first non-empty
        for x in range(7, -1, -1):
            if any(on[y][x] for y in range(8)):
                right = x
                break
        adv.append(4 if ch == 32 else right + 2)
    n = FONT_LAST - FONT_FIRST + 1
    out = ["/* GENERATED by tools/gen_lce_assets.py from %s/%s - Mojang art,"
           % (SRC, FONT),
           " * gitignored, never commit. Chars %d..%d: 8 row bytes (bit 7 ="
           % (FONT_FIRST, FONT_LAST),
           " * leftmost column) + Minecraft's per-glyph advance. */",
           "#define MCFONT_FIRST %d" % FONT_FIRST,
           "#define MCFONT_COUNT %d" % n,
           "static const uint8_t mcfont_bits[MCFONT_COUNT][8] = {"]
    for i, r in enumerate(rows):
        out.append("    {%s}, /* %r */" % (",".join("0x%02X" % b for b in r),
                                            chr(FONT_FIRST + i)))
    out.append("};")
    out.append("static const uint8_t mcfont_adv[MCFONT_COUNT] = {")
    for i in range(0, n, 16):
        out.append("    " + ",".join(str(a) for a in adv[i:i + 16]) + ",")
    out.append("};")
    with open(os.path.join(OUT, FONT_HDR), "w") as f:
        f.write("\n".join(out).replace("/* '\\\\' */", "/* backslash */")
                + "\n")
    manifest.append("%-24s <- %s chars %d..%d 8x8 grid, 1bpp + MC advance"
                    % (FONT_HDR, FONT, FONT_FIRST, FONT_LAST))


def main():
    if not os.path.isdir(SRC):
        sys.exit("gen_lce_assets: missing input directory %s (%s)"
                 % (SRC, FETCH_HINT))
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):                 # no stale outputs
        os.remove(os.path.join(OUT, f))

    terrain("tex_grass_top", 0, tint_rgb=GRASS_TINT)
    terrain("tex_grass_side", 3)
    terrain("tex_dirt", 2)
    terrain("tex_stone", 1)
    terrain("tex_cobble", 16)
    terrain("tex_log_top", 21)
    terrain("tex_log_side", 20)
    terrain("tex_leaves", 52, bg=BLACK, tint_rgb=FOLIAGE_TINT)
    terrain("tex_planks", 4)
    terrain("tex_sand", 18)
    terrain("tex_water", 205)
    terrain("tex_glass", 49, bg=BLACK)
    terrain("tex_bedrock", 17)
    terrain("tex_tnt_top", 9)
    terrain("tex_tnt_side", 8)
    terrain("tex_tnt_bottom", 10)
    terrain("tex_coal_ore", 34)
    terrain("tex_iron_ore", 33)
    terrain("tex_furnace_front", 44)
    terrain("tex_furnace_side", 45)
    terrain("tex_furnace_top", 62)
    terrain("tex_furnace_front_lit", 61)
    terrain("tex_table_top", 43)
    terrain("tex_table_side", 59)
    terrain("tex_torch", 80, bg=INSET)
    # the in-world torch is a 2x10-texel box (light.c torches_draw: 0.22 x
    # 0.63 blocks = MC's torch model), which maps a WHOLE tile onto each
    # face: give it just the stick+flame (terrain #80 rect 7,6 2x10) so it
    # reads as a torch instead of a dark post; the full tile stays the
    # thumbnail.
    tx, ty = terrain_rect(80)[:2]
    rect = (tx + TORCH_STICK[0], ty + TORCH_STICK[1]) + TORCH_STICK[2:]
    emit("tex_torch_box", flatten(scale16(crop("terrain.png", rect)), INSET),
         "terrain.png #80 rect %d,%d %dx%d -> 16x16 nearest" % rect)
    chest()
    terrain("tex_lava", 237)
    terrain("tex_obsidian", 37)
    terrain("tex_sapling", 15, bg=INSET)
    icons()
    hud_icons()
    font()

    text = "\n".join(manifest) + "\n"
    sys.stdout.write(text)
    with open(os.path.join(OUT, "MANIFEST.txt"), "w") as f:
        f.write("# generated by tools/gen_lce_assets.py from %s\n" % SRC)
        f.write(text)
    print("gen_lce_assets: %d outputs -> %s/" % (len(manifest), OUT))


if __name__ == "__main__":
    main()
